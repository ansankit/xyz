import * as React from "react";
import { cn } from "@repo/ui/lib/utils";
import { useSidebar } from "./sidebar-provider";

export function Sidebar({ className, children }: React.HTMLAttributes<HTMLDivElement>) {
  const { open } = useSidebar();
  return (
    <aside
      className={cn(
        "flex flex-col border-r border-gray-200 bg-white transition-all dark:border-neutral-800 dark:bg-neutral-900",
        open ? "w-64" : "w-16",
        className
      )}
    >
      {children}
    </aside>
  );
}
