import * as React from "react";
import { cn } from "@repo/ui/lib/utils";

export function SidebarFooter({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={cn("p-4 border-t dark:border-neutral-800", className)} {...props} />
  );
}
