import * as React from "react";
import { cn } from "@repo/ui/lib/utils";

export function SidebarHeader({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={cn("flex items-center justify-between p-4 border-b dark:border-neutral-800", className)} {...props} />
  );
}
