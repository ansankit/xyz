"use client";

import React, { useState, useEffect } from "react";
import { cn } from "@repo/ui/lib/utils";
import { ChevronDown } from "lucide-react";
import type { LucideIcon } from "lucide-react";

interface SidebarCollapsibleItemProps {
  icon?: LucideIcon;
  label: string;
  children: React.ReactNode;
  active?: boolean;
  defaultOpen?: boolean;
  className?: string;
}

export function SidebarCollapsibleItem({ 
  icon: Icon, 
  label, 
  children, 
  active = false, 
  defaultOpen = false,
  className 
}: SidebarCollapsibleItemProps) {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  // Update open state when defaultOpen changes
  useEffect(() => {
    setIsOpen(defaultOpen);
  }, [defaultOpen]);

  const toggleOpen = () => {
    setIsOpen(!isOpen);
  };

  return (
    <div className={cn("space-y-1", className)}>
      {/* Parent Item */}
      <button
        onClick={toggleOpen}
        className={cn(
          "flex w-full items-center justify-between gap-3 rounded-md px-3 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-neutral-800 transition-colors",
          active && "bg-gray-100 dark:bg-neutral-800 font-medium"
        )}
        aria-expanded={isOpen}
        aria-label={`${isOpen ? 'Collapse' : 'Expand'} ${label}`}
      >
        <div className="flex items-center gap-3">
          {Icon && React.createElement(Icon, { size: 18 })}
          <span>{label}</span>
        </div>
        <ChevronDown 
          size={16} 
          className={cn(
            "transition-transform duration-300 ease-in-out",
            isOpen && "rotate-180"
          )}
        />
      </button>

      {/* Children Container with Smooth Animation */}
      <div
        className={cn(
          "overflow-hidden transition-all duration-300 ease-in-out",
          isOpen ? "max-h-96 opacity-100" : "max-h-0 opacity-0"
        )}
      >
        <div className="space-y-1 pl-6">
          {children}
        </div>
      </div>
    </div>
  );
}
