"use client";

import React from "react";
import Link from "next/link";
import { cn } from "@repo/ui/lib/utils";
import type { LucideIcon } from "lucide-react";

interface SidebarItemProps {
  icon?: LucideIcon;
  label: string;
  href?: string;
  active?: boolean;
}

export function SidebarItem({ icon: Icon, label, href, active }: SidebarItemProps) {
  const className = cn(
    "flex items-center gap-3 rounded-md px-3 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-neutral-800",
    active && "bg-gray-100 dark:bg-neutral-800 font-medium"
  );

  const content = (
    <>
      {Icon && React.createElement(Icon, { size: 18 })}
      <span>{label}</span>
    </>
  );

  if (href) {
    return (
      <Link href={href} prefetch={true} className={className}>
        {content}
      </Link>
    );
  }

  return <div className={className}>{content}</div>;
}
