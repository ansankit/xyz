"use client"

import * as React from "react"
import { Bell } from "lucide-react"
import { Button } from "../button"
import { Badge } from "../badge"
import { ProfileDropdown, type UserProfile } from "./profile-dropdown"
import { cn } from "@repo/ui/lib/utils"

export interface HeaderProps extends React.HTMLAttributes<HTMLElement> {
  icon?: React.ReactNode
  onNotificationClick?: () => void
  notificationCount?: number
  user?: UserProfile
  onEditProfile?: () => void
  onManageNotifications?: () => void
  onChangePassword?: () => void
  onLogout?: () => void
  tabs?: React.ReactNode
}

export function Header({
  className,
  icon,
  onNotificationClick,
  notificationCount = 0,
  user,
  onEditProfile,
  onManageNotifications,
  onChangePassword,
  onLogout,
  tabs,
  ...props
}: HeaderProps) {
  const hasWhiteBackground = className?.includes('bg-white') || className?.includes('!bg-white')
  const hasLightYellowBackground = className?.includes('bg-yellow-50') || className?.includes('bg-amber-50')
  
  return (
    <header
      className={cn(
        "sticky top-0 z-50 w-full border-border backdrop-blur max-w-screen-3xl mx-auto justify-center",
        className
      )}
      {...props}
    >
      <div className={cn(
        "container flex h-16 shadow-sm items-center justify-between w-full max-w-screen-3xl mx-auto pr-6", 
        hasWhiteBackground ? 'bg-white' : 
        hasLightYellowBackground ? 'bg-yellow-50' :
        'bg-navbar'
      )}>
        {/* Left side - Icon */}
        <div className="flex items-center">
          {icon && (
            <div className="flex items-center space-x-2 text-primary">
              {icon}
            </div>
          )}
        </div>

        {/* Center - Tabs */}
        {tabs && (
          <div className="flex-1 flex justify-center">
            {tabs}
          </div>
        )}

        {/* Right side - Notifications and Profile */}
        <div className="flex items-center gap-3">
          {/* Notifications */}
          {/* {onNotificationClick && (
            <Button
              variant="ghost"
              size="icon"
              className="relative h-10 w-10"
              onClick={onNotificationClick}
            >
              <Bell className="h-5 w-5" />
              {notificationCount > 0 && (
                <Badge
                  variant="destructive"
                  className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs"
                >
                  {notificationCount > 99 ? "99+" : notificationCount}
                </Badge>
              )}
            </Button>
          )} */}

          {/* Profile Dropdown */}
          {user && (
            <ProfileDropdown
              user={user}
              onEditProfile={onEditProfile}
              onManageNotifications={onManageNotifications}
              onChangePassword={onChangePassword}
              onLogout={onLogout}
            />
          )}
        </div>
      </div>
    </header>
  )
}
