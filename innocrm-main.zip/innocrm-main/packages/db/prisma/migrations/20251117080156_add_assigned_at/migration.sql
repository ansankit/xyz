-- AlterTable
ALTER TABLE "leads" ADD COLUMN     "assigned_at" TIMESTAMP(3);
