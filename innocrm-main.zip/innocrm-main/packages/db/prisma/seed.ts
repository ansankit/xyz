import {
  LeadStatus,
  PrismaClient,
  UserRole,
  LeadSource,
  Region,
  Contact as ContactModel,
} from "@prisma/client";

const prisma = new PrismaClient();

// -------------------------------
// Helpers
// -------------------------------
function randInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function pick<T>(arr: T[]): T {
  return arr[randInt(0, arr.length - 1)];
}

function randomDateWithin(days: number): Date {
  const now = new Date();
  const past = new Date(now);
  past.setDate(now.getDate() - randInt(0, days));
  past.setHours(randInt(0, 23), randInt(0, 59), randInt(0, 59), 0);
  return past;
}

function slugify(input: string): string {
  return input
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

function buildEmail(name: string, company: string): string {
  const n = slugify(name).replace(/-/g, ".");
  const c = slugify(company).replace(/-/g, "");
  return `${n}@${c}.com`;
}

async function main() {
  console.log("🌱 Seeding database (destructive reset, medium volume)...");

  // Destructive reset in FK-safe order
  await prisma.$transaction([
    prisma.chatHistory.deleteMany({}),
    prisma.botSession.deleteMany({}),
    prisma.analyticsEvent.deleteMany({}),
    prisma.formSubmission.deleteMany({}),
    prisma.campaignMember.deleteMany({}),
    prisma.campaignChannel.deleteMany({}),
    prisma.campaign.deleteMany({}),
    prisma.leadAssignmentRule.deleteMany({}),
    prisma.customField.deleteMany({}),
    prisma.auditLog.deleteMany({}),
    prisma.lead.deleteMany({}),
    prisma.contact.deleteMany({}),
    prisma.account.deleteMany({}),
    prisma.user.deleteMany({}),
  ]);

  // Users with roles
  const passwordHash =
    "$2b$10$K7L1OJ45/4Y2nIvhRVpCe.FSmhDdWoXehVzJByJ.Xd5c3z2y7BZ8K"; // "admin123"

  const adminUser = await prisma.user.upsert({
    where: { email: "admin@example.com" },
    update: {},
    create: {
      name: "Admin User",
      email: "admin@example.com",
      passwordHash,
      role: UserRole.ADMIN,
      region: Region.NORTH,
    },
  });

  const salesUserProfiles = [
    { name: "Sarah Sales", email: "sarah.sales@example.com", region: Region.SOUTH },
    { name: "Liam Prospect", email: "liam.sales@example.com", region: Region.NORTH },
    { name: "Priya Closer", email: "priya.sales@example.com", region: Region.WEST_1 },
    { name: "Diego Hunter", email: "diego.sales@example.com", region: Region.WEST_2 },
  ];
  const salesUsers = await Promise.all(
    salesUserProfiles.map(profile =>
      prisma.user.upsert({
        where: { email: profile.email },
        update: {},
        create: {
          name: profile.name,
          email: profile.email,
          passwordHash,
          role: UserRole.SALES,
          region: profile.region,
        },
      })
    )
  );
  const primarySalesUser = salesUsers[0];

  const marketingUser = await prisma.user.upsert({
    where: { email: "mike.marketing@example.com" },
    update: {},
    create: {
      name: "Mike Marketing",
      email: "mike.marketing@example.com",
      passwordHash,
      role: UserRole.ADMIN,
      region: Region.EAST,
    },
  });

  // Accounts
  const industries = [
    "Technology",
    "Marketing",
    "Consulting",
    "E-commerce",
    "Healthcare",
    "Education",
    "Finance",
    "Manufacturing",
  ];
  const companyNames = [
    "TechNova Labs",
    "MarketGenius",
    "BluePeak Consulting",
    "Orbit Retail",
    "HealthSync",
    "EduSphere",
    "FinEdge Capital",
    "ForgeWorks",
    "BrightPath",
    "CloudBridge",
    "VectorAI",
    "LuminaSoft",
    "GrowthFoundry",
    "PinnacleOps",
    "ApexMetrics",
    "SummitHub",
    "NeonByte",
    "QuantumWare",
    "AtlasGroup",
    "Zenith Systems",
  ];
  const accountCache = new Map<string, { id: number; name: string }>();
  async function getOrCreateAccount(name: string) {
    if (accountCache.has(name)) {
      return accountCache.get(name)!;
    }
    const created = await prisma.account.create({
      data: {
        name,
        industry: pick(industries),
        website: `https://www.${slugify(name)}.com`,
      },
    });
    const accountRecord = { id: created.id, name: created.name };
    accountCache.set(name, accountRecord);
    return accountRecord;
  }
  const contacts: {
    id: number;
    name: string;
    email: string;
    accountId?: number | null;
  }[] = [];
  const firstNames = [
    "John",
    "Sarah",
    "Mike",
    "Emily",
    "David",
    "Laura",
    "Adam",
    "Nina",
    "Chris",
    "Olivia",
    "Ethan",
    "Grace",
    "Liam",
    "Sophia",
    "Noah",
    "Ava",
  ];
  const lastNames = [
    "Smith",
    "Johnson",
    "Davis",
    "Brown",
    "Wilson",
    "Clark",
    "Lopez",
    "Taylor",
    "Lee",
    "Martin",
    "Walker",
    "Hall",
    "Young",
    "King",
  ];
  const positions = [
    "CTO",
    "CMO",
    "Marketing Director",
    "VP Sales",
    "CEO",
    "Growth Lead",
    "Head of Ops",
    "Product Manager",
  ];

  // Campaigns
  const landingCampaign = await prisma.campaign.create({
    data: {
      name: "Spring Landing Page Lead Gen",
      description: "Landing page campaign to capture demo requests",
      startDate: randomDateWithin(90),
      endDate: null,
      createdBy: marketingUser.id,
    },
  });
  await prisma.campaignChannel.create({
    data: {
      campaignId: landingCampaign.id,
      channelType: "landing-page-campaign",
      externalId: `lp-${landingCampaign.id}-${Date.now()}`,
    },
  });

  const whatsappCampaign = await prisma.campaign.create({
    data: {
      name: "WhatsApp Re-Engagement",
      description: "Follow-up with dormant leads via WhatsApp",
      startDate: randomDateWithin(60),
      endDate: null,
      createdBy: marketingUser.id,
    },
  });
  await prisma.campaignChannel.create({
    data: {
      campaignId: whatsappCampaign.id,
      channelType: "whatsapp-campaign",
      externalId: `wa-${whatsappCampaign.id}-${Date.now()}`,
    },
  });

  const emailCampaign = await prisma.campaign.create({
    data: {
      name: "Email Nurture Series",
      description: "Three-touch email sequence for product education",
      startDate: randomDateWithin(75),
      endDate: null,
      createdBy: marketingUser.id,
    },
  });
  await prisma.campaignChannel.create({
    data: {
      campaignId: emailCampaign.id,
      channelType: "email-marketing",
      externalId: `em-${emailCampaign.id}-${Date.now()}`,
    },
  });

  // Leads
  const leadSources = ["IMPORT", "LANDING_PAGE", "MANUAL"];
  const leadStatuses = [
    "OPEN",
    "WORKING",
    "QUALIFIED",
    "NURTURING",
    "CONVERTED",
    "UNQUALIFIED",
  ];

  const leads = [] as { id: number; email: string }[];
  const totalLeads = 500;
  const assignedLeadCount = 400;
  const unassignedLeadCount = totalLeads - assignedLeadCount;
  const assignmentPlan = [
    ...Array(assignedLeadCount).fill(true),
    ...Array(unassignedLeadCount).fill(false),
  ].sort(() => Math.random() - 0.5);
  const usedLeadEmails = new Set<string>();

  // Location data for seed data (Indian context)
  const cities = [
    "Mumbai",
    "Delhi",
    "Bengaluru",
    "Hyderabad",
    "Chennai",
    "Pune",
    "Ahmedabad",
    "Kolkata",
    "Jaipur",
    "Chandigarh",
  ];
  const states = [
    "Maharashtra",
    "Delhi",
    "Karnataka",
    "Telangana",
    "Tamil Nadu",
    "Maharashtra",
    "Gujarat",
    "West Bengal",
    "Rajasthan",
    "Punjab",
  ];
  const pincodes = [
    "400001",
    "110001",
    "560001",
    "500001",
    "600001",
    "411001",
    "380001",
    "700001",
    "302001",
    "160017",
  ];

  const generateIndianPhoneNumber = () => {
    const prefixes = ["6", "7", "8", "9"];
    const firstDigit = pick(prefixes);
    let remaining = "";
    for (let i = 0; i < 9; i++) {
      remaining += randInt(0, 9);
    }
    return `${firstDigit}${remaining}`;
  };

  for (let i = 0; i < totalLeads; i++) {
    const isAssigned = assignmentPlan[i];
    const owner = isAssigned ? pick(salesUsers) : null;
    const firstName = pick(firstNames);
    const lastName = pick(lastNames);
    const fullName = `${firstName} ${lastName}`;
    const company = pick(companyNames);
    let email = buildEmail(fullName, company);

    // Ensure unique email by adding suffix if needed
    let counter = 1;
    while (usedLeadEmails.has(email)) {
      email = email.replace("@", `+${counter}@`);
      counter++;
    }
    usedLeadEmails.add(email);

    // Pick location indices (same index for matching data)
    const statusPool = owner ? leadStatuses : leadStatuses.filter(s => s !== "CONVERTED");
    const status = pick(statusPool) as LeadStatus;

    let convertedContactId: number | null = null;
    if (status === "CONVERTED") {
      const existingContact = await prisma.contact.findUnique({
        where: { email },
      });
      const account = await getOrCreateAccount(company);
      let contactRecord: ContactModel;
      if (existingContact) {
        contactRecord = existingContact;
      } else {
        contactRecord = await prisma.contact.create({
          data: {
            name: fullName,
            email,
            phone: generateIndianPhoneNumber(),
            position: pick(positions),
            accountId: account.id,
          },
        });
      }
      convertedContactId = contactRecord.id;
      if (!contacts.some(c => c.id === contactRecord.id)) {
        contacts.push({
          id: contactRecord.id,
          name: contactRecord.name,
          email: contactRecord.email,
          accountId: contactRecord.accountId,
        });
      }
    }

    const created = await prisma.lead.create({
      data: {
        firstName,
        lastName,
        email: email,
        phone: generateIndianPhoneNumber(),
        companyName: company,
        city: pick(cities),
        state: pick(states),
        pincode: pick(pincodes),
        source: pick(leadSources) as LeadSource,
        status,
        ownerId: owner ? owner.id : null,
        assignedAt: owner ? randomDateWithin(60) : null,
        convertedToContactId: convertedContactId,
        score: randInt(10, 100),
      },
    });
    leads.push({ id: created.id, email: created.email });
  }

  // Campaign Members (contacts + leads)
  const memberStatuses = ["Invited", "Clicked", "Responded"];
  const allCampaigns = [landingCampaign, whatsappCampaign, emailCampaign];

  for (const c of allCampaigns) {
    const sampleContacts = contacts.slice(0, randInt(15, 25));
    for (const ct of sampleContacts) {
      try {
        await prisma.campaignMember.create({
          data: {
            campaignId: c.id,
            contactId: ct.id,
            status: pick(memberStatuses),
          },
        });
      } catch {}
    }
    const sampleLeads = leads.slice(0, randInt(20, 35));
    for (const ld of sampleLeads) {
      try {
        await prisma.campaignMember.create({
          data: {
            campaignId: c.id,
            leadId: ld.id,
            status: pick(memberStatuses),
          },
        });
      } catch {}
    }
  }

  // Analytics Events by channel
  type MemberRef = { campaignId: number; contactId?: number; leadId?: number };
  const membersLanding = await prisma.campaignMember.findMany({
    where: { campaignId: landingCampaign.id },
  });
  const membersWhatsApp = await prisma.campaignMember.findMany({
    where: { campaignId: whatsappCampaign.id },
  });
  const membersEmail = await prisma.campaignMember.findMany({
    where: { campaignId: emailCampaign.id },
  });

  const makeEvent = (
    ref: MemberRef,
    eventType: string,
    eventData: Record<string, any> = {}
  ) => ({
    campaignId: ref.campaignId,
    contactId: ref.contactId ?? null,
    leadId: ref.leadId ?? null,
    eventType,
    eventData,
    occurredAt: randomDateWithin(90),
  });

  const analyticsToCreate: any[] = [];
  // Landing page events
  for (const m of membersLanding) {
    const ref = {
      campaignId: m.campaignId,
      contactId: m.contactId ?? undefined,
      leadId: m.leadId ?? undefined,
    };
    analyticsToCreate.push(
      makeEvent(ref, "page_view", { path: "/", utm_source: "google" })
    );
    if (Math.random() < 0.6)
      analyticsToCreate.push(
        makeEvent(ref, "form_submit", { form: "demo", success: true })
      );
  }
  // WhatsApp events
  for (const m of membersWhatsApp) {
    const ref = {
      campaignId: m.campaignId,
      contactId: m.contactId ?? undefined,
      leadId: m.leadId ?? undefined,
    };
    analyticsToCreate.push(
      makeEvent(ref, "whatsapp_msg_sent", { template: "reengage_v1" })
    );
    if (Math.random() < 0.45)
      analyticsToCreate.push(
        makeEvent(ref, "whatsapp_reply", {
          sentiment: pick(["positive", "neutral", "negative"]),
        })
      );
  }
  // Email events
  for (const m of membersEmail) {
    const ref = {
      campaignId: m.campaignId,
      contactId: m.contactId ?? undefined,
      leadId: m.leadId ?? undefined,
    };
    analyticsToCreate.push(
      makeEvent(ref, "email_sent", { messageId: `m-${m.id}` })
    );
    if (Math.random() < 0.7)
      analyticsToCreate.push(
        makeEvent(ref, "email_open", { userAgent: "Mozilla" })
      );
    if (Math.random() < 0.4)
      analyticsToCreate.push(
        makeEvent(ref, "email_click", { url: "/pricing" })
      );
  }

  // Batch create analytics in chunks to avoid large payloads
  const chunkSize = 100;
  for (let i = 0; i < analyticsToCreate.length; i += chunkSize) {
    const slice = analyticsToCreate.slice(i, i + chunkSize);
    await prisma.analyticsEvent.createMany({ data: slice });
  }

  // Form Submissions (landing page)
  const formSubsToCreate: any[] = [];
  const landingMembers = [...membersLanding];
  for (let i = 0; i < randInt(30, 50) && i < landingMembers.length; i++) {
    const m = landingMembers[i];
    const name = m.contactId
      ? (contacts.find(c => c.id === m.contactId)?.name ?? "")
      : (leads
          .find(l => l.id === (m.leadId as number))
          ?.email.split("@")[0]
          .replace(".", " ") ?? "");
    formSubsToCreate.push({
      leadId: m.leadId ?? null,
      contactId: m.contactId ?? null,
      submittedAt: randomDateWithin(90),
      formData: {
        name,
        email: m.contactId
          ? contacts.find(c => c.id === m.contactId)?.email
          : leads.find(l => l.id === (m.leadId as number))?.email,
        utm_campaign: "spring-lp",
      },
    });
  }
  for (let i = 0; i < formSubsToCreate.length; i += 100) {
    await prisma.formSubmission.createMany({
      data: formSubsToCreate.slice(i, i + 100),
    });
  }

  // WhatsApp Bot Sessions + Chat History
  const whatsappContacts = membersWhatsApp
    .filter(m => m.contactId)
    .slice(0, randInt(10, 20));
  for (const m of whatsappContacts) {
    const startedAt = randomDateWithin(45);
    const ended = Math.random() < 0.6;
    const session = await prisma.botSession.create({
      data: {
        contactId: m.contactId as number,
        userId: marketingUser.id,
        startedAt,
        endedAt: ended
          ? new Date(startedAt.getTime() + randInt(10, 3600) * 1000)
          : null,
        status: ended ? "closed" : "open",
      },
    });
    const msgs = [
      { sender: "system", message: "Hello! Can we help with your evaluation?" },
      {
        sender: "contact",
        message: pick(["Yes, tell me more", "Maybe later", "What's pricing?"]),
      },
      {
        sender: "system",
        message: pick([
          "We offer flexible plans.",
          "We have a free trial.",
          "I'll connect you with sales.",
        ]),
      },
    ];
    for (const msg of msgs) {
      await prisma.chatHistory.create({
        data: {
          contactId: m.contactId as number,
          sessionId: session.id,
          message: msg.message,
          sender: msg.sender,
          createdAt: new Date(startedAt.getTime() + randInt(1, 1800) * 1000),
        },
      });
    }
  }

  // Lead Assignment Rules
  await prisma.leadAssignmentRule.createMany({
    data: [
      {
        name: "High Score Website Leads",
        criteria: { score_gte: 85, source: "Website" },
        assignedUserId: primarySalesUser.id,
        priority: 1,
        active: true,
        createdAt: new Date(),
      },
      {
        name: "WhatsApp Quick Replies",
        criteria: { source: "WhatsApp" },
        assignedUserId: salesUsers[1]?.id ?? primarySalesUser.id,
        priority: 2,
        active: true,
        createdAt: new Date(),
      },
    ],
  });

  console.log("✅ Database seeded successfully!");
}

main()
  .catch(e => {
    console.error("❌ Error seeding database:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
