import { createApp } from './app.js';
import { setupRoutes } from './routes/index.js';
import { prisma } from '@repo/db';

const app = createApp();
const PORT = process.env.PORT || 4000;

// Setup all routes
setupRoutes(app);

// Start server
app.listen(PORT, () => {
  console.log(`🚀 API server running on http://localhost:${PORT}`);
  console.log(`📊 Health check: http://localhost:${PORT}/health`);
});

// Graceful shutdown
process.on('SIGINT', async () => {
  console.log('🛑 Shutting down server...');
  await prisma.$disconnect();
  process.exit(0);
});

process.on('SIGTERM', async () => {
  console.log('🛑 Shutting down server...');
  await prisma.$disconnect();
  process.exit(0);
});
