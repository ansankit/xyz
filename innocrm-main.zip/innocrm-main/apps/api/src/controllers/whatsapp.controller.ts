import { Request, Response } from 'express';
// WhatsApp features are temporarily disabled. Export stubs that return 503.
export class WhatsappController {
  async listAccounts(req: Request, res: Response) { res.status(503).json({ message: 'WhatsApp disabled' }); }
  async createAccount(req: Request, res: Response) { res.status(503).json({ message: 'WhatsApp disabled' }); }
  async listTemplates(req: Request, res: Response) { res.status(503).json({ message: 'WhatsApp disabled' }); }
  async syncTemplates(req: Request, res: Response) { res.status(503).json({ message: 'WhatsApp disabled' }); }
  async createCampaign(req: Request, res: Response) { res.status(503).json({ message: 'WhatsApp disabled' }); }
  async scheduleOrSend(req: Request, res: Response) { res.status(503).json({ message: 'WhatsApp disabled' }); }
  async optOut(req: Request, res: Response) { res.status(503).json({ message: 'WhatsApp disabled' }); }
  async removeOptOut(req: Request, res: Response) { res.status(503).json({ message: 'WhatsApp disabled' }); }
  async listDeliveries(req: Request, res: Response) { res.status(503).json({ message: 'WhatsApp disabled' }); }
  async listEvents(req: Request, res: Response) { res.status(503).json({ message: 'WhatsApp disabled' }); }
  async handleWebhook(req: Request, res: Response) { res.status(503).json({ message: 'WhatsApp disabled' }); }
}


