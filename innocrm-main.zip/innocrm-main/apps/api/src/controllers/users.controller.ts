import { Request, Response } from 'express';
import { prisma } from '@repo/db';
import { UserRole, Region } from '@prisma/client';
import bcrypt from 'bcryptjs';
import { generateUserPassword } from '../utils/password.utils.js';
import { emailService } from '../services/email.service.js';
import {
  handleError,
  handleValidationError,
  handleNotFoundError,
  handleConflictError,
  validateRequiredFields,
} from '../utils/errorHandler.js';
import { isValidEmail, isValidPhone, isValidName } from '../utils/validators.js';

export class UserController {
  async getAllUsers(req: Request, res: Response) {
    try {
      const { role, region } = req.query;
      const developerEmail = process.env.DEVELOPER_LOGIN_EMAIL?.trim() || undefined;
      const developerName = process.env.DEVELOPER_LOGIN_NAME?.trim() || 'Developer Access';

      // Build where clause based on query params
      const whereClause: any = {
        deletedAt: null, // Exclude soft-deleted users
      };
      if (role) {
        whereClause.role = role as UserRole;
      }
      if (region) {
        whereClause.region = region as Region;
      }
      // Exclude developer account if configured (case-insensitive)
      const andFilters: any[] = [];
      if (developerEmail) {
        andFilters.push({
          NOT: [
            {
              email: {
                equals: developerEmail,
                mode: 'insensitive',
              }
            },
            {
              AND: [
                { role: UserRole.SYSTEM_ADMIN },
                { name: { equals: developerName, mode: 'insensitive' } }
              ]
            }
          ]
        } as any);
      } else {
        // If email is not configured, still attempt to hide the conventional developer account by name + role
        andFilters.push({
          NOT: {
            AND: [
              { role: UserRole.SYSTEM_ADMIN },
              { name: { equals: developerName, mode: 'insensitive' } }
            ]
          }
        } as any);
      }
      if (andFilters.length > 0) {
        whereClause.AND = andFilters;
      }

      const users = await prisma.user.findMany({
        where: whereClause,
        select: {
          id: true,
          name: true,
          email: true,
          phone: true,
          role: true,
          region: true,
          createdAt: true,
        }
      });
      res.json(users);
    } catch (error) {
      handleError(error, res, 'Get all users');
    }
  }

  async createUser(req: Request, res: Response) {
    try {
      const { name, email, phone, role, region } = req.body;

      // Validate required fields (region is optional for SYSTEM_ADMIN)
      const requiredFields = role === UserRole.SYSTEM_ADMIN 
        ? ['name', 'email', 'role'] 
        : ['name', 'email', 'role', 'region'];
      if (!validateRequiredFields(req.body, requiredFields, res, 'Create user')) {
        return;
      }

      // Normalize email: trim whitespace and convert to lowercase for consistent storage
      const normalizedEmail = email.trim().toLowerCase();

      // Validate name
      if (!isValidName(name)) {
        return handleValidationError(
          res,
          'Name is required and must be non-empty (max 255 characters)',
          'name',
          'Create user'
        );
      }

      // Validate email format (use original email for validation message)
      if (!isValidEmail(normalizedEmail)) {
        return handleValidationError(
          res,
          'Invalid email format. Email must be a valid address ending with .com, .co, .in, .org, .net, .edu, .gov, .io, or .info',
          'email',
          'Create user'
        );
      }

      // Validate phone if provided
      if (phone && !isValidPhone(phone)) {
        return handleValidationError(
          res,
          'Invalid phone number. Phone must be 10 digits starting with 6-9, optionally prefixed with +91 or 91',
          'phone',
          'Create user'
        );
      }

      // Validate region (required for non-SYSTEM_ADMIN users)
      if (role !== UserRole.SYSTEM_ADMIN) {
        if (!region) {
          return handleValidationError(
            res,
            'Region is required. Must be SOUTH, NORTH, EAST, WEST_1, WEST_2, or APTOC',
            'region',
            'Create user'
          );
        }
        const validRegions = [Region.SOUTH, Region.NORTH, Region.EAST, Region.WEST_1, Region.WEST_2, Region.APTOC];
        if (!validRegions.includes(region)) {
          return handleValidationError(
            res,
            'Invalid region. Must be SOUTH, NORTH, EAST, WEST_1, WEST_2, or APTOC',
            'region',
            'Create user'
          );
        }
      } else if (region !== undefined && region !== null) {
        // SYSTEM_ADMIN can have null region, but if provided, it must be valid
        const validRegions = [Region.SOUTH, Region.NORTH, Region.EAST, Region.WEST_1, Region.WEST_2, Region.APTOC];
        if (!validRegions.includes(region)) {
          return handleValidationError(
            res,
            'Invalid region. Must be SOUTH, NORTH, EAST, WEST_1, WEST_2, or APTOC',
            'region',
            'Create user'
          );
        }
      }

      // Only SYSTEM_ADMIN can create users (enforced by middleware)
      // Additional check: SYSTEM_ADMIN cannot create another SYSTEM_ADMIN
      if (role === UserRole.SYSTEM_ADMIN) {
        const existingSystemAdmin = await prisma.user.findFirst({
          where: { role: UserRole.SYSTEM_ADMIN, deletedAt: null }
        });

        if (existingSystemAdmin) {
          return handleConflictError(
            res,
            'System Admin already exists. Only one System Admin is allowed.',
            'Create user'
          );
        }
      }

      // Check if user with this email already exists (use normalized email)
      const existingUser = await prisma.user.findUnique({
        where: { email: normalizedEmail, deletedAt: null }
      });

      if (existingUser) {
        return handleConflictError(
          res,
          `User with email ${normalizedEmail} already exists`,
          'Create user'
        );
      }

      // Generate random password
      const generatedPassword = generateUserPassword();
      const passwordHash = await bcrypt.hash(generatedPassword, 10);

      // Create user (store normalized email)
      const user = await prisma.user.create({
        data: {
          name,
          email: normalizedEmail,
          phone,
          passwordHash,
          role,
          region: region || null,
        },
        select: {
          id: true,
          name: true,
          email: true,
          phone: true,
          role: true,
          region: true,
          createdAt: true,
        }
      });

      // Send email with credentials (async, don't wait for it)
      // Use normalized email for sending
      emailService.sendUserCreationEmail({
        name,
        email: normalizedEmail,
        password: generatedPassword,
        role,
      }).catch(error => {
        console.error('Failed to send user creation email:', error);
      });

      // Return user data (without password hash)
      res.status(201).json({
        ...user,
        message: 'User created successfully. Login credentials have been sent to their email.',
      });
    } catch (error) {
      handleError(error, res, 'Create user');
    }
  }

  async getUserById(req: Request, res: Response) {
    try {
      const { id } = req.params;

      if (!id) {
        return handleValidationError(res, 'User ID is required', 'id', 'Get user by ID');
      }

      const userId = parseInt(id);
      if (isNaN(userId)) {
        return handleValidationError(res, 'User ID must be a valid number', 'id', 'Get user by ID');
      }

      const user = await prisma.user.findUnique({
        where: { id: userId, deletedAt: null },
        include: {
          leads: true,
          campaigns: true
        }
      });

      if (!user) {
        return handleNotFoundError(res, 'User', 'Get user by ID');
      }

      res.json(user);
    } catch (error) {
      handleError(error, res, 'Get user by ID');
    }
  }

  async updateUser(req: Request, res: Response) {
    try {
      const { id } = req.params;

      if (!id) {
        return handleValidationError(res, 'User ID is required', 'id', 'Update user');
      }

      const userId = parseInt(id);
      if (isNaN(userId)) {
        return handleValidationError(res, 'User ID must be a valid number', 'id', 'Update user');
      }

      const updateData = req.body;

      // Validate name if being updated
      if (updateData.name !== undefined && !isValidName(updateData.name)) {
        return handleValidationError(
          res,
          'Name must be non-empty (max 255 characters)',
          'name',
          'Update user'
        );
      }

      // Validate email format if email is being updated
      if (updateData.email !== undefined && !isValidEmail(updateData.email)) {
        return handleValidationError(
          res,
          'Invalid email format. Email must be a valid address ending with .com, .co, .in, .org, .net, .edu, .gov, .io, or .info',
          'email',
          'Update user'
        );
      }

      // Validate phone if being updated
      if (updateData.phone !== undefined && updateData.phone && !isValidPhone(updateData.phone)) {
        return handleValidationError(
          res,
          'Invalid phone number. Phone must be 10 digits starting with 6-9, optionally prefixed with +91 or 91',
          'phone',
          'Update user'
        );
      }

      // Validate region if being updated
      if (updateData.region !== undefined && updateData.region !== null) {
        const validRegions = [Region.SOUTH, Region.NORTH, Region.EAST, Region.WEST_1, Region.WEST_2, Region.APTOC];
        if (!validRegions.includes(updateData.region)) {
          return handleValidationError(
            res,
            'Invalid region. Must be SOUTH, NORTH, EAST, WEST_1, WEST_2, or APTOC',
            'region',
            'Update user'
          );
        }
      }

      const user = await prisma.user.update({
        where: { id: userId },
        data: updateData,
      });

      res.json(user);
    } catch (error: any) {
      handleError(error, res, 'Update user');
    }
  }

  async deleteUser(req: Request, res: Response) {
    try {
      const { id } = req.params;

      if (!id) {
        return handleValidationError(res, 'User ID is required', 'id', 'Delete user');
      }

      const userId = parseInt(id);
      if (isNaN(userId)) {
        return handleValidationError(res, 'User ID must be a valid number', 'id', 'Delete user');
      }

      // Soft delete: set deletedAt and deletedBy
      await prisma.user.update({
        where: { id: userId },
        data: {
          deletedAt: new Date(),
          deletedBy: req.user?.id,
        },
      });

      res.status(204).send();
    } catch (error: any) {
      handleError(error, res, 'Delete user');
    }
  }
}
