import { Request, Response } from 'express';
import { prisma } from '@repo/db';
import { recordAuditLog } from '../utils/audit.utils.js';
import * as nodeCrypto from 'node:crypto';

function maskTail(value: string, show: number = 4): string {
  if (!value) return '';
  const tail = value.slice(-show);
  return `****${tail}`;
}

function deriveKey(): Buffer {
  const key = process.env.ENCRYPTION_KEY || '';
  const raw = key.startsWith('base64:') ? Buffer.from(key.slice(7), 'base64')
    : key.startsWith('hex:') ? Buffer.from(key.slice(4), 'hex')
    : Buffer.from(key, 'utf8');
  return raw.length === 32 ? raw : nodeCrypto.createHash('sha256').update(raw).digest();
}

function encryptGCM(plainText: string): { cipherText: string; iv: string; authTag: string } {
  const key = deriveKey();
  const iv = nodeCrypto.randomBytes(12);
  const cipher = nodeCrypto.createCipheriv('aes-256-gcm', key, iv);
  const encrypted = Buffer.concat([cipher.update(plainText, 'utf8'), cipher.final()]);
  const authTag = cipher.getAuthTag();
  return { cipherText: encrypted.toString('base64'), iv: iv.toString('base64'), authTag: authTag.toString('base64') };
}

export const integrationsController = {
  getCredentials: async (_req: Request, res: Response) => {
    const [whatsapp, email] = await Promise.all([
      prisma.integrationCredential.findUnique({ where: { provider: 'whatsapp' } }),
      prisma.integrationCredential.findUnique({ where: { provider: 'email' } }),
    ]);
    res.json({
      whatsapp: { exists: !!whatsapp, masked: whatsapp?.maskedTail ?? null, updatedAt: whatsapp?.updatedAt ?? null },
      email: { exists: !!email, masked: email?.maskedTail ?? null, updatedAt: email?.updatedAt ?? null },
    });
  },

  upsertCredential: async (req: Request, res: Response) => {
    const { provider, apiKey } = req.body as { provider?: 'whatsapp' | 'email'; apiKey?: string };
    if (!provider || !['whatsapp', 'email'].includes(provider)) {
      return res.status(400).json({ error: 'Invalid provider' });
    }
    if (!apiKey || typeof apiKey !== 'string' || apiKey.trim().length < 8) {
      return res.status(400).json({ error: 'Invalid apiKey' });
    }
    const userId = String(req.user?.id ?? 'system');
    const cleaned = apiKey.trim();
    const enc = encryptGCM(cleaned);
    const masked = maskTail(cleaned);
    const existing = await prisma.integrationCredential.findUnique({ where: { provider } });

    await prisma.integrationCredential.upsert({
      where: { provider },
      update: {
        encryptedApiKey: enc.cipherText,
        iv: enc.iv,
        authTag: enc.authTag,
        maskedTail: masked,
        updatedByUserId: userId,
      },
      create: {
        provider,
        encryptedApiKey: enc.cipherText,
        iv: enc.iv,
        authTag: enc.authTag,
        maskedTail: masked,
        updatedByUserId: userId,
      },
    });
    await recordAuditLog({
      action: 'INTEGRATION_CREDENTIAL_UPDATED',
      changedBy: req.user?.id ?? 0,
      entityType: 'INTEGRATION_CREDENTIAL',
      entityId: 0,
      oldValues: existing
        ? {
            provider,
            maskedTail: existing.maskedTail,
            updatedAt: existing.updatedAt,
          }
        : null,
      newValues: {
        provider,
        maskedTail: masked,
      },
    });

    res.status(204).send();
  },

  getConfig: async (_req: Request, res: Response) => {
    const keys = ['email.baseUrl', 'email.webhookSecret', 'whatsapp.source', 'whatsapp.appName'] as const;
    const rows = await prisma.appConfig.findMany({ where: { key: { in: keys as unknown as string[] } } });
    const byKey = Object.fromEntries(rows.map(r => [r.key, r]));
    res.json({
      email: {
        baseUrl: { exists: !!byKey['email.baseUrl'], value: byKey['email.baseUrl']?.plainValue ?? null },
        webhookSecret: { exists: !!byKey['email.webhookSecret'], masked: byKey['email.webhookSecret']?.maskedTail ?? null },
      },
      whatsapp: {
        source: { exists: !!byKey['whatsapp.source'], value: byKey['whatsapp.source']?.plainValue ?? null },
        appName: { exists: !!byKey['whatsapp.appName'], value: byKey['whatsapp.appName']?.plainValue ?? null },
      },
    });
  },

  upsertConfig: async (req: Request, res: Response) => {
    const body = req.body as Partial<{ email: { baseUrl?: string; webhookSecret?: string }; whatsapp: { source?: string; appName?: string } }>;
    const userId = String(req.user?.id ?? 'system');

    const changedBy = req.user?.id ?? 0;
    const oldValues: Record<string, unknown> = {};
    const newValues: Record<string, unknown> = {};
    if (body.email?.baseUrl !== undefined) {
      const existingBaseUrl = await prisma.appConfig.findUnique({ where: { key: 'email.baseUrl' } });
      oldValues['email.baseUrl'] = existingBaseUrl?.plainValue ?? null;
      const nextValue = body.email.baseUrl?.trim() || null;
      newValues['email.baseUrl'] = nextValue;

      await prisma.appConfig.upsert({
        where: { key: 'email.baseUrl' },
        update: { plainValue: nextValue, encryptedValue: null, iv: null, authTag: null, maskedTail: null, updatedByUserId: userId },
        create: { key: 'email.baseUrl', plainValue: nextValue, updatedByUserId: userId },
      });
    }
    if (body.email?.webhookSecret !== undefined) {
      const cleaned = (body.email.webhookSecret || '').trim();
      const existingWebhook = await prisma.appConfig.findUnique({ where: { key: 'email.webhookSecret' } });
      oldValues['email.webhookSecret'] = existingWebhook?.maskedTail ?? null;
      if (cleaned) {
        const enc = encryptGCM(cleaned);
        const masked = maskTail(cleaned);
        newValues['email.webhookSecret'] = masked;
        await prisma.appConfig.upsert({
          where: { key: 'email.webhookSecret' },
          update: { encryptedValue: enc.cipherText, iv: enc.iv, authTag: enc.authTag, maskedTail: masked, plainValue: null, updatedByUserId: userId },
          create: { key: 'email.webhookSecret', encryptedValue: enc.cipherText, iv: enc.iv, authTag: enc.authTag, maskedTail: masked, updatedByUserId: userId },
        });
      } else {
        // Clearing secret
        newValues['email.webhookSecret'] = null;
        await prisma.appConfig.upsert({
          where: { key: 'email.webhookSecret' },
          update: { encryptedValue: null, iv: null, authTag: null, maskedTail: null, plainValue: null, updatedByUserId: userId },
          create: { key: 'email.webhookSecret', plainValue: null, updatedByUserId: userId },
        });
      }
    }
    if (body.whatsapp?.source !== undefined) {
      const existingSource = await prisma.appConfig.findUnique({ where: { key: 'whatsapp.source' } });
      oldValues['whatsapp.source'] = existingSource?.plainValue ?? null;
      const nextSource = body.whatsapp.source?.trim() || null;
      newValues['whatsapp.source'] = nextSource;
      await prisma.appConfig.upsert({
        where: { key: 'whatsapp.source' },
        update: { plainValue: nextSource, encryptedValue: null, iv: null, authTag: null, maskedTail: null, updatedByUserId: userId },
        create: { key: 'whatsapp.source', plainValue: nextSource, updatedByUserId: userId },
      });
    }
    if (body.whatsapp?.appName !== undefined) {
      const existingAppName = await prisma.appConfig.findUnique({ where: { key: 'whatsapp.appName' } });
      oldValues['whatsapp.appName'] = existingAppName?.plainValue ?? null;
      const nextAppName = body.whatsapp.appName?.trim() || null;
      newValues['whatsapp.appName'] = nextAppName;
      await prisma.appConfig.upsert({
        where: { key: 'whatsapp.appName' },
        update: { plainValue: nextAppName, encryptedValue: null, iv: null, authTag: null, maskedTail: null, updatedByUserId: userId },
        create: { key: 'whatsapp.appName', plainValue: nextAppName, updatedByUserId: userId },
      });
    }

    const hasChanges = Object.keys(newValues).length > 0;

    if (hasChanges) {
      await recordAuditLog({
        action: 'INTEGRATION_CONFIG_UPDATED',
        changedBy,
        entityType: 'APP_CONFIG',
        entityId: 0,
        oldValues,
        newValues,
      });
    }

    res.status(204).send();
  },
};


