import { Request, Response } from 'express';
import { prisma } from '@repo/db';
import bcrypt from 'bcryptjs';
import { gstService, GstDetails } from '../services/gst.service.js';
import { smsService } from '../services/sms.service.js';
import { isValidPhone, isValidGstNumber } from '../utils/validators.js';
import {
  handleError,
  handleValidationError,
  handleUnauthorizedError,
} from '../utils/errorHandler.js';

export class SubdealerController {
  /**
   * Fetch GST details by GST number
   * POST /api/subdealer/fetch-gst { gstNumber }
   */
  async fetchGstDetails(req: Request, res: Response) {
    try {
      const { gstNumber } = req.body as { gstNumber?: string };

      if (!gstNumber) {
        return handleValidationError(res, 'GST number is required', 'gstNumber', 'Fetch GST details');
      }

      // Validate GST number format
      if (!isValidGstNumber(gstNumber)) {
        return handleValidationError(
          res,
          'Invalid GST number. GST number must be exactly 15 characters (alphanumeric)',
          'gstNumber',
          'Fetch GST details'
        );
      }

      // Check if GST number already exists
      const existingSubdealer = await prisma.subdealer.findUnique({
        where: { gstNumber: gstNumber.trim().toUpperCase() },
      });

      if (existingSubdealer) {
        return handleValidationError(
          res,
          'GST number already registered',
          'gstNumber',
          'Fetch GST details'
        );
      }

      // Fetch GST details from service
      const gstDetails = await gstService.fetchGstDetails(gstNumber);

      return res.json({
        success: true,
        data: gstDetails,
      });
    } catch (error) {
      handleError(error, res, 'Fetch GST details');
    }
  }

  /**
   * Generate and send OTP to phone number
   * POST /api/subdealer/generate-otp { phone }
   */
  async generateOtp(req: Request, res: Response) {
    try {
      const { phone } = req.body as { phone?: string };

      if (!phone) {
        return handleValidationError(res, 'Phone number is required', 'phone', 'Generate OTP');
      }

      // Normalize phone number (remove +91, 91 prefix, spaces)
      const normalizedPhone = phone.replace(/[\s\+\-\(\)]/g, '').replace(/^91/, '');

      // Validate phone number (10 digits, starting with 6-9)
      if (!isValidPhone(normalizedPhone)) {
        return handleValidationError(
          res,
          'Invalid phone number. Phone must be 10 digits starting with 6-9',
          'phone',
          'Generate OTP'
        );
      }

      // Check if phone already registered
      const existingSubdealer = await prisma.subdealer.findUnique({
        where: { phone: normalizedPhone },
      });

      if (existingSubdealer) {
        return handleValidationError(
          res,
          'Phone number already registered',
          'phone',
          'Generate OTP'
        );
      }

      // Generate 6-digit OTP
      const otp = (Math.floor(100000 + Math.random() * 900000)).toString();
      const otpHash = await bcrypt.hash(otp, 10);

      const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

      // Use transaction to ensure atomicity: invalidate old OTPs and create new one
      // This ensures only the latest OTP is valid (security best practice)
      await prisma.$transaction(async (tx) => {
        // Invalidate all previous unused OTPs for this phone number
        await tx.subdealerOTP.updateMany({
          where: {
            phone: normalizedPhone,
            usedAt: null, // Only invalidate unused OTPs
          },
          data: {
            usedAt: new Date(), // Mark as used to invalidate
          },
        });

        // Create new OTP record
        await tx.subdealerOTP.create({
          data: {
            phone: normalizedPhone,
            otpHash,
            expiresAt,
          },
        });
      });

      // Send OTP via SMS
      const smsSent = await smsService.sendOtp(normalizedPhone, otp);

      if (!smsSent) {
        // In development, log the OTP
        if (process.env.NODE_ENV === 'development') {
          console.log(`[DEV MODE] OTP for ${normalizedPhone}: ${otp}`);
        }
        // Still return success even if SMS fails (in dev mode)
        if (process.env.NODE_ENV !== 'development') {
          return handleError(new Error('Failed to send SMS'), res, 'Generate OTP');
        }
      }

      return res.json({
        success: true,
        message: 'OTP sent successfully',
      });
    } catch (error) {
      handleError(error, res, 'Generate OTP');
    }
  }

  /**
   * Verify OTP and create subdealer
   * POST /api/subdealer/verify-otp { phone, otp, gstDetails }
   */
  async verifyOtpAndRegister(req: Request, res: Response) {
    try {
      const { phone, otp, gstDetails } = req.body as {
        phone?: string;
        otp?: string;
        gstDetails?: GstDetails & { gstNumber: string };
      };

      if (!phone || !otp || !gstDetails) {
        return handleValidationError(
          res,
          'Phone, OTP, and GST details are required',
          undefined,
          'Verify OTP'
        );
      }

      // Normalize phone number
      const normalizedPhone = phone.replace(/[\s\+\-\(\)]/g, '').replace(/^91/, '');

      // Validate phone number
      if (!isValidPhone(normalizedPhone)) {
        return handleValidationError(
          res,
          'Invalid phone number',
          'phone',
          'Verify OTP'
        );
      }

      // Validate GST number
      if (!gstDetails.gstNumber || !isValidGstNumber(gstDetails.gstNumber)) {
        return handleValidationError(
          res,
          'Invalid GST number',
          'gstNumber',
          'Verify OTP'
        );
      }

      // Validate required GST fields
      if (!gstDetails.legalName) {
        return handleValidationError(
          res,
          'Legal name is required',
          'legalName',
          'Verify OTP'
        );
      }

      const normalizedGst = gstDetails.gstNumber.trim().toUpperCase();

      // Early duplicate check (before OTP verification to save resources)
      // But we'll also check again in transaction to prevent race conditions
      const earlyDuplicateCheck = await Promise.all([
        prisma.subdealer.findUnique({
          where: { phone: normalizedPhone },
        }),
        prisma.subdealer.findUnique({
          where: { gstNumber: normalizedGst },
        }),
      ]);

      if (earlyDuplicateCheck[0]) {
        return handleValidationError(
          res,
          'Phone number already registered',
          'phone',
          'Verify OTP'
        );
      }

      if (earlyDuplicateCheck[1]) {
        return handleValidationError(
          res,
          'GST number already registered',
          'gstNumber',
          'Verify OTP'
        );
      }

      // Use transaction to ensure atomicity of OTP verification and registration
      // This prevents race conditions where multiple requests could create duplicate subdealers
      const result = await prisma.$transaction(async (tx) => {
        // Get latest non-used, non-expired OTP record
        const otpRecord = await tx.subdealerOTP.findFirst({
          where: {
            phone: normalizedPhone,
            usedAt: null,
            expiresAt: { gt: new Date() },
          },
          orderBy: { createdAt: 'desc' },
        });

        if (!otpRecord) {
          throw new Error('Invalid or expired OTP');
        }

        // Check attempts
        if (otpRecord.attempts >= 5) {
          throw new Error('Too many attempts. Please request a new OTP');
        }

        // Verify OTP
        const isOtpValid = await bcrypt.compare(otp, otpRecord.otpHash);
        if (!isOtpValid) {
          // Increment attempts
          await tx.subdealerOTP.update({
            where: { id: otpRecord.id },
            data: { attempts: otpRecord.attempts + 1 },
          });
          throw new Error('Invalid OTP');
        }

        // Check for duplicate phone or GST again within transaction (prevents race conditions)
        const duplicateCheck = await Promise.all([
          tx.subdealer.findUnique({
            where: { phone: normalizedPhone },
          }),
          tx.subdealer.findUnique({
            where: { gstNumber: normalizedGst },
          }),
        ]);

        if (duplicateCheck[0]) {
          throw new Error('Phone number already registered');
        }

        if (duplicateCheck[1]) {
          throw new Error('GST number already registered');
        }

        // Create subdealer record
        const subdealer = await tx.subdealer.create({
          data: {
            phone: normalizedPhone,
            gstNumber: normalizedGst,
            email: null, // Email is not available from GST API
            legalName: gstDetails.legalName,
            tradeName: gstDetails.tradeName || null,
            address: gstDetails.address || null,
            city: gstDetails.city || null,
            state: gstDetails.state || null,
            pincode: gstDetails.pincode || null,
            panNumber: gstDetails.panNumber || null,
            registrationDate: gstDetails.registrationDate
              ? new Date(gstDetails.registrationDate)
              : null,
            businessType: gstDetails.businessType || null,
            status: gstDetails.status || null,
            jurisdiction: gstDetails.jurisdiction || null,
            phoneVerified: true,
            verifiedAt: new Date(),
          },
        });

        // Mark OTP as used and link to subdealer
        await tx.subdealerOTP.update({
          where: { id: otpRecord.id },
          data: {
            usedAt: new Date(),
            subdealerId: subdealer.id,
          },
        });

        return subdealer;
      });

      const subdealer = result;

      return res.json({
        success: true,
        message: 'Subdealer registered successfully',
        data: {
          id: subdealer.id,
          phone: subdealer.phone,
          gstNumber: subdealer.gstNumber,
          legalName: subdealer.legalName,
        },
      });
    } catch (error: any) {
      // Handle transaction errors with specific messages
      if (error?.message) {
        if (error.message === 'Invalid or expired OTP') {
          return handleUnauthorizedError(res, 'Invalid or expired OTP', 'Verify OTP');
        }
        if (error.message === 'Too many attempts. Please request a new OTP') {
          return handleUnauthorizedError(res, 'Too many attempts. Please request a new OTP', 'Verify OTP');
        }
        if (error.message === 'Invalid OTP') {
          return handleUnauthorizedError(res, 'Invalid OTP', 'Verify OTP');
        }
        if (error.message === 'Phone number already registered') {
          return handleValidationError(
            res,
            'Phone number already registered',
            'phone',
            'Verify OTP'
          );
        }
        if (error.message === 'GST number already registered') {
          return handleValidationError(
            res,
            'GST number already registered',
            'gstNumber',
            'Verify OTP'
          );
        }
      }
      handleError(error, res, 'Verify OTP and Register');
    }
  }
}

