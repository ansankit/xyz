import { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import { prisma } from '@repo/db';
import { generateToken, generateResetToken, verifyResetToken } from '../utils/jwt.utils.js';
import crypto from 'crypto';
import { emailService } from '../services/email.service.js';
import { recordAuditLog } from '../utils/audit.utils.js';
import { UserRole } from '@prisma/client';
import {
  handleError,
  handleValidationError,
  handleUnauthorizedError,
  handleNotFoundError,
  handleForbiddenError,
  validateRequiredFields,
} from '../utils/errorHandler.js';

const developerEmailConfigured = process.env.DEVELOPER_LOGIN_EMAIL?.trim();
const developerEmailNormalized = developerEmailConfigured ? developerEmailConfigured.toLowerCase() : undefined;
const developerPasswordConfigured = process.env.DEVELOPER_LOGIN_PASSWORD;
const developerNameConfigured = process.env.DEVELOPER_LOGIN_NAME || 'Developer Access';

export class AuthController {
  async login(req: Request, res: Response) {
    try {
      const { email, password } = req.body;

      // Validate required fields
      if (!validateRequiredFields(req.body, ['email', 'password'], res, 'Login')) {
        return;
      }

      // Normalize email: trim whitespace and convert to lowercase for consistent matching
      const normalizedEmail = email.trim().toLowerCase();

      // Find user by email - try normalized email first, then original if different
      let user = await prisma.user.findUnique({
        where: { email: normalizedEmail },
      });

      // If not found with normalized email, try original email (in case it was stored differently)
      if (!user && email.trim() !== normalizedEmail) {
        user = await prisma.user.findUnique({
          where: { email: email.trim() },
        });
      }

      if (!user) {
        return handleUnauthorizedError(res, 'Invalid email or password', 'Login');
      }

      const developerName = (process.env.DEVELOPER_LOGIN_NAME || 'Developer Access').toLowerCase();
      if (
        (developerEmailNormalized && user.email.trim().toLowerCase() === developerEmailNormalized) ||
        (user.role === UserRole.SYSTEM_ADMIN && (user.name || '').toLowerCase() === developerName)
      ) {
        return handleForbiddenError(res, 'Developer access requires the dedicated login route', 'Login');
      }

      // Compare password using bcrypt
      const isPasswordValid = await bcrypt.compare(password, user.passwordHash);

      if (!isPasswordValid) {
        return handleUnauthorizedError(res, 'Invalid email or password', 'Login');
      }

      // Generate JWT token
      const token = generateToken(user.id, user.email);

      // Return user data (excluding password hash) and token
      const userResponse = {
        id: user.id,
        email: user.email,
        name: user.name,
        createdAt: user.createdAt,
        role: user.role
      };

      res.json({
        token,
        user: userResponse,
        isDeveloper: false
      });
    } catch (error) {
      handleError(error, res, 'Login');
    }
  }

  async logout(req: Request, res: Response) {
    try {
      if (req.user?.isDeveloper) {
        await recordAuditLog({
          action: 'DEVELOPER_LOGOUT',
          changedBy: req.user.id,
          entityType: 'DEVELOPER_AUTH',
          entityId: req.user.id,
          oldValues: null,
          newValues: null,
        });
      }

      res.json({
        message: 'Logged out successfully'
      });
    } catch (error) {
      handleError(error, res, 'Logout');
    }
  }

  async getCurrentUser(req: Request, res: Response) {
    try {
      if (!req.user) {
        return handleUnauthorizedError(res, 'User not authenticated', 'Get current user');
      }

      // Fetch full user details from database
      const user = await prisma.user.findUnique({
        where: { id: req.user.id },
      });

      if (!user) {
        return handleNotFoundError(res, 'User', 'Get current user');
      }

      // Return user data (excluding password hash)
      const userResponse = {
        id: user.id,
        email: user.email,
        name: user.name,
        createdAt: user.createdAt,
      role: user.role,
      isDeveloper: req.user?.isDeveloper ?? false
      };

      res.json(userResponse);
    } catch (error) {
      handleError(error, res, 'Get current user');
    }
  }

  async createTestAdmin(req: Request, res: Response) {
    try {
      // Verify secret token for protection
      const { secret } = req.body;
      const expectedSecret = process.env.TEST_ADMIN_SECRET || "1234";

      if (secret !== expectedSecret) {
        return handleForbiddenError(res, 'Invalid secret token', 'Create test admin');
      }

      // Check if test admin already exists
      const existingAdmin = await prisma.user.findUnique({
        where: { email: "superadmin@example.com" }
      });

      if (existingAdmin) {
        return res.status(200).json({
          message: 'Test admin already exists'
        });
      }

      // Create test admin user
      const passwordHash = await bcrypt.hash("admin123", 10);

      await prisma.user.create({
        data: {
          name: "Test Super Admin",
          email: "superadmin@example.com",
          passwordHash,
          role: UserRole.SYSTEM_ADMIN
        }
      });

      res.status(201).json({
        message: 'Test admin created successfully'
      });
    } catch (error) {
      handleError(error, res, 'Create test admin');
    }
  }

  async developerLogin(req: Request, res: Response) {
    try {
      const { email, password } = req.body as { email?: string; password?: string };

      if (!developerEmailConfigured || !developerPasswordConfigured) {
        return handleForbiddenError(res, 'Developer credentials not configured', 'Developer login');
      }

      if (!email || !password) {
        return handleValidationError(res, 'Email and password are required', undefined, 'Developer login');
      }

      const normalizedEmail = email.trim().toLowerCase();

      if (!developerEmailNormalized || normalizedEmail !== developerEmailNormalized) {
        return handleUnauthorizedError(res, 'Invalid developer credentials', 'Developer login');
      }

      if (password !== developerPasswordConfigured) {
        return handleUnauthorizedError(res, 'Invalid developer credentials', 'Developer login');
      }

      let developerUser = await prisma.user.findUnique({
        where: { email: developerEmailConfigured }
      });

      const ensurePasswordHash = async () => bcrypt.hash(developerPasswordConfigured!, 10);

      if (!developerUser) {
        developerUser = await prisma.user.create({
          data: {
            email: developerEmailConfigured,
            name: developerNameConfigured,
            passwordHash: await ensurePasswordHash(),
            role: UserRole.SYSTEM_ADMIN
          }
        });
      } else {
        const updates: Record<string, unknown> = {};

        if (developerUser.role !== UserRole.SYSTEM_ADMIN) {
          updates.role = UserRole.SYSTEM_ADMIN;
        }

        if (developerUser.name !== developerNameConfigured) {
          updates.name = developerNameConfigured;
        }

        const passwordMatches = await bcrypt.compare(
          developerPasswordConfigured!,
          developerUser.passwordHash
        );

        if (!passwordMatches) {
          updates.passwordHash = await ensurePasswordHash();
        }

        if (Object.keys(updates).length > 0) {
          developerUser = await prisma.user.update({
            where: { id: developerUser.id },
            data: updates
          });
        }
      }

      const token = generateToken(developerUser.id, developerUser.email, { isDeveloper: true });

      const userResponse = {
        id: developerUser.id,
        email: developerUser.email,
        name: developerUser.name,
        createdAt: developerUser.createdAt,
        role: developerUser.role
      };

      await recordAuditLog({
        action: 'DEVELOPER_LOGIN',
        changedBy: developerUser.id,
        entityType: 'DEVELOPER_AUTH',
        entityId: developerUser.id,
        oldValues: null,
        newValues: {
          email: developerUser.email,
        },
      });

      res.json({
        token,
        user: userResponse,
        isDeveloper: true
      });
    } catch (error) {
      handleError(error, res, 'Developer login');
    }
  }

  /**
   * Start forgot password: generate OTP and email it
   * POST /api/auth/forgot-password { email }
   */
  async forgotPassword(req: Request, res: Response) {
    try {
      const { email } = req.body as { email?: string };
      if (!email) {
        return handleValidationError(res, 'Email is required', 'email', 'Forgot password');
      }

      const user = await prisma.user.findUnique({ where: { email } });
      if (!user) {
        // Do not reveal existence; respond success
        return res.json({ success: true });
      }

      // Create 6-digit numeric OTP
      const otp = (Math.floor(100000 + Math.random() * 900000)).toString();
      const otpHash = await bcrypt.hash(otp, 10);

      const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

      // Create reset record
      await prisma.passwordReset.create({
        data: {
          userId: user.id,
          otpHash,
          expiresAt,
        },
      });

      const masked = email.replace(/(^.).*(@.*$)/, (_m, a, b) => `${a}***${b}`);
      const subject = 'Your password reset code';
      const body = `Hi ${user.name || user.email},\n\nYour password reset code is: ${otp}\nThis code expires in 10 minutes. If you did not request this, you can ignore this email.\n\nRequested for: ${masked}`;
      await emailService.sendEmail({ to: email, subject, body, name: user.name || user.email });

      return res.json({ success: true });
    } catch (error) {
      handleError(error, res, 'Forgot password');
    }
  }

  /**
   * Verify OTP and return a short-lived reset token
   * POST /api/auth/forgot-password/verify { email, otp }
   */
  async verifyForgotPassword(req: Request, res: Response) {
    try {
      const { email, otp } = req.body as { email?: string; otp?: string };
      if (!email || !otp) {
        return handleValidationError(res, 'Email and otp are required', undefined, 'Verify OTP');
      }

      const user = await prisma.user.findUnique({ where: { email } });
      if (!user) {
        return handleUnauthorizedError(res, 'Invalid code', 'Verify OTP');
      }

      // Get latest non-used, non-expired reset entry
      const record = await prisma.passwordReset.findFirst({
        where: { userId: user.id, usedAt: null, expiresAt: { gt: new Date() } },
        orderBy: { createdAt: 'desc' },
      });

      if (!record) {
        return handleUnauthorizedError(res, 'Invalid or expired code', 'Verify OTP');
      }

      if (record.attempts >= 5) {
        return handleUnauthorizedError(res, 'Too many attempts', 'Verify OTP');
      }

      const ok = await bcrypt.compare(otp, record.otpHash);
      if (!ok) {
        await prisma.passwordReset.update({ where: { id: record.id }, data: { attempts: record.attempts + 1 } });
        return handleUnauthorizedError(res, 'Invalid code', 'Verify OTP');
      }

      // Mark usedAt to prevent reuse of OTP itself, but keep row for jti mapping
      const updated = await prisma.passwordReset.update({ where: { id: record.id }, data: { usedAt: new Date() } });

      // Use record id as jti
      const resetToken = generateResetToken(user.id, String(updated.id), '15m');
      return res.json({ resetToken, expiresIn: 900 });
    } catch (error) {
      handleError(error, res, 'Verify OTP');
    }
  }

  /**
   * Reset password with resetToken
   * POST /api/auth/forgot-password/reset { resetToken, newPassword }
   */
  async resetPassword(req: Request, res: Response) {
    try {
      const { resetToken, newPassword } = req.body as { resetToken?: string; newPassword?: string };
      if (!resetToken || !newPassword) {
        return handleValidationError(res, 'resetToken and newPassword are required', undefined, 'Reset password');
      }
      if (newPassword.length < 8) {
        return handleValidationError(res, 'Password must be at least 8 characters', 'newPassword', 'Reset password');
      }

      const decoded = verifyResetToken(resetToken);

      // Ensure the referenced reset record exists and is not expired beyond grace
      const recId = Number(decoded.jti);
      const rec = await prisma.passwordReset.findUnique({ where: { id: recId } });
      if (!rec || rec.userId !== decoded.userId) {
        return handleUnauthorizedError(res, 'Invalid reset token', 'Reset password');
      }

      const hash = await bcrypt.hash(newPassword, 10);

      await prisma.$transaction([
        prisma.user.update({ where: { id: decoded.userId }, data: { passwordHash: hash } }),
        // Invalidate all outstanding reset requests for user
        prisma.passwordReset.updateMany({ where: { userId: decoded.userId, usedAt: null }, data: { usedAt: new Date() } }),
      ]);

      return res.json({ success: true });
    } catch (error) {
      handleError(error, res, 'Reset password');
    }
  }

  /**
   * Change password for authenticated user
   * POST /api/auth/change-password { currentPassword, newPassword }
   */
  async changePassword(req: Request, res: Response) {
    try {
      if (!req.user) {
        return handleUnauthorizedError(res, 'User not authenticated', 'Change password');
      }
      const { currentPassword, newPassword } = req.body as { currentPassword?: string; newPassword?: string };
      if (!currentPassword || !newPassword) {
        return handleValidationError(res, 'currentPassword and newPassword are required', undefined, 'Change password');
      }
      if (newPassword.length < 8) {
        return handleValidationError(res, 'Password must be at least 8 characters', 'newPassword', 'Change password');
      }

      const user = await prisma.user.findUnique({ where: { id: req.user.id } });
      if (!user) {
        return handleNotFoundError(res, 'User', 'Change password');
      }

      const ok = await bcrypt.compare(currentPassword, user.passwordHash);
      if (!ok) {
        return handleUnauthorizedError(res, 'Current password is incorrect', 'Change password');
      }

      const hash = await bcrypt.hash(newPassword, 10);
      await prisma.user.update({ where: { id: user.id }, data: { passwordHash: hash } });

      return res.json({ success: true });
    } catch (error) {
      handleError(error, res, 'Change password');
    }
  }
}
