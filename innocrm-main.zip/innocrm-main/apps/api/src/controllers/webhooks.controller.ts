import { Request, Response } from "express";
import { handleError } from "../utils/errorHandler.js";
import { prisma, LeadStatus, LeadSource } from "@repo/db";
import { isValidEmail, isValidPhone, isValidName, isValidPincode, validateFieldLength } from "../utils/validators.js";
import { buildFullName, splitFullName } from "../utils/nameHelpers.js";

export class WebhookController {
  async handleLandingiWebhook(req: Request, res: Response) {
    try {
      // Log the received webhook data
      console.log("🎯 Landingi Webhook Received!");
      console.log("📅 Timestamp:", new Date().toISOString());
      console.log("📋 Headers:", JSON.stringify(req.headers, null, 2));
      console.log("📦 Body (Parsed):", JSON.stringify(req.body, null, 2));
      console.log("🔗 Query Parameters:", JSON.stringify(req.query, null, 2));
      console.log("🌐 IP Address:", req.ip || req.connection.remoteAddress);
      console.log("📝 User Agent:", req.get("User-Agent") || "Not provided");
      console.log(
        "🔐 Content Type:",
        req.get("Content-Type") || "Not provided"
      );
      console.log(
        "📏 Content Length:",
        req.get("Content-Length") || "Not provided"
      );

      // Log raw body data for debugging
      console.log("🔍 Raw Request Info:");
      console.log("   - Method:", req.method);
      console.log("   - URL:", req.url);
      console.log(
        "   - Body Keys:",
        req.body ? Object.keys(req.body) : "No body"
      );
      console.log("   - Body Values:", req.body);
      console.log("─".repeat(50));

      // Extract common Landingi webhook fields
      const webhookData = req.body;
      let createdLead = null;
      let createdFormSubmission = null;

      if (webhookData) {
        console.log("📊 Parsed Webhook Data:");

        // Log form submission data if present
        if (webhookData.form_submission) {
          console.log("📝 Form Submission:", webhookData.form_submission);
        }

        // Log lead data if present
        if (webhookData.lead) {
          console.log("👤 Lead Data:", webhookData.lead);
        }

        // Log campaign data if present
        if (webhookData.campaign) {
          console.log("📢 Campaign Data:", webhookData.campaign);
        }

        // Log landing page data if present
        if (webhookData.landing_page) {
          console.log("🌐 Landing Page Data:", webhookData.landing_page);
        }

        // Log custom fields if present
        if (webhookData.custom_fields) {
          console.log("🏷️ Custom Fields:", webhookData.custom_fields);
        }

        // Log any other fields
        const knownFields = [
          "form_submission",
          "lead",
          "campaign",
          "landing_page",
          "custom_fields",
        ];
        const otherFields = Object.keys(webhookData).filter(
          key => !knownFields.includes(key)
        );
        if (otherFields.length > 0) {
          console.log(
            "🔍 Other Fields:",
            otherFields.reduce((acc, key) => {
              acc[key] = webhookData[key];
              return acc;
            }, {} as any)
          );
        }

        // Extract and store lead data
        try {
          const leadData = this.extractLeadDataFromWebhook(webhookData);
          if (leadData) {
            console.log("💾 Attempting to store lead:", leadData);
            createdLead = await this.storeLead(leadData);
            console.log("✅ Lead stored successfully:", createdLead);
          } else {
            console.log("⚠️ No valid lead data found in webhook");
          }
        } catch (leadError) {
          console.error("❌ Error storing lead:", leadError);
          // Don't fail the entire webhook if lead storage fails
        }

        // Extract and store form submission data
        try {
          const formSubmissionData = this.extractFormSubmissionData(
            webhookData,
            createdLead
          );
          if (formSubmissionData) {
            console.log(
              "📝 Attempting to store form submission:",
              formSubmissionData
            );
            createdFormSubmission =
              await this.storeFormSubmission(formSubmissionData);
            console.log(
              "✅ Form submission stored successfully:",
              createdFormSubmission
            );
          } else {
            console.log("⚠️ No valid form submission data found in webhook");
          }
        } catch (formSubmissionError) {
          console.error(
            "❌ Error storing form submission:",
            formSubmissionError
          );
          // Don't fail the entire webhook if form submission storage fails
        }
      }

      console.log("✅ Webhook processed successfully");
      console.log("=".repeat(60));

      // Respond with success status
      res.status(200).json({
        success: true,
        message: "Webhook received and processed successfully",
        timestamp: new Date().toISOString(),
        receivedData: {
          hasBody: !!req.body,
          bodyKeys: req.body ? Object.keys(req.body) : [],
          headers: Object.keys(req.headers),
          queryKeys: Object.keys(req.query),
        },
        leadCreated: !!createdLead,
        leadId: createdLead?.id || null,
        formSubmissionCreated: !!createdFormSubmission,
        formSubmissionId: createdFormSubmission?.id || null,
      });
    } catch (error) {
      console.error("❌ Error processing Landingi webhook:", error);
      console.error(
        "🔍 Error details:",
        error instanceof Error ? error.message : String(error)
      );
      console.error("📋 Request data:", {
        headers: req.headers,
        body: req.body,
        query: req.query,
      });
      console.log("=".repeat(60));

      handleError(error, res, "Process Landingi webhook");
    }
  }

  async testLandingiWebhook(req: Request, res: Response) {
    console.log("🧪 Landingi Webhook Test Endpoint Accessed");
    console.log("📅 Timestamp:", new Date().toISOString());
    console.log("📋 Query Parameters:", JSON.stringify(req.query, null, 2));
    console.log("🌐 IP Address:", req.ip || req.connection.remoteAddress);
    console.log("=".repeat(50));

    res.json({
      success: true,
      message: "Landingi webhook test endpoint is working",
      timestamp: new Date().toISOString(),
      webhookUrl: `${req.protocol}://${req.get("host")}/api/webhook/landingi`,
      instructions:
        "Send POST requests to the webhook URL to test the webhook receiver",
    });
  }

  /**
   * Extract lead data from Landingi webhook payload
   */
  private extractLeadDataFromWebhook(webhookData: any): any | null {
    try {
      // Try to extract from form_submission first (most common)
      if (webhookData.form_submission) {
        const formData = webhookData.form_submission;
        return this.extractLeadFromFormSubmission(formData, webhookData);
      }

      // Try to extract from lead object
      if (webhookData.lead) {
        return this.extractLeadFromLeadObject(webhookData.lead, webhookData);
      }

      // Try to extract from direct webhook fields
      if (webhookData.email || webhookData.name) {
        return this.extractLeadFromDirectFields(webhookData);
      }

      // Try to extract from custom fields
      if (webhookData.custom_fields) {
        return this.extractLeadFromCustomFields(
          webhookData.custom_fields,
          webhookData
        );
      }

      return null;
    } catch (error) {
      console.error("Error extracting lead data:", error);
      return null;
    }
  }

  /**
   * Extract lead data from form submission
   */
  private extractLeadFromFormSubmission(
    formData: any,
    webhookData: any
  ): any | null {
    const leadData: any = {};

    // Extract name
    if (formData.name || formData.first_name || formData.full_name) {
      leadData.name =
        formData.name ||
        formData.full_name ||
        `${formData.first_name || ""} ${formData.last_name || ""}`.trim();
    }

    // Extract email
    if (formData.email) {
      leadData.email = formData.email;
    }

    // Extract phone
    if (formData.phone || formData.phone_number || formData.telephone) {
      leadData.phone =
        formData.phone || formData.phone_number || formData.telephone;
    }

    // Extract company information
    if (
      formData.company ||
      formData.company_name ||
      formData.organization ||
      formData.business_name
    ) {
      leadData.companyName =
        formData.company ||
        formData.company_name ||
        formData.organization ||
        formData.business_name;
    }

    // Extract city
    if (formData.city) {
      leadData.city = formData.city;
    }

    // Extract state
    if (formData.state) {
      leadData.state = formData.state;
    }

    // Extract pincode
    if (
      formData.pincode ||
      formData.pin_code ||
      formData.zipcode ||
      formData.zip_code
    ) {
      leadData.pincode =
        formData.pincode ||
        formData.pin_code ||
        formData.zipcode ||
        formData.zip_code;
    }

    // Set source as LANDING_PAGE (valid enum value)
    leadData.source = "LANDING_PAGE";

    // Set initial status as OPEN (valid enum value)
    leadData.status = "OPEN";

    // Validate required fields
    if (!leadData.name || !leadData.email) {
      console.log("Missing required fields (name or email) in form submission");
      return null;
    }

    return leadData;
  }

  /**
   * Extract lead data from lead object
   */
  private extractLeadFromLeadObject(
    leadData: any,
    webhookData: any
  ): any | null {
    const extractedLead: any = {};

    // Extract name
    if (leadData.name || leadData.first_name || leadData.full_name) {
      extractedLead.name =
        leadData.name ||
        leadData.full_name ||
        `${leadData.first_name || ""} ${leadData.last_name || ""}`.trim();
    }

    // Extract email
    if (leadData.email) {
      extractedLead.email = leadData.email;
    }

    // Extract phone
    if (leadData.phone || leadData.phone_number || leadData.telephone) {
      extractedLead.phone =
        leadData.phone || leadData.phone_number || leadData.telephone;
    }

    // Extract company information
    if (
      leadData.company ||
      leadData.company_name ||
      leadData.organization ||
      leadData.business_name
    ) {
      extractedLead.companyName =
        leadData.company ||
        leadData.company_name ||
        leadData.organization ||
        leadData.business_name;
    }

    // Extract city
    if (leadData.city) {
      extractedLead.city = leadData.city;
    }

    // Extract state
    if (leadData.state) {
      extractedLead.state = leadData.state;
    }

    // Extract pincode
    if (
      leadData.pincode ||
      leadData.pin_code ||
      leadData.zipcode ||
      leadData.zip_code
    ) {
      extractedLead.pincode =
        leadData.pincode ||
        leadData.pin_code ||
        leadData.zipcode ||
        leadData.zip_code;
    }

    // Set source as LANDING_PAGE (valid enum value)
    extractedLead.source = "LANDING_PAGE";

    // Set initial status as OPEN (valid enum value)
    extractedLead.status = leadData.status || "OPEN";

    // Validate required fields
    if (!extractedLead.name || !extractedLead.email) {
      console.log("Missing required fields (name or email) in lead object");
      return null;
    }

    return extractedLead;
  }

  /**
   * Extract lead data from direct webhook fields
   */
  private extractLeadFromDirectFields(webhookData: any): any | null {
    const leadData: any = {};

    // Extract name
    if (webhookData.name || webhookData.first_name || webhookData.full_name) {
      leadData.name =
        webhookData.name ||
        webhookData.full_name ||
        `${webhookData.first_name || ""} ${webhookData.last_name || ""}`.trim();
    }

    // Extract email
    if (webhookData.email) {
      leadData.email = webhookData.email;
    }

    // Extract phone
    if (
      webhookData.phone ||
      webhookData.phone_number ||
      webhookData.telephone
    ) {
      leadData.phone =
        webhookData.phone || webhookData.phone_number || webhookData.telephone;
    }

    // Extract company information
    if (
      webhookData.company ||
      webhookData.company_name ||
      webhookData.organization ||
      webhookData.business_name
    ) {
      leadData.companyName =
        webhookData.company ||
        webhookData.company_name ||
        webhookData.organization ||
        webhookData.business_name;
    }

    // Extract city
    if (webhookData.city) {
      leadData.city = webhookData.city;
    }

    // Extract state
    if (webhookData.state) {
      leadData.state = webhookData.state;
    }

    // Extract pincode
    if (
      webhookData.pincode ||
      webhookData.pin_code ||
      webhookData.zipcode ||
      webhookData.zip_code
    ) {
      leadData.pincode =
        webhookData.pincode ||
        webhookData.pin_code ||
        webhookData.zipcode ||
        webhookData.zip_code;
    }

    // Set source as LANDING_PAGE (valid enum value)
    leadData.source = "LANDING_PAGE";

    // Set initial status as OPEN (valid enum value)
    leadData.status = "OPEN";

    // Validate required fields
    if (!leadData.name || !leadData.email) {
      console.log("Missing required fields (name or email) in direct fields");
      return null;
    }

    return leadData;
  }

  /**
   * Extract lead data from custom fields
   */
  private extractLeadFromCustomFields(
    customFields: any,
    webhookData: any
  ): any | null {
    const leadData: any = {};

    // Extract name from custom fields
    if (
      customFields.name ||
      customFields.first_name ||
      customFields.full_name
    ) {
      leadData.name =
        customFields.name ||
        customFields.full_name ||
        `${customFields.first_name || ""} ${customFields.last_name || ""}`.trim();
    }

    // Extract email from custom fields
    if (customFields.email) {
      leadData.email = customFields.email;
    }

    // Extract phone from custom fields
    if (
      customFields.phone ||
      customFields.phone_number ||
      customFields.telephone
    ) {
      leadData.phone =
        customFields.phone ||
        customFields.phone_number ||
        customFields.telephone;
    }

    // Set source as LANDING_PAGE (valid enum value)
    leadData.source = "LANDING_PAGE";

    // Set initial status as OPEN (valid enum value)
    leadData.status = "OPEN";

    // Validate required fields
    if (!leadData.name || !leadData.email) {
      console.log("Missing required fields (name or email) in custom fields");
      return null;
    }

    return leadData;
  }

  /**
   * Store lead in database
   */
  private async storeLead(leadData: any): Promise<any> {
    try {
      // Validate required fields and formats
      if (!leadData.name || !isValidName(leadData.name)) {
        throw new Error("Invalid or missing name. Name must be non-empty (max 255 characters)");
      }

      if (!leadData.email || !isValidEmail(leadData.email)) {
        throw new Error("Invalid or missing email. Email must be a valid address ending with .com, .co, .in, .org, .net, .edu, .gov, .io, or .info");
      }

      if (leadData.phone && !isValidPhone(leadData.phone)) {
        throw new Error("Invalid phone number. Phone must be 10 digits starting with 6-9, optionally prefixed with +91 or 91");
      }

      if (leadData.pincode && !isValidPincode(leadData.pincode)) {
        throw new Error("Invalid pincode. Pincode must be exactly 6 digits");
      }

      if (leadData.companyName && !validateFieldLength(leadData.companyName, 255)) {
        throw new Error("Company name must be 255 characters or less");
      }

      if (leadData.city && !validateFieldLength(leadData.city, 100)) {
        throw new Error("City must be 100 characters or less");
      }

      if (leadData.state && !validateFieldLength(leadData.state, 100)) {
        throw new Error("State must be 100 characters or less");
      }

      // Check if lead already exists by email
      const existingLead = await prisma.lead.findUnique({
        where: { email: leadData.email },
      });

      // Accept only valid enums
      let enumSource: LeadSource | undefined = undefined;
      let enumStatus: LeadStatus | undefined = undefined;
      if (
        leadData.source &&
        Object.values(LeadSource).includes(leadData.source.toUpperCase())
      ) {
        enumSource = leadData.source.toUpperCase() as LeadSource;
      }
      if (
        leadData.status &&
        Object.values(LeadStatus).includes(leadData.status.toUpperCase())
      ) {
        enumStatus = leadData.status.toUpperCase() as LeadStatus;
      }
      if (
        (leadData.source && !enumSource) ||
        (leadData.status && !enumStatus)
      ) {
        throw new Error(
          `Invalid status/source: status=${leadData.status}, source=${leadData.source}`
        );
      }

      const initialFirstName =
        typeof leadData.firstName === "string"
          ? leadData.firstName.trim()
          : "";
      const initialLastName =
        typeof leadData.lastName === "string"
          ? leadData.lastName.trim()
          : "";
      const legacyName =
        typeof leadData.name === "string" && leadData.name.trim().length > 0
          ? leadData.name
          : undefined;
      const derivedNames = splitFullName(
        legacyName ?? buildFullName(initialFirstName, initialLastName)
      );
      const normalizedFirstName =
        initialFirstName || derivedNames.firstName || "Unknown";
      const normalizedLastNameRaw =
        initialLastName || derivedNames.lastName || "";
      const normalizedLastName =
        normalizedLastNameRaw && normalizedLastNameRaw.trim().length > 0
          ? normalizedLastNameRaw.trim()
          : null;
      leadData.firstName = normalizedFirstName;
      leadData.lastName = normalizedLastName;
      leadData.name = buildFullName(
        normalizedFirstName,
        normalizedLastName
      );

      if (existingLead) {
        console.log(
          "📧 Lead with email already exists, updating:",
          existingLead.id
        );

        // Update existing lead with new information
        const updatedLead = await prisma.lead.update({
          where: { id: existingLead.id },
          data: {
            firstName: normalizedFirstName,
            lastName: normalizedLastName,
            phone: leadData.phone || existingLead.phone,
            companyName: leadData.companyName || existingLead.companyName,
            city: leadData.city || existingLead.city,
            state: leadData.state || existingLead.state,
            pincode: leadData.pincode || existingLead.pincode,
            source: enumSource || existingLead.source,
            status: enumStatus || existingLead.status,
            // Don't update score automatically
          },
          include: {
            owner: true,
          },
        });

        return updatedLead;
      } else {
        console.log("🆕 Creating new lead");

        // Create new lead
        const newLead = await prisma.lead.create({
          data: {
            firstName: normalizedFirstName,
            lastName: normalizedLastName,
            email: leadData.email,
            phone: leadData.phone,
            companyName: leadData.companyName,
            city: leadData.city,
            state: leadData.state,
            pincode: leadData.pincode,
            source: enumSource,
            status: enumStatus,
            score: 0, // Default score
          },
          include: {
            owner: true,
          },
        });

        return newLead;
      }
    } catch (error) {
      console.error("Database error storing lead:", error);
      throw error;
    }
  }

  /**
   * Extract form submission data from webhook payload
   */
  private extractFormSubmissionData(
    webhookData: any,
    createdLead: any
  ): any | null {
    try {
      const formSubmissionData = {
        leadId: createdLead?.id || null,
        contactId: null, // Will be null for new leads
        formData: {
          // Store the entire webhook payload as form data
          webhookData: webhookData,
          extractedAt: new Date().toISOString(),
          source: "Landingi Webhook",
        },
      };

      console.log("📋 Extracted form submission data:", formSubmissionData);
      return formSubmissionData;
    } catch (error) {
      console.error("Error extracting form submission data:", error);
      return null;
    }
  }

  /**
   * Store form submission in database
   */
  private async storeFormSubmission(formSubmissionData: any): Promise<any> {
    try {
      // Create form submission (campaignId is now optional)
      const newFormSubmission = await prisma.formSubmission.create({
        data: {
          leadId: formSubmissionData.leadId,
          contactId: formSubmissionData.contactId,
          formData: formSubmissionData.formData,
        },
        include: {
          lead: true,
          contact: true,
        },
      });

      console.log("✅ Form submission stored successfully");
      return newFormSubmission;
    } catch (error) {
      console.error("Database error storing form submission:", error);
      throw error;
    }
  }
}
