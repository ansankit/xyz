import { Request, Response } from 'express';
import { prisma } from '@repo/db';
import { UserRole, LeadStatus } from '@prisma/client';
import {
  handleError,
  handleUnauthorizedError,
  handleNotFoundError,
  handleForbiddenError,
  handleValidationError,
  validateRequiredFields,
} from '../utils/errorHandler.js';
import { buildFullName } from '../utils/nameHelpers.js';

/**
 * Sales Controller
 * Handles all sales-specific operations
 * Sales users can only:
 * 1. View leads assigned to them
 * 2. Qualify or Disqualify leads
 * 3. Add remarks to leads
 */
export class SalesController {
  /**
   * Get all leads assigned to the current sales user
   */
  async getMyLeads(req: Request, res: Response) {
    try {
      // Ensure user is authenticated
      if (!req.user) {
        return handleUnauthorizedError(res, 'Authentication required', 'Get my leads');
      }

      const userId = req.user.id;

      // Parse query parameters for pagination
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      const skip = (page - 1) * limit;

      // Parse filters
      const status = req.query.status as string | undefined;
      const source = req.query.source as string | undefined;

      // Build where clause
      const whereClause: any = {
        ownerId: userId, // Only show leads assigned to this sales user
      };

      if (status) {
        whereClause.status = status;
      }

      if (source) {
        whereClause.source = source;
      }

      // Get leads with pagination
      const [leads, total] = await Promise.all([
        prisma.lead.findMany({
          where: whereClause,
          include: {
            owner: {
              select: {
                id: true,
                name: true,
                email: true,
                role: true,
              },
            },
            remarks: {
              include: {
                user: {
                  select: {
                    id: true,
                    name: true,
                    email: true,
                  },
                },
              },
              orderBy: {
                createdAt: 'desc',
              },
            },
          },
          skip,
          take: limit,
          orderBy: {
            createdAt: 'desc',
          },
        }),
        prisma.lead.count({ where: whereClause }),
      ]);

      res.json({
        leads,
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
        },
      });
    } catch (error) {
      handleError(error, res, 'Get my leads');
    }
  }

  /**
   * Get a specific lead (only if assigned to this sales user)
   */
  async getLeadById(req: Request, res: Response) {
    try {
      if (!req.user) {
        return handleUnauthorizedError(res, 'Authentication required', 'Get lead by ID');
      }

      const idParam = req.params.id;
      const leadId = parseInt(idParam as string);
      const userId = req.user.id;

      if (isNaN(leadId)) {
        return handleValidationError(res, 'Invalid lead ID', 'id', 'Get lead by ID');
      }

      const lead = await prisma.lead.findFirst({
        where: {
          id: leadId,
          ownerId: userId, // Ensure lead is assigned to this user
        },
        include: {
          owner: {
            select: {
              id: true,
              name: true,
              email: true,
              role: true,
            },
          },
          remarks: {
            include: {
              user: {
                select: {
                  id: true,
                  name: true,
                  email: true,
                },
              },
            },
            orderBy: {
              createdAt: 'desc',
            },
          },
        },
      });

      if (!lead) {
        return handleForbiddenError(
          res,
          'Lead not found or not assigned to you',
          'Get lead by ID'
        );
      }

      res.json(lead);
    } catch (error) {
      handleError(error, res, 'Get lead by ID');
    }
  }

  /**
   * Qualify a lead (change status to QUALIFIED)
   */
  async qualifyLead(req: Request, res: Response) {
    try {
      if (!req.user) {
        return handleUnauthorizedError(res, 'Authentication required', 'Qualify lead');
      }

      const idParam = req.params.id;
      const leadId = parseInt(idParam as string);
      const userId = req.user.id;

      if (isNaN(leadId)) {
        return handleValidationError(res, 'Invalid lead ID', 'id', 'Qualify lead');
      }

      // Check if lead exists and is assigned to this user
      const existingLead = await prisma.lead.findFirst({
        where: {
          id: leadId,
          ownerId: userId,
        },
      });

      if (!existingLead) {
        return handleForbiddenError(
          res,
          'Lead not found or not assigned to you',
          'Qualify lead'
        );
      }

      // Update lead status to QUALIFIED
      const updatedLead = await prisma.lead.update({
        where: { id: leadId },
        data: {
          status: LeadStatus.QUALIFIED,
        },
        include: {
          owner: {
            select: {
              id: true,
              name: true,
              email: true,
              role: true,
            },
          },
        },
      });

      res.json({
        message: 'Lead qualified successfully',
        lead: updatedLead,
      });
    } catch (error) {
      handleError(error, res, 'Qualify lead');
    }
  }

  /**
   * Disqualify a lead (change status to UNQUALIFIED)
   */
  async disqualifyLead(req: Request, res: Response) {
    try {
      if (!req.user) {
        return handleUnauthorizedError(res, 'Authentication required', 'Disqualify lead');
      }

      const idParam = req.params.id;
      const leadId = parseInt(idParam as string);
      const userId = req.user.id;

      if (isNaN(leadId)) {
        return handleValidationError(res, 'Invalid lead ID', 'id', 'Disqualify lead');
      }

      // Check if lead exists and is assigned to this user
      const existingLead = await prisma.lead.findFirst({
        where: {
          id: leadId,
          ownerId: userId,
        },
      });

      if (!existingLead) {
        return handleForbiddenError(res, 'Lead not found or not assigned to you', 'Disqualify lead');
      }

      // Update lead status to UNQUALIFIED
      const updatedLead = await prisma.lead.update({
        where: { id: leadId },
        data: {
          status: LeadStatus.UNQUALIFIED,
        },
        include: {
          owner: {
            select: {
              id: true,
              name: true,
              email: true,
              role: true,
            },
          },
        },
      });

      res.json({
        message: 'Lead disqualified successfully',
        lead: updatedLead,
      });
    } catch (error) {
      console.error('Error disqualifying lead:', error);
      handleError(error, res, 'Disqualify lead');
    }
  }

  /**
   * Add a remark/note to a lead
   */
  async addRemark(req: Request, res: Response) {
    try {
      if (!req.user) {
        return handleUnauthorizedError(res, 'Authentication required', 'Add remark');
      }

      const idParam = req.params.id;
      const leadId = parseInt(idParam as string);
      const userId = req.user.id;
      const { remark } = req.body;

      if (isNaN(leadId)) {
        return handleValidationError(res, 'Invalid lead ID', 'id', 'Add remark');
      }

      if (!remark || remark.trim().length === 0) {
        return handleValidationError(res, 'Remark cannot be empty', 'remark', 'Add remark');
      }

      // Check if lead exists and is assigned to this user
      const existingLead = await prisma.lead.findFirst({
        where: {
          id: leadId,
          ownerId: userId,
        },
      });

      if (!existingLead) {
        return handleForbiddenError(res, 'Lead not found or not assigned to you', 'Add remark');
      }

      // Create remark
      const newRemark = await prisma.leadRemark.create({
        data: {
          leadId,
          userId,
          remark: remark.trim(),
        },
        include: {
          user: {
            select: {
              id: true,
              name: true,
              email: true,
            },
          },
          lead: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              status: true,
            },
          },
        },
      });

      const remarkResponse = {
        ...newRemark,
        lead: newRemark.lead
          ? {
              ...newRemark.lead,
              name: buildFullName(newRemark.lead.firstName, newRemark.lead.lastName),
            }
          : null,
      };

      res.status(201).json({
        message: 'Remark added successfully',
        remark: remarkResponse,
      });
    } catch (error) {
      console.error('Error adding remark:', error);
      handleError(error, res, 'Add remark');
    }
  }

  /**
   * Get all remarks for a specific lead
   */
  async getLeadRemarks(req: Request, res: Response) {
    try {
      if (!req.user) {
        return handleUnauthorizedError(res, 'Authentication required', 'Get lead remarks');
      }

      const leadId = parseInt(String(req.params.id));
      const userId = req.user.id;

      if (isNaN(leadId)) {
        return handleValidationError(res, 'Invalid lead ID', 'id', 'Get lead remarks');
      }

      // Check if lead exists and is assigned to this user
      const existingLead = await prisma.lead.findFirst({
        where: {
          id: leadId,
          ownerId: userId,
        },
      });

      if (!existingLead) {
        return handleForbiddenError(res, 'Lead not found or not assigned to you', 'Get lead remarks');
      }

      // Get all remarks for this lead
      const remarks = await prisma.leadRemark.findMany({
        where: { leadId },
        include: {
          user: {
            select: {
              id: true,
              name: true,
              email: true,
            },
          },
        },
        orderBy: {
          createdAt: 'desc',
        },
      });

      res.json({ remarks });
    } catch (error) {
      console.error('Error fetching remarks:', error);
      handleError(error, res, 'Get lead remarks');
    }
  }

  /**
   * Get statistics for the sales user's leads
   */
  async getMyStats(req: Request, res: Response) {
    try {
      if (!req.user) {
        return handleUnauthorizedError(res, 'Authentication required', 'Get my stats');
      }

      const userId = req.user.id;

      // Get counts by status
      const [
        totalLeads,
        qualifiedLeads,
        unqualifiedLeads,
        workingLeads,
        openLeads,
        convertedLeads,
      ] = await Promise.all([
        prisma.lead.count({ where: { ownerId: userId } }),
        prisma.lead.count({ where: { ownerId: userId, status: LeadStatus.QUALIFIED } }),
        prisma.lead.count({ where: { ownerId: userId, status: LeadStatus.UNQUALIFIED } }),
        prisma.lead.count({ where: { ownerId: userId, status: LeadStatus.WORKING } }),
        prisma.lead.count({ where: { ownerId: userId, status: LeadStatus.OPEN } }),
        prisma.lead.count({
          where: {
            ownerId: userId,
            OR: [
              { convertedToContactId: { not: null } },
              { status: LeadStatus.CONVERTED },
            ],
          },
        }),
      ]);

      res.json({
        stats: {
          totalLeads,
          qualifiedLeads,
          unqualifiedLeads,
          workingLeads,
          openLeads,
          convertedLeads,
          conversionRate: totalLeads > 0 ? ((convertedLeads / totalLeads) * 100).toFixed(2) : '0.00',
          qualificationRate: totalLeads > 0 ? ((qualifiedLeads / totalLeads) * 100).toFixed(2) : '0.00',
        },
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
      handleError(error, res, 'Get my stats');
    }
  }
}

export const salesController = new SalesController();
