/**
 * Validate email address with specific domain requirements
 * Pattern: ^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.(com|co|in|org|net|edu|gov|io|info)$
 */
export function isValidEmail(email: string | null | undefined): boolean {
  if (!email || typeof email !== 'string') {
    return false;
  }
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.(com|co|in|org|net|edu|gov|io|info)$/;
  return emailRegex.test(email.trim());
}

/**
 * Validate Indian phone number
 * Pattern: ^(?:\+91|91)?[6-9]\d{9}$
 * Accepts: +91, 91, or no prefix, followed by 10 digits starting with 6-9
 */
export function isValidPhone(phone: string | null | undefined): boolean {
  if (!phone || typeof phone !== 'string') {
    return false;
  }
  const phoneRegex = /^(?:\+91|91)?[6-9]\d{9}$/;
  return phoneRegex.test(phone.trim());
}

/**
 * Validate name field
 * - Non-empty after trim
 * - Max 255 characters
 */
export function isValidName(name: string | null | undefined): boolean {
  if (!name || typeof name !== 'string') {
    return false;
  }
  const trimmed = name.trim();
  return trimmed.length > 0 && trimmed.length <= 255;
}

/**
 * Validate pincode (6 digits)
 */
export function isValidPincode(pincode: string | null | undefined): boolean {
  if (!pincode || typeof pincode !== 'string') {
    return false;
  }
  const pincodeRegex = /^\d{6}$/;
  return pincodeRegex.test(pincode.trim());
}

/**
 * Validate website URL format (basic validation)
 */
export function isValidWebsite(url: string | null | undefined): boolean {
  if (!url || typeof url !== 'string') {
    return false;
  }
  const trimmed = url.trim();
  if (trimmed.length === 0) {
    return false;
  }
  // Basic URL validation - starts with http:// or https://
  const urlRegex = /^https?:\/\/.+/;
  return urlRegex.test(trimmed);
}

/**
 * Validate field length
 */
export function validateFieldLength(field: string | null | undefined, maxLength: number): boolean {
  if (!field || typeof field !== 'string') {
    return true; // Empty fields are valid for length check (use required check separately)
  }
  return field.trim().length <= maxLength;
}

/**
 * Validate GST number
 * Pattern: 15 characters, alphanumeric
 * Format: 15AABCC1234D1Z5 (2 char state code + 10 char PAN + 3 char entity number + 1 char Z + 1 digit checksum)
 */
export function isValidGstNumber(gst: string | null | undefined): boolean {
  if (!gst || typeof gst !== 'string') {
    return false;
  }
  const trimmed = gst.trim().toUpperCase();
  // GST number should be exactly 15 characters, alphanumeric
  const gstRegex = /^[0-9A-Z]{15}$/;
  return gstRegex.test(trimmed);
}