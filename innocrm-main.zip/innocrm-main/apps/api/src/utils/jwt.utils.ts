import jwt, { SignOptions } from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'fallback-secret-key-change-in-production';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '24h';

export interface JWTPayload {
  userId: number;
  email: string;
  isDeveloper?: boolean;
  iat?: number;
  exp?: number;
}

type GenerateTokenOptions = {
  isDeveloper?: boolean;
};

export function generateToken(
  userId: number,
  email: string,
  options: GenerateTokenOptions = {}
): string {
  const payload: Omit<JWTPayload, 'iat' | 'exp'> = {
    userId,
    email,
    ...(options.isDeveloper ? { isDeveloper: true } : {})
  };

  return jwt.sign(payload, JWT_SECRET, {
    expiresIn: JWT_EXPIRES_IN
  } as jwt.SignOptions);
}

export function verifyToken(token: string): JWTPayload {
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as JWTPayload;
    return decoded;
  } catch (error) {
    if (error instanceof jwt.JsonWebTokenError) {
      throw new Error('Invalid token');
    } else if (error instanceof jwt.TokenExpiredError) {
      throw new Error('Token expired');
    } else {
      throw new Error('Token verification failed');
    }
  }
}

// Scoped tokens (e.g., password reset)
export interface ResetTokenPayload {
  userId: number;
  purpose: 'reset';
  jti: string; // unique id to correlate with reset record
  iat?: number;
  exp?: number;
}

export function generateResetToken(userId: number, jti: string, expiresIn: string = '15m'): string {
  const payload: Omit<ResetTokenPayload, 'iat' | 'exp'> = { userId, purpose: 'reset', jti };
  return jwt.sign(payload, JWT_SECRET, { expiresIn } as SignOptions);
}

export function verifyResetToken(token: string): ResetTokenPayload {
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as ResetTokenPayload;
    if (decoded.purpose !== 'reset') {
      throw new Error('Invalid reset token scope');
    }
    return decoded;
  } catch (error) {
    if (error instanceof jwt.JsonWebTokenError) {
      throw new Error('Invalid token');
    } else if (error instanceof jwt.TokenExpiredError) {
      throw new Error('Token expired');
    } else {
      throw new Error('Token verification failed');
    }
  }
}