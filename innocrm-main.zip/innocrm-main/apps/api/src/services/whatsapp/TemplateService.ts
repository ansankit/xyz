// WhatsApp templates are disabled for now. Provide a no-op service.
export class WhatsappTemplateService {
  async syncTemplates(_messagingAccountId: number) { return []; }
  async listTemplates(_messagingAccountId: number) { return []; }
}


