// WhatsApp sending is disabled for now. Provide a no-op service to satisfy imports.
export class WhatsappSendService {
  async sendCampaign(_campaignId: number, _messagingAccountId: number, _templateId: number) {
    return { queued: 0 };
  }
}


