// Webhook handling is disabled for now.
export class WhatsappWebhookService {
  async handleGupshupEvent(_payload: any) {
    return { ok: false, message: 'WhatsApp disabled' };
  }
}


