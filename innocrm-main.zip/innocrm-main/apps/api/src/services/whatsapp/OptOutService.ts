// Opt-out store is disabled for now. Provide a no-op service.
export class OptOutService {
  async isOptedOut(_channel: string, _address: string): Promise<boolean> { return false; }
  async optOut(_channel: string, _address: string, _reason?: string, _source?: string) { return null as any; }
  async removeOptOut(_channel: string, _address: string) { return null; }
}


