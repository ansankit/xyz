import { Express } from 'express';
import { prisma } from '@repo/db';
import authRoutes from './auth.routes.js';
import userRoutes from './users.routes.js';
import leadRoutes from './leads.routes.js';
import contactRoutes from './contacts.routes.js';
import campaignRoutes from './campaigns.routes.js';
import analyticsRoutes from './analytics.routes.js';
import dashboardRoutes from './dashboard.routes.js';
import webhookRoutes from './webhooks.routes.js';
import brevoRoutes from './brevo.routes.js';
import integrationsRoutes from './integrations.routes.js';
import whatsappRoutes from './whatsapp.routes.js';
import accountRoutes from './accounts.routes.js';
import exportRoutes from './exports.routes.js';
import salesRoutes from './sales.routes.js';
import subdealerRoutes from './subdealer.routes.js';
import productRoutes from './product.routes.js';
import productCategoryRoutes from './productCategory.routes.js';
import keywordRoutes from './keywords.routes.js';
import invoiceRoutes from './invoice.routes.js';
import { requireAuth } from '../middleware/auth.middleware.js';

export function setupRoutes(app: Express) {
  // Health check
  app.get("/health", async (req, res) => {
    try {
      await prisma.$queryRaw`SELECT 1`;
      res.json({ status: "ok", database: "connected" });
    } catch (error) {
      res.status(500).json({ 
        status: "error", 
        database: "disconnected", 
        error: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  // Lightweight keep-alive endpoint (no DB work)
  app.get('/healthz', (req, res) => {
    const token = process.env.KEEPALIVE_TOKEN;
    if (token && req.get('x-keepalive-token') !== token) {
      return res.status(401).send('unauthorized');
    }
    res.set('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
    res.set('Surrogate-Control', 'no-store');
    res.set('Pragma', 'no-cache');
    return res.status(200).send('ok');
  });

  // Mount auth routes (no authentication required)
  app.use('/api/auth', authRoutes);

  // Mount subdealer routes (no authentication required)
  app.use('/api/subdealer', subdealerRoutes);

  // Mount product routes (some public, some protected)
  app.use('/api/products', productRoutes);
  app.use('/api/product-categories', productCategoryRoutes);
  app.use('/api/keywords', keywordRoutes);

  // Mount invoice routes (upload is public, CRUD requires SYSTEM_ADMIN)
  app.use('/api/invoices', invoiceRoutes);

  // Mount protected route modules (require authentication)
  app.use('/api/users', requireAuth, userRoutes);
  app.use('/api/leads', requireAuth, leadRoutes);
  app.use('/api/contacts', requireAuth, contactRoutes);
  app.use('/api/campaigns', requireAuth, campaignRoutes);
  app.use('/api/analytics', requireAuth, analyticsRoutes);
  app.use('/api/brevo', requireAuth, brevoRoutes);
  app.use('/api/whatsapp', requireAuth, whatsappRoutes);
  app.use('/api/dashboard', requireAuth, dashboardRoutes);
  app.use('/api/accounts', requireAuth, accountRoutes);
  app.use('/api/integrations', integrationsRoutes);
  app.use('/api/export', requireAuth, exportRoutes);
  app.use('/api/sales', salesRoutes); // Sales routes have their own auth middleware

  // Mount webhook routes (no authentication required)
  app.use('/api/webhook', webhookRoutes);
}
