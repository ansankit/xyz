import { Router } from 'express';
import { WhatsappController } from '../controllers/whatsapp.controller.js';

const router = Router();
const controller = new WhatsappController();

// Accounts
router.get('/accounts', (req, res) => controller.listAccounts(req, res));
router.post('/accounts', (req, res) => controller.createAccount(req, res));

// Templates
router.get('/templates', (req, res) => controller.listTemplates(req, res));
router.post('/templates/sync', (req, res) => controller.syncTemplates(req, res));

// Campaigns
router.post('/campaigns', (req, res) => controller.createCampaign(req, res));
router.post('/campaigns/:id/send', (req, res) => controller.scheduleOrSend(req, res));
router.get('/deliveries', (req, res) => controller.listDeliveries(req, res));
router.get('/events', (req, res) => controller.listEvents(req, res));

// Webhook moved to /api/webhook/gupshup (unauthenticated)

// Opt-out
router.post('/optout', (req, res) => controller.optOut(req, res));
router.delete('/optout', (req, res) => controller.removeOptOut(req, res));

export default router;


