import { Router } from 'express';
import { WebhookController } from '../controllers/webhooks.controller.js';
import { WhatsappController } from '../controllers/whatsapp.controller.js';

const router = Router();
const webhookController = new WebhookController();
const whatsappController = new WhatsappController();

// POST /api/webhook/landingi
router.post('/landingi', webhookController.handleLandingiWebhook.bind(webhookController));

// GET /api/webhook/landingi/test
router.get('/landingi/test', webhookController.testLandingiWebhook.bind(webhookController));

// POST /api/webhook/gupshup (WhatsApp provider)
router.post('/gupshup', (req, res) => whatsappController.handleWebhook(req, res));

export default router;
