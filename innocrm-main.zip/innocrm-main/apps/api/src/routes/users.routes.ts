import { Router } from 'express';
import { UserController } from '../controllers/users.controller.js';
import { requireAuth, requireRole } from '../middleware/auth.middleware.js';
import { UserRole } from '@prisma/client';

const router = Router();
const userController = new UserController();

// Require authentication for all user routes
router.use(requireAuth);

// GET /api/users -- admin and above
router.get('/', requireRole([UserRole.ADMIN, UserRole.SYSTEM_ADMIN]), userController.getAllUsers);
// POST /api/users -- system admin only
router.post('/', requireRole([UserRole.SYSTEM_ADMIN]), userController.createUser);
// GET user by id -- admin and above
router.get('/:id', requireRole([UserRole.ADMIN, UserRole.SYSTEM_ADMIN]), userController.getUserById);
// PUT user by id -- admin and above
router.put('/:id', requireRole([UserRole.ADMIN, UserRole.SYSTEM_ADMIN]), userController.updateUser);
// Update user permissions (remove entirely as permissions no longer exist)
// DELETE user -- system admin only
router.delete('/:id', requireRole([UserRole.SYSTEM_ADMIN]), userController.deleteUser);

export default router;
