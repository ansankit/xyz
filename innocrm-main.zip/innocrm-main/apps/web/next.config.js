import path from "path";
import { fileURLToPath } from "url";

// Derive __dirname in ESM context
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/** @type {import('next').NextConfig} */
const nextConfig = {
  // Ensure the shared UI package and DB package are transpiled by Next/Turbopack
  transpilePackages: ["@repo/ui", "@repo/db"],

  // Explicitly set the monorepo root to silence the multiple lockfiles warning
  turbopack: {
    root: path.resolve(__dirname, "../../"),
  },

  // Image optimization configuration
  images: {
    // Enable image optimization with Sharp (works perfectly on Vercel)
    formats: ["image/webp", "image/avif"],
    // Configure remote patterns for external images (S3, Cloudinary, etc.)
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '**.s3.*.amazonaws.com',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: '**.amazonaws.com',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: 'res.cloudinary.com',
        pathname: '/**',
      },
    ],
    // Allow all external images (less secure but more flexible)
    // You can restrict this to specific domains for better security
    unoptimized: false,
  },

  // Server configuration
  serverExternalPackages: [],

  // Ignore ESLint during builds to prevent CI failures
  // ESLint should be run separately via `npm run lint`
  eslint: {
    ignoreDuringBuilds: true,
  },

  // Ignore TypeScript errors during builds (optional, but recommended for CI)
  typescript: {
    ignoreBuildErrors: false, // Keep this as false to catch TS errors
  },
};

export default nextConfig;
