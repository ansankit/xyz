"use client"

import React from "react"
import { Badge } from "@repo/ui"
import { Button } from "@repo/ui"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@repo/ui"
import { SearchInput } from "@repo/ui"
import { MoreVertical, User } from "lucide-react"
import { DataTable, TableColumn } from "./data-table"
import { CampaignFilter, CampaignFilterValues } from "./campaign-filter"
import { TableSkeleton, ToolbarSkeleton } from "./skeletons"

export interface Campaign {
  id: string
  name: string
  channel: 'Email' | 'WhatsApp'
  status: string
  startDate: string
  startDateRaw?: string // Raw ISO date string for filtering
  endDate: string
  createdAt?: string
  createdBy: string
  subject?: string
  fromEmail?: string
  replyToEmail?: string
  previewText?: string
  numMessages: number
  openRate: number
  clickRate: number
}

interface ChannelBadgeProps {
  channel: Campaign['channel']
}

const ChannelBadge: React.FC<ChannelBadgeProps> = ({ channel }) => {
  const channelConfig = {
    'Email': { 
      label: 'Email', 
      className: 'bg-blue-100 text-blue-800 hover:bg-blue-100' 
    },
    'WhatsApp': { 
      label: 'WhatsApp', 
      className: 'bg-green-100 text-green-800 hover:bg-green-100' 
    }
  }

  const config = channelConfig[channel] || {
    label: channel,
    className: 'bg-gray-100 text-gray-800 hover:bg-gray-100'
  }

  return (
    <Badge variant="secondary" className={config.className}>
      {config.label}
    </Badge>
  )
}

interface StatusBadgeProps {
  status: string
}

const StatusBadge: React.FC<StatusBadgeProps> = ({ status }) => {
  return (
    <Badge variant="secondary" className="bg-gray-100 text-gray-800 hover:bg-gray-100">
      {status}
    </Badge>
  )
}

interface CampaignTableProps {
  campaigns: Campaign[]
  searchQuery?: string
  filters?: CampaignFilterValues
  channelFilter?: string
  currentPage?: number
  totalPages?: number
  totalCount?: number
  itemsPerPage?: number
  isLoading?: boolean
  onSearchChange?: (value: string) => void
  onFilterChange?: (filters: CampaignFilterValues) => void
  onChannelChange?: (value: string) => void
  onPageChange?: (page: number) => void
  onItemsPerPageChange?: (itemsPerPage: number) => void
  onCampaignClick?: (campaign: Campaign) => void
  onGoToCampaign?: (campaign: Campaign) => void
  onDeleteClick?: (campaign: Campaign) => void
  onEditClick?: (campaign: Campaign) => void
  onCreateClick?: () => void
  title?: string
  subtitle?: string
}

export const CampaignTable: React.FC<CampaignTableProps> = ({ 
  campaigns,
  searchQuery = "",
  filters = {},
  channelFilter = "All Channels",
  currentPage = 1,
  totalPages = 1,
  totalCount = 0,
  itemsPerPage = 10,
  isLoading = false,
  onSearchChange,
  onFilterChange,
  onChannelChange,
  onPageChange,
  onItemsPerPageChange,
  onCampaignClick,
  onGoToCampaign,
  onDeleteClick,
  onEditClick,
  onCreateClick,
  title,
  subtitle
}) => {
  const [showCustomInput, setShowCustomInput] = React.useState(false)
  const [customValue, setCustomValue] = React.useState("")

  const handleItemsPerPageChange = (value: number) => {
    onItemsPerPageChange?.(value)
    setShowCustomInput(false)
    setCustomValue("")
  }

  const handleCustomSubmit = () => {
    const value = parseInt(customValue)
    if (value >= 1 && value <= 100) {
      handleItemsPerPageChange(value)
    }
  }

  // Calculate pagination values
  const startItem = (currentPage - 1) * itemsPerPage + 1
  const endItem = Math.min(currentPage * itemsPerPage, totalCount || campaigns.length)
  
  // Show skeleton when loading
  if (isLoading) {
    return (
      <div className="space-y-6">
        {/* Header Section */}
        <div className="flex items-center justify-between">
          <div className="space-y-2">
            <h1 className="text-3xl font-bold">{title ?? 'Campaign Management'}</h1>
            <p className="text-muted-foreground">{subtitle ?? 'Manage your campaigns'}</p>
          </div>
          {onCreateClick && (
            <Button onClick={onCreateClick}>
              Create Campaign
            </Button>
          )}
        </div>
        <ToolbarSkeleton />
        <div className="rounded-md border">
          <TableSkeleton rows={10} />
        </div>
      </div>
    )
  }
  
  return (
    <div className="space-y-6">
      {/* Header Section */}
      <div className="flex items-center justify-between">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold">{title ?? 'Campaign Management'}</h1>
          <p className="text-muted-foreground">{subtitle ?? 'Manage your campaigns'}</p>
        </div>
        {onCreateClick && (
          <Button onClick={onCreateClick}>
            Create Campaign
          </Button>
        )}
      </div>

      {(() => {
        const columns: TableColumn<Campaign>[] = [
          { key: 'name', label: 'Campaign Name' },
          { key: 'status', label: 'Status', render: (_v, item) => <StatusBadge status={item.status} /> },
          { key: 'createdBy', label: 'Created By', className: 'text-muted-foreground' },
          { key: 'fromEmail', label: 'Email', className: 'text-muted-foreground' },
          { key: 'replyToEmail', label: 'Reply To', className: 'text-muted-foreground' },
          { key: 'startDate', label: 'Start Date', className: 'text-muted-foreground' },
          { key: 'createdAt', label: 'Created At', render: (v) => v ? new Date(v).toLocaleString() : '-', className: 'text-muted-foreground' }
        ]

        const customFilter = (
          <div className="flex items-center gap-4">
            <div className="w-80">
              <SearchInput 
                placeholder="Search campaign..." 
                value={searchQuery}
                onChange={(e) => onSearchChange?.(e.target.value)}
              />
            </div>
            {onFilterChange && (
              <CampaignFilter
                filters={filters}
                onStatusChange={(status) => onFilterChange({ ...filters, status })}
                onStartDateChange={(date) => onFilterChange({ ...filters, startDate: date })}
                onCreatedFromChange={(date) => onFilterChange({ ...filters, createdFrom: date })}
                onCreatedToChange={(date) => onFilterChange({ ...filters, createdTo: date })}
                onClearFilters={() => onFilterChange({})}
                onApplyFilters={(newFilters) => onFilterChange(newFilters)}
              />
            )}
          </div>
        )

        const renderActions = (item: Campaign) => {
          const isDraft = item.status?.toLowerCase() === 'draft';
          return (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="sm"
                  className="h-8 w-8 p-0"
                  onClick={(e: React.MouseEvent) => e.stopPropagation()}
                >
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {!isDraft && (
                  <DropdownMenuItem onSelect={() => onCampaignClick?.(item)}>
                    View Details
                  </DropdownMenuItem>
                )}
                <DropdownMenuItem onSelect={() => onGoToCampaign?.(item)}>
                  Go to Campaign
                </DropdownMenuItem>
                {isDraft && (
                  <DropdownMenuItem className="text-red-600" onSelect={() => onDeleteClick?.(item)}>
                    Delete
                  </DropdownMenuItem>
                )}
                {!isDraft && (
                  <DropdownMenuItem onSelect={() => onEditClick?.(item)}>
                    Edit
                  </DropdownMenuItem>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          );
        }

        return (
          <DataTable
            data={campaigns}
            columns={columns}
            title={title ?? 'Campaigns'}
            count={totalCount || campaigns.length}
            customActions={renderActions}
            onNameClick={(item) => onCampaignClick?.(item)}
            getRowHref={(campaign) => `/campaigns/${campaign.channel.toLowerCase()}/${campaign.id}`}
            currentPage={currentPage}
            totalPages={totalPages}
            itemsPerPage={itemsPerPage}
            onPageChange={onPageChange}
            onItemsPerPageChange={onItemsPerPageChange}
            showFilter={true}
            customFilter={customFilter}
            searchQuery={searchQuery}
            isSearchMode={Boolean(searchQuery)}
          />
        )
      })()}
    </div>
  )
}

