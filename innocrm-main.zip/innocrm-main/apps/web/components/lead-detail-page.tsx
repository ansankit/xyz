"use client";

import * as React from "react";
import Link from "next/link";
import {
  DetailPageHeader,
  DetailCard,
  ActivityItem,
  LeadScore,
  QuickAction,
  InfoField,
  InfoGrid,
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  Label,
  Button,
  Badge,
  
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
  TabsContents,
  DeleteConfirmationDialog,
} from "@repo/ui";
import { Select, SelectTrigger, SelectContent, SelectItem, SelectValue } from "@repo/ui/components/ui/select" 
import {
  ArrowLeft,
  Edit,
  Trash2,
  ArrowRightLeft,
  Mail,
  MessageCircle,
  Plus,
  User,
  Building2,
  ChevronDown,
} from "lucide-react";
import { toast } from "sonner";
import { useRouter } from "next/navigation";
import {
  useAnalyticsByLead,
  useCreateAnalyticsEvent,
} from "../hooks/useAnalytics";
import { useFormSubmissionsByLead } from "../hooks/useFormSubmissions";
import {
  useLead,
  useUpdateLead,
  useDeleteLead,
  useConvertLead,
} from "../hooks/useLeads";
import { useContact } from "../hooks/useContacts";
import { useUsers } from "../hooks/useUsers";
import { useAccount } from "../hooks/useAccounts";
import { Lead, Contact, Account } from "../lib/api/types";
import EditLeadModal from "./EditLeadModal";
import { KeywordSelect } from "./keyword-select";
import { getLeadStatusConfig, getLeadSourceLabel } from "../lib/status-config";
import { LeadSource } from "@prisma/client";
import type { LeadStatus as PrismaLeadStatus } from "@prisma/client";
import { validateEmail, validatePhone, validateName } from "../lib/validation";
import { getLeadFullName } from "../lib/name";
import { ActivityFeedSkeleton, DetailHeaderSkeleton, DetailSidebarSkeleton, SectionSkeleton, TableSkeleton } from "./skeletons";

interface LeadDetailPageProps {
  leadId: number;
  onBack?: () => void;
  onEdit?: () => void;
  onDelete?: () => void;
  onConvert?: () => void;
  onSendEmail?: () => void;
  onSendWhatsApp?: () => void;
  onCreateAccount?: () => void;
  onLinkAccount?: () => void;
  onCreateContact?: () => void;
  onLinkContact?: () => void;
}

export function LeadDetailPage({
  leadId,
  onBack,
  onEdit,
  onDelete,
  onConvert,
  onSendEmail,
  onSendWhatsApp,
  onCreateAccount,
  onLinkAccount,
  onCreateContact,
  onLinkContact,
}: LeadDetailPageProps) {
  const router = useRouter();
  const [activeTab, setActiveTab] = React.useState("details");
  const [accountContactTab, setAccountContactTab] = React.useState("accounts");
  const [isEditing, setIsEditing] = React.useState(false);
  const [showConvertDialog, setShowConvertDialog] = React.useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = React.useState(false);
  const [convertData, setConvertData] = React.useState({
    keywordIds: [] as number[],
  });

  // API hooks - ALL hooks must be called in the same order every time
  const {
    data: lead,
    isLoading: leadLoading,
    error: leadError,
  } = useLead(leadId);
  const updateLeadMutation = useUpdateLead();
  const deleteLeadMutation = useDeleteLead();
  const convertLeadMutation = useConvertLead();

  // Fetch contact and account if lead is converted
  // Note: Account details are now included in the lead response from backend
  const contact = lead?.convertedToContact;
  const account = contact?.account;

  // Analytics hooks
  const { data: analyticsEvents = [], isLoading: analyticsLoading } =
    useAnalyticsByLead(leadId);
  const createAnalyticsEvent = useCreateAnalyticsEvent();
  const { data: formSubmissions = [], isLoading: submissionsLoading } =
    useFormSubmissionsByLead(leadId);

  // Local state for editing
  const [editedLead, setEditedLead] = React.useState<Partial<Lead>>({});
  const { data: usersData } = useUsers();

  // Update edited lead when lead data changes, but only if not currently editing
  React.useEffect(() => {
    if (lead && !isEditing) {
      setEditedLead(lead);
    }
  }, [lead, isEditing]);

  // Initialize edited lead when entering edit mode
  React.useEffect(() => {
    if (isEditing && lead) {
      setEditedLead(lead);
    }
  }, [isEditing, lead]);

  // All other hooks and state must be called before any early returns
  const handleCreateEvent = async (eventType: string, eventData: any) => {
    try {
      await createAnalyticsEvent.mutateAsync({
        leadId,
        eventType,
        eventData,
        campaignId: undefined,
        contactId: undefined,
      });
    } catch (error) {
      console.error("Failed to create analytics event:", error);
    }
  };

  const [showEditModal, setShowEditModal] = React.useState(false);
  const handleEdit = () => {
    setShowEditModal(true);
  };

  const handleSave = async () => {
    // Basic validation
    if (!editedLead.firstName?.trim()) {
      toast.error("Lead first name is required");
      return;
    }
    if (!editedLead.email?.trim()) {
      toast.error("Email is required");
      return;
    }
    // Validate fields before saving
    const firstNameValidation = validateName(editedLead.firstName || "");
    if (!firstNameValidation.isValid) {
      toast.error(firstNameValidation.error || "Invalid first name");
      return;
    }

    if (editedLead.lastName && editedLead.lastName.trim()) {
      const lastNameValidation = validateName(editedLead.lastName);
      if (!lastNameValidation.isValid) {
        toast.error(lastNameValidation.error || "Invalid last name");
        return;
      }
    }

    const trimmedLastName =
      editedLead.lastName && editedLead.lastName.trim().length > 0
        ? editedLead.lastName.trim()
        : null;

    const emailValidation = validateEmail(editedLead.email || "");
    if (!emailValidation.isValid) {
      toast.error(emailValidation.error || "Invalid email address");
      return;
    }

    const phoneValidation = validatePhone(editedLead.phone || "");
    if (!phoneValidation.isValid) {
      toast.error(phoneValidation.error || "Invalid phone number");
      return;
    }

    try {
      console.log("Attempting to update lead:", {
        leadId,
        data: editedLead,
        originalLead: lead,
      });

      // Ensure we have the required fields
      const updateData = {
        firstName: editedLead.firstName,
        lastName: trimmedLastName,
        email: editedLead.email,
        phone: editedLead.phone,
        companyName: editedLead.companyName,
        source: editedLead.source,
        status: editedLead.status,
        ownerId: (editedLead as any).ownerId ?? (lead as any)?.ownerId,
      };

      console.log("Sending update data:", updateData);

      const result = await updateLeadMutation.mutateAsync({
        id: leadId,
        data: updateData,
      });

      console.log("Lead update successful:", result);
      setIsEditing(false);
      toast.success("Lead updated successfully!");
      onEdit?.();
    } catch (error) {
      console.error("Failed to update lead - Full error details:", {
        error,
        errorMessage: error instanceof Error ? error.message : "Unknown error",
        errorStack: error instanceof Error ? error.stack : "No stack trace",
        leadId,
        editedLead,
        originalLead: lead,
      });
      toast.error(
        `Failed to update lead: ${error instanceof Error ? error.message : "Unknown error"}`
      );
    }
  };

  const handleCancel = () => {
    setIsEditing(false);
    if (lead) {
      setEditedLead(lead); // Reset to original values
    }
  };

  const handleFieldChange = (field: keyof Lead, value: string) => {
    setEditedLead(prev => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleConvert = () => {
    setShowConvertDialog(true);
  };

  const handleDelete = () => {
    setShowDeleteDialog(true);
  };

  const handleConvertConfirm = async () => {
    try {
      console.log("Converting lead:", { leadId, convertData });
      const result = await convertLeadMutation.mutateAsync({
        id: leadId,
        data: convertData,
      });
      console.log("Lead conversion successful:", result);
      setShowConvertDialog(false);
      toast.success("Lead converted to contact successfully!");
      onConvert?.();
    } catch (error) {
      console.error("Failed to convert lead:", error);
      toast.error(
        `Failed to convert lead: ${error instanceof Error ? error.message : "Unknown error"}`
      );
    }
  };

  const handleDeleteConfirm = async () => {
    try {
      await deleteLeadMutation.mutateAsync(leadId);
      setShowDeleteDialog(false);
      toast.success("Lead deleted successfully!");
      onDelete?.();
      // Navigate away to prevent refetching a deleted lead (404)
      router.push("/leads/lead-master");
    } catch (error) {
      console.error("Failed to delete lead:", error);
      // Don't close the dialog on error so user can try again
      const errorMessage =
        error instanceof Error ? error.message : "Unknown error";
      // Check if it's a 404 error (lead already deleted)
      if (errorMessage.includes("404") || errorMessage.includes("not found")) {
        toast.error("Lead has already been deleted");
        setShowDeleteDialog(false);
        router.push("/leads/lead-master");
      } else {
        toast.error(`Failed to delete lead: ${errorMessage}`);
      }
    }
  };

  const handleSendEmail = () => {
    try {
      onSendEmail?.();
      toast.success("Email sent successfully!");
    } catch (error) {
      console.error("Failed to send email:", error);
      toast.error("Failed to send email. Please try again.");
    }
  };

  const handleSendWhatsApp = () => {
    try {
      onSendWhatsApp?.();
      toast.success("WhatsApp message sent successfully!");
    } catch (error) {
      console.error("Failed to send WhatsApp message:", error);
      toast.error("Failed to send WhatsApp message. Please try again.");
    }
  };

  const handleAccountClick = () => {
    if (account?.id) {
      router.push(`/accounts/${account.id}`);
    }
  };

  const handleContactClick = () => {
    if (contact?.id) {
      router.push(`/contacts/${contact.id}`);
    }
  };

  const getStatusVariant = (status: string) => {
    const normalized = String(
      status || ""
    ).toUpperCase() as unknown as PrismaLeadStatus;
    const config = getLeadStatusConfig(normalized);
    return config?.variant || "secondary";
  };

  const actions = React.useMemo(() => {
    const actionList = [];

    if (onConvert && !lead?.convertedToContactId) {
      actionList.push({
        label: convertLeadMutation.isPending ? "Converting..." : "Convert",
        icon: <ArrowRightLeft className="h-4 w-4" />,
        onClick: handleConvert,
        variant: "outline" as const,
        disabled: convertLeadMutation.isPending,
      });
    }

    if (onDelete) {
      actionList.push({
        label: deleteLeadMutation.isPending ? "Deleting..." : "Delete",
        icon: <Trash2 className="h-4 w-4" />,
        onClick: handleDelete,
        variant: "destructive" as const,
        disabled: deleteLeadMutation.isPending,
      });
    }

    return actionList;
  }, [
    lead?.status,
    onConvert,
    onEdit,
    onDelete,
    convertLeadMutation.isPending,
    deleteLeadMutation.isPending,
  ]);

  // Loading and error states - AFTER all hooks are called
  if (leadLoading) {
    return (
      <div className="min-h-screen bg-gray-50 p-6 space-y-6">
        <DetailHeaderSkeleton />
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-6">
            <SectionSkeleton>
              <TableSkeleton rows={4} />
            </SectionSkeleton>
            <SectionSkeleton>
              <TableSkeleton rows={3} />
            </SectionSkeleton>
            <ActivityFeedSkeleton items={4} />
          </div>
          <div className="space-y-6">
            <DetailSidebarSkeleton />
            <DetailSidebarSkeleton items={3} />
          </div>
        </div>
      </div>
    );
  }

  if (leadError || !lead) {
    return (
      <div className="min-h-screen bg-gray-50 p-6 flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600 mb-4">Failed to load lead details</p>
          <Button onClick={onBack} variant="outline">
            Go Back
          </Button>
        </div>
      </div>
    );
  }

  const currentFirstName =
    editedLead.firstName ?? lead?.firstName ?? "";
  const currentLastName =
    editedLead.lastName ?? lead?.lastName ?? "";
  const displayName = getLeadFullName(currentFirstName, currentLastName);

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      {/* @ts-ignore */}
      <DetailPageHeader
        title={displayName}
        status={editedLead.status || lead?.status || "Unknown"}
        statusVariant={getStatusVariant(
          editedLead.status || lead?.status || "Unknown"
        )}
        onBack={onBack}
        actions={actions}
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Lead Details Card */}
          {/* @ts-ignore */}
          <DetailCard
            title="Lead Details"
            headerActions={
              onEdit ? (
                <Button
                  variant="outline"
                  onClick={handleEdit}
                  className="gap-2"
                >
                  <Edit className="h-4 w-4" /> Edit
                </Button>
              ) : undefined
            }
            className="border shadow-sm"
          >
            {/* @ts-ignore */}
            <InfoGrid columns={2}>
              {/* @ts-ignore */}
              <InfoField
                key={`name-${isEditing}`}
                label="Lead Name"
                value={displayName || "N/A"}
                editable={false}
              />
              {/* @ts-ignore */}
              <InfoField
                key={`company-${isEditing}`}
                label="Company"
                value={
                  isEditing
                    ? editedLead.companyName || ""
                    : lead?.companyName || "N/A"
                }
                editable={isEditing}
                onChange={value => handleFieldChange("companyName", value)}
              />
              {/* Assigned To field with editable dropdown */}
              {isEditing ? (
                <div className="space-y-1.5">
                  {/* @ts-ignore */}
                  <Label className="text-sm tracking-wide font-bold">
                    Assigned To
                  </Label>
                  {/* @ts-ignore */}
                  <Select
                    value={(editedLead as any).ownerId ? String((editedLead as any).ownerId) : "__unassigned__"}
                    onValueChange={(v) => handleFieldChange("ownerId" as any, v === "__unassigned__" ? "" : String(parseInt(v)))}
                  >
                    <SelectTrigger className="h-9">
                      <SelectValue placeholder="Unassigned" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="__unassigned__">Unassigned</SelectItem>
                      {(usersData || []).map((u: any) => (
                        <SelectItem key={u.id} value={String(u.id)}>
                          {u.name || u.email}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              ) : (
                // @ts-ignore
                <InfoField
                  key="assigned"
                  label="Assigned To"
                  value={lead?.owner?.name || "N/A"}
                  editable={false}
                />
              )}
              {!isEditing && (
                // @ts-ignore
                <InfoField
                  key="assigned-on"
                  label="Assigned On"
                  value={
                    lead?.assignedAt
                      ? new Date(lead.assignedAt).toLocaleString("en-GB", {
                          day: "2-digit",
                          month: "2-digit",
                          year: "2-digit",
                          hour: "2-digit",
                          minute: "2-digit",
                          hour12: true,
                        })
                      : "Not assigned yet"
                  }
                  editable={false}
                />
              )}
              {/* @ts-ignore */}
              <InfoField
                key={`email-${isEditing}`}
                label="Email"
                value={
                  isEditing ? editedLead.email || "" : lead?.email || "N/A"
                }
                editable={isEditing}
                onChange={value => handleFieldChange("email", value)}
              />
              {/* @ts-ignore */}
              <InfoField
                key={`phone-${isEditing}`}
                label="Phone"
                value={
                  isEditing ? editedLead.phone || "" : lead?.phone || "N/A"
                }
                editable={isEditing}
                onChange={value => handleFieldChange("phone", value)}
              />
              {/* Source field with editable dropdown */}
              {isEditing ? (
                <div className="space-y-1.5">
                  {/* @ts-ignore */}
                  <Label className="text-sm font-medium tracking-wide font-bold">
                    Source
                  </Label>
                  {/* @ts-ignore */}
                  <Select
                    value={editedLead.source || undefined}
                    onValueChange={(v) => handleFieldChange("source", v)}
                  >
                    <SelectTrigger className="h-9">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={String(LeadSource.MANUAL)}>Manual</SelectItem>
                      <SelectItem value={String(LeadSource.IMPORT)}>Import</SelectItem>
                      <SelectItem value={String(LeadSource.LANDING_PAGE)}>Landing Page</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              ) : (
                // @ts-ignore
                <InfoField
                  key="source"
                  label="Source"
                  value={lead?.source ? getLeadSourceLabel(lead.source) : "N/A"}
                  editable={false}
                />
              )}
              {/* @ts-ignore */}
              <InfoField
                key="created"
                label="Created At"
                value={lead?.createdAt ? new Date(lead.createdAt).toLocaleString('en-GB', {
                  day: '2-digit',
                  month: '2-digit',
                  year: '2-digit',
                  hour: '2-digit',
                  minute: '2-digit',
                  hour12: true
                }) : "N/A"}
                editable={false}
              />
            </InfoGrid>
            {/* Footer actions moved to header for a cleaner UI */}
          </DetailCard>

          {/* Activity Timeline Card */}
          {/* @ts-ignore */}
          <DetailCard
            title="Activity Timeline"
            headerActions={
              <>
                <Select defaultValue="all" onValueChange={() => {}}>
                  <SelectTrigger className="h-9">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Activities</SelectItem>
                    <SelectItem value="recent">Recent</SelectItem>
                    <SelectItem value="emails">Emails</SelectItem>
                    <SelectItem value="calls">Calls</SelectItem>
                  </SelectContent>
                </Select>
              </>
            }
          >
            <div className="space-y-0">
              {lead.activities && lead.activities.length > 0 ? (
                lead.activities.map((activity: any) => (
                  <React.Fragment key={activity.id}>
                    {/* @ts-ignore */}
                    <ActivityItem
                      title={activity.title || "Activity"}
                      description={
                        activity.description || "No description available"
                      }
                      time={activity.time || "Unknown time"}
                    />
                  </React.Fragment>
                ))
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <p>No activities recorded yet</p>
                </div>
              )}
            </div>
          </DetailCard>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Account & Contact Card */}
          {/* @ts-ignore */}
          <Card>
            {/* @ts-ignore */}
            <CardHeader>
              <div className="flex items-center justify-center">
                {/* @ts-ignore */}
                <Tabs
                  value={accountContactTab}
                  onValueChange={setAccountContactTab}
                >
                  {/* @ts-ignore */}
                  <TabsList className="gap-16">
                    {/* @ts-ignore */}
                    <TabsTrigger value="accounts">Accounts</TabsTrigger>
                    {/* @ts-ignore */}
                    <TabsTrigger value="contacts">Contacts</TabsTrigger>
                  </TabsList>
                </Tabs>
              </div>
            </CardHeader>
            {/* @ts-ignore */}
            <CardContent>
              <Tabs
                value={accountContactTab}
                onValueChange={setAccountContactTab}
              >
                {/* @ts-ignore */}
                <TabsContent value="accounts">
                  {lead?.convertedToContactId ? (
                    account ? (
                      <div className="space-y-3">
                        <Link
                          href={`/leads/accounts/${account.id}`}
                          prefetch={true}
                          className="flex items-center justify-between p-3 border rounded-lg cursor-pointer hover:bg-gray-50 transition-colors block"
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                              <Building2 className="h-5 w-5 text-blue-600" />
                            </div>
                            <div>
                              <h4 className="font-medium text-blue-600 hover:text-blue-800">
                                {account.name || "N/A"}
                              </h4>
                              <p className="text-sm text-muted-foreground">
                                {account.industry || "N/A"}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-sm">
                              {account.website || "N/A"}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              {account.phone || "N/A"}
                            </p>
                            <p className="text-xs text-blue-600 mt-1">
                              Click to view details
                            </p>
                          </div>
                        </Link>
                        {/* Keywords Display */}
                        {lead?.keywords && lead.keywords.length > 0 && (
                          <div className="flex flex-wrap gap-2 mt-3">
                            {lead.keywords.map((leadKeyword) => (
                              <Badge
                                key={leadKeyword.id}
                                variant="secondary"
                                className="text-xs"
                              >
                                #{leadKeyword.keyword.name}
                              </Badge>
                            ))}
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <div className="w-16 h-16 bg-gray-200 rounded-full mx-auto mb-4 flex items-center justify-center">
                          <Building2 className="h-8 w-8 text-gray-400" />
                        </div>
                        <h3 className="font-medium mb-2">No Account Linked</h3>
                        <p className="text-sm text-muted-foreground mb-4">
                          The converted contact is not associated with any
                          account.
                        </p>
                      </div>
                    )
                  ) : (
                    <div className="text-center py-8">
                      <div className="w-16 h-16 bg-gray-200 rounded-full mx-auto mb-4 flex items-center justify-center">
                        <Building2 className="h-8 w-8 text-gray-400" />
                      </div>
                      <h3 className="font-medium mb-2">Lead Not Converted</h3>
                      <p className="text-sm text-muted-foreground mb-4">
                        This lead has not been converted yet. Convert the lead
                        to create a contact and optionally link to an account.
                      </p>
                    </div>
                  )}
                </TabsContent>
                {/* @ts-ignore */}
                <TabsContent value="contacts">
                  {lead?.convertedToContactId ? (
                    contact ? (
                      <div className="space-y-3">
                        <Link
                          href={`/leads/contacts/${contact.id}`}
                          prefetch={true}
                          className="flex items-center justify-between p-3 border rounded-lg cursor-pointer hover:bg-gray-50 transition-colors block"
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                              <User className="h-5 w-5 text-green-600" />
                            </div>
                            <div>
                              <h4 className="font-medium text-green-600 hover:text-green-800">
                                {contact.name || "N/A"}
                              </h4>
                              <p className="text-sm text-muted-foreground">
                                {contact.position || "N/A"}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-sm">{contact.email || "N/A"}</p>
                            <p className="text-sm text-muted-foreground">
                              {contact.phone || "N/A"}
                            </p>
                            <p className="text-xs text-green-600 mt-1">
                              Click to view details
                            </p>
                          </div>
                        </Link>
                        {/* Keywords Display */}
                        {lead?.keywords && lead.keywords.length > 0 && (
                          <div className="flex flex-wrap gap-2 mt-3">
                            {lead.keywords.map((leadKeyword) => (
                              <Badge
                                key={leadKeyword.id}
                                variant="secondary"
                                className="text-xs"
                              >
                                #{leadKeyword.keyword.name}
                              </Badge>
                            ))}
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <div className="w-16 h-16 bg-gray-200 rounded-full mx-auto mb-4 flex items-center justify-center">
                          <User className="h-8 w-8 text-gray-400" />
                        </div>
                        <h3 className="font-medium mb-2">Contact Not Found</h3>
                        <p className="text-sm text-muted-foreground mb-4">
                          The converted contact could not be loaded.
                        </p>
                      </div>
                    )
                  ) : (
                    <div className="text-center py-8">
                      <div className="w-16 h-16 bg-gray-200 rounded-full mx-auto mb-4 flex items-center justify-center">
                        <User className="h-8 w-8 text-gray-400" />
                      </div>
                      <h3 className="font-medium mb-2">Lead Not Converted</h3>
                      <p className="text-sm text-muted-foreground mb-4">
                        This lead has not been converted yet. Convert the lead
                        to create a contact.
                      </p>
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          {/* Lead Score Card */}
          {/* @ts-ignore */}
          {/* <Card>
            <CardHeader>
              <CardTitle className="text-lg">Lead Score</CardTitle>
            </CardHeader>
            <CardContent>
              <LeadScore
                score={lead.score}
                maxScore={100}
                description="High quality lead based on engagement"
              />
            </CardContent>
          </Card> */}

          {/* Quick Actions Card */}
          {/* @ts-ignore */}
          <Card>
            {/* @ts-ignore */}
            <CardHeader>
              {/* @ts-ignore */}
              <CardTitle className="text-lg">Quick Actions</CardTitle>
            </CardHeader>
            {/* @ts-ignore */}
            <CardContent className="space-y-2">
              {/* @ts-ignore */}
              <QuickAction
                icon={<Mail className="h-4 w-4" />}
                label="Send Email"
                onClick={handleSendEmail}
              />
              {/* @ts-ignore */}
              <QuickAction
                icon={<MessageCircle className="h-4 w-4" />}
                label="Send Whatsapp"
                onClick={handleSendWhatsApp}
              />
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Enhanced Convert Dialog */}
      {showConvertDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md mx-4">
            <h2 className="text-lg font-semibold mb-4">
              Convert Lead to Contact
            </h2>
            <p className="text-sm text-gray-600 mb-4">
              Convert "{displayName || "this lead"}" to a contact. You can
              optionally assign keywords.
            </p>
            <div className="space-y-4">
              <KeywordSelect
                selectedKeywordIds={convertData.keywordIds}
                onSelectionChange={(keywordIds) =>
                  setConvertData(prev => ({
                    ...prev,
                    keywordIds,
                  }))
                }
                label="Keyword"
                placeholder="Select or create keywords"
              />
            </div>
            <div className="flex justify-end gap-2 mt-6">
              <Button
                variant="outline"
                onClick={() => setShowConvertDialog(false)}
              >
                Cancel
              </Button>
              <Button
                onClick={handleConvertConfirm}
                disabled={convertLeadMutation.isPending}
              >
                {convertLeadMutation.isPending
                  ? "Converting..."
                  : "Convert Lead"}
              </Button>
            </div>
          </div>
        </div>
      )}

      <DeleteConfirmationDialog
        open={showDeleteDialog}
        onOpenChange={setShowDeleteDialog}
        onConfirm={handleDeleteConfirm}
        itemName={displayName || "this lead"}
        itemType="lead"
        isLoading={deleteLeadMutation.isPending}
        disabled={deleteLeadMutation.isPending}
      />
      {/* Edit Lead Modal */}
      {lead && (
        <EditLeadModal
          open={showEditModal}
          onOpenChange={setShowEditModal}
          lead={lead as any}
          onUpdated={() => onEdit?.()}
        />
      )}
    </div>
  );
}

