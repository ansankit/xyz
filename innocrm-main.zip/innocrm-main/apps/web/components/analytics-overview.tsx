"use client"

import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@repo/ui';
import { LineChart } from '@repo/ui';
import { DonutChart } from '@repo/ui';
import { useLeadsGeneratedOverTime, useConversionRate, useLeadSources } from '../hooks/useDashboard';
import { ChartSkeleton } from './skeletons';

// Leads Generated Card Component
export function LeadsGeneratedCard() {
  const { data: leadsData, isLoading, error } = useLeadsGeneratedOverTime({ period: 'week' });

  if (isLoading) {
    return (
      <Card className="h-full">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Leads Generated</CardTitle>
        </CardHeader>
        <CardContent className="h-[200px] flex items-center justify-center">
          <ChartSkeleton height={180} />
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="h-full">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Leads Generated</CardTitle>
        </CardHeader>
        <CardContent className="h-[200px] flex items-center justify-center">
          <div>Error loading data</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="h-full">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">Leads Generated</CardTitle>
      </CardHeader>
      <CardContent className="h-[200px]">
        <LineChart 
          data={leadsData || { labels: [], datasets: [] }} 
          className="h-full"
          showLegend={false}
        />
      </CardContent>
    </Card>
  );
}

// Conversion Rate Card Component
export function ConversionRateCard() {
  const { data: conversionData, isLoading, error } = useConversionRate();

  // Define custom colors for the donut chart
  // You can customize these colors here
  const customColors = [
    '#3b82f6', // blue
    '#10b981', // emerald
    '#f59e0b', // amber
    '#ef4444', // red
    '#8b5cf6', // violet
    '#06b6d4', // cyan
    '#ec4899', // pink
    '#14b8a6', // teal
  ];

  // Transform the data to use custom colors
  const chartData = conversionData ? {
    ...conversionData,
    datasets: conversionData.datasets?.map((dataset: any, index: number) => ({
      ...dataset,
      backgroundColor: customColors.slice(0, dataset.data?.length || 0),
      borderColor: customColors.slice(0, dataset.data?.length || 0).map((color: string) => color),
      borderWidth: 2,
    })) || []
  } : { labels: [], datasets: [] };

  if (isLoading) {
    return (
      <Card className="h-full">
        <CardHeader>
          <CardTitle className="text-sm font-medium">Conversion Rate</CardTitle>
        </CardHeader>
        <CardContent className="h-[200px] flex items-center justify-center">
          <ChartSkeleton height={180} />
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="h-full">
        <CardHeader>
          <CardTitle className="text-sm font-medium">Conversion Rate</CardTitle>
        </CardHeader>
        <CardContent className="h-[200px] flex items-center justify-center">
          <div>Error loading data</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle className="text-sm font-medium">Conversion Rate</CardTitle>
      </CardHeader>
      <CardContent className="h-[200px]">
        <DonutChart 
          data={chartData} 
          className="h-full"
          showLegend={true}
          legendPosition="bottom"
        />
      </CardContent>
    </Card>
  );
}

// Lead Sources Card Component
export function LeadSourcesCard() {
  const { data: sourcesData, isLoading, error } = useLeadSources();

  // Define custom colors for the donut chart
  // You can customize these colors here
  const customColors = [
    '#3b82f6', // blue
    '#10b981', // emerald
    '#f59e0b', // amber
    '#ef4444', // red
    '#8b5cf6', // violet
    '#06b6d4', // cyan
    '#ec4899', // pink
    '#14b8a6', // teal
  ];

  // Transform the data to use custom colors
  const chartData = sourcesData ? {
    ...sourcesData,
    datasets: sourcesData.datasets?.map((dataset: any, index: number) => ({
      ...dataset,
      backgroundColor: customColors.slice(0, dataset.data?.length || 0),
      borderColor: customColors.slice(0, dataset.data?.length || 0).map((color: string) => color),
      borderWidth: 2,
    })) || []
  } : { labels: [], datasets: [] };

  if (isLoading) {
    return (
      <Card className="h-full">
        <CardHeader>
          <CardTitle className="text-sm font-medium">Lead Sources</CardTitle>
        </CardHeader>
        <CardContent className="h-[200px] flex items-center justify-center">
          <ChartSkeleton height={180} />
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="h-full">
        <CardHeader>
          <CardTitle className="text-sm font-medium">Lead Sources</CardTitle>
        </CardHeader>
        <CardContent className="h-[200px] flex items-center justify-center">
          <div>Error loading data</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle className="text-sm font-medium">Lead Sources</CardTitle>
      </CardHeader>
      <CardContent className="h-[200px]">
        <DonutChart 
          data={chartData} 
          className="h-full"
          showLegend={true}
          legendPosition="bottom"
        />
      </CardContent>
    </Card>
  );
}

// Analytics Overview Component
export function AnalyticsOverview() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      <LeadsGeneratedCard />
      <ConversionRateCard />
      <LeadSourcesCard />
    </div>
  );
}
