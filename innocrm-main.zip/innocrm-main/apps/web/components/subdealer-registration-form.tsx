"use client";

import { useState, useMemo } from "react";
import { Button } from "@repo/ui/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@repo/ui/components/ui/card";
import {
  Field,
  FieldDescription,
  FieldError,
  FieldGroup,
  FieldLabel,
} from "@repo/ui/components/ui/field";
import { Input } from "@repo/ui/components/ui/input";
import { Textarea } from "@repo/ui/components/ui/textarea";
import { Badge } from "@repo/ui/components/ui/badge";
import { Separator } from "@repo/ui/components/ui/separator";
import {
  Loader2,
  CheckCircle2,
  AlertCircle,
  Phone,
  Building2,
  Shield,
  Mail,
} from "lucide-react";
import { subdealerService } from "@/lib/api/services";
import { phoneSchema, gstSchema, otpSchema, emailSchema } from "@/lib/validation/subdealer";
import { GstDetails } from "@/lib/api/types";
import { toast } from "sonner";

type Step = 1 | 2 | 3 | 4 | 5;

export function SubdealerRegistrationForm() {
  const [step, setStep] = useState<Step>(1);
  const [phone, setPhone] = useState("");
  const [gstNumber, setGstNumber] = useState("");
  const [otp, setOtp] = useState("");
  const [email, setEmail] = useState("");
  const [gstDetails, setGstDetails] = useState<GstDetails | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  // Validation
  const phoneValidation = useMemo(() => {
    if (!phone) return { isValid: true, error: undefined };
    const result = phoneSchema.safeParse(phone);
    if (result.success) {
      return { isValid: true, error: undefined };
    }
    // Safely extract error message - ZodError has 'issues' property
    const errorMessage =
      result.error?.issues?.[0]?.message ||
      result.error?.message ||
      "Invalid phone number";
    return {
      isValid: false,
      error: errorMessage,
    };
  }, [phone]);

  const gstValidation = useMemo(() => {
    if (!gstNumber) return { isValid: true, error: undefined };
    const result = gstSchema.safeParse(gstNumber);
    if (result.success) {
      return { isValid: true, error: undefined };
    }
    // Safely extract error message - ZodError has 'issues' property
    const errorMessage =
      result.error?.issues?.[0]?.message ||
      result.error?.message ||
      "Invalid GST number";
    return {
      isValid: false,
      error: errorMessage,
    };
  }, [gstNumber]);

  const otpValidation = useMemo(() => {
    if (!otp) return { isValid: true, error: undefined };
    const result = otpSchema.safeParse(otp);
    if (result.success) {
      return { isValid: true, error: undefined };
    }
    // Safely extract error message - ZodError has 'issues' property
    const errorMessage =
      result.error?.issues?.[0]?.message ||
      result.error?.message ||
      "Invalid OTP";
    return {
      isValid: false,
      error: errorMessage,
    };
  }, [otp]);

  const emailValidation = useMemo(() => {
    if (!email) return { isValid: true, error: undefined }; // Optional field
    const result = emailSchema.safeParse(email);
    if (result.success) {
      return { isValid: true, error: undefined };
    }
    // Safely extract error message - ZodError has 'issues' property
    const errorMessage =
      result.error?.issues?.[0]?.message || result.error?.message || "Invalid email";
    return {
      isValid: false,
      error: errorMessage,
    };
  }, [email]);

  // Handle phone input - move to step 2 when valid
  const handlePhoneChange = (value: string) => {
    const digitsOnly = value.replace(/\D/g, "");
    const previousLength = phone.length;
    const newPhone = digitsOnly.slice(0, 10);
    setPhone(newPhone);
    setError(null);
    
    // Show validation toast when user completes entering 10 digits
    if (newPhone.length === 10 && previousLength !== 10) {
      const result = phoneSchema.safeParse(newPhone);
      if (result.success) {
        toast.success("Phone number validated successfully");
        // Auto-advance to step 2 when valid
        if (step === 1) {
          setTimeout(() => setStep(2), 100);
        }
      } else {
        const errorMessage = result.error?.issues?.[0]?.message || "Phone number must be 10 digits and start with 6-9";
        toast.error(errorMessage);
      }
    }
  };

  // Handle GST input
  const handleGstChange = (value: string) => {
    const upperValue = value.toUpperCase().replace(/[^0-9A-Z]/g, "");
    setGstNumber(upperValue.slice(0, 15));
    setError(null);
  };

  // Fetch GST details
  const handleFetchGst = async () => {
    if (!gstValidation.isValid) return;

    setLoading(true);
    setError(null);

    try {
      const response = await subdealerService.fetchGstDetails(gstNumber);
      if (response.success && response.data) {
        setGstDetails({ ...response.data, gstNumber });
        setStep(3);
        toast.success("GST details fetched successfully");
      } else {
        setError("Failed to fetch GST details");
      }
    } catch (err: any) {
      const errorMessage =
        err?.response?.data?.message ||
        err?.message ||
        "Failed to fetch GST details";
      setError(errorMessage);
      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  // Generate OTP
  const handleGenerateOtp = async () => {
    if (!phoneValidation.isValid) return;

    setLoading(true);
    setError(null);

    try {
      const response = await subdealerService.generateOtp(phone);
      if (response.success) {
        setStep(4);
        toast.success("OTP sent to your phone number");
      } else {
        setError("Failed to generate OTP");
      }
    } catch (err: any) {
      const errorMessage =
        err?.response?.data?.message ||
        err?.message ||
        "Failed to generate OTP";
      setError(errorMessage);
      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  // Verify OTP and register
  const handleVerifyOtp = async () => {
    if (!otpValidation.isValid || !gstDetails) return;
    if (email && !emailValidation.isValid) return; // Don't proceed if email is invalid

    setLoading(true);
    setError(null);

    try {
      // Include email in GST details if provided
      const gstDetailsWithEmail = {
        ...gstDetails,
        email: email.trim() || undefined,
      };

      const response = await subdealerService.verifyOtpAndRegister({
        phone,
        otp,
        gstDetails: gstDetailsWithEmail,
      });

      if (response.success) {
        setSuccess(true);
        setStep(5);
        toast.success("Registration successful!");
      } else {
        setError("Verification failed");
      }
    } catch (err: any) {
      const errorMessage =
        err?.response?.data?.message || err?.message || "Verification failed";
      setError(errorMessage);
      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  // Success view
  if (step === 5 && success) {
    return (
      <div className="container mx-auto max-w-md px-4 py-8">
        <Card className="w-full">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-green-100">
              <CheckCircle2 className="h-8 w-8 text-green-600" />
            </div>
            <CardTitle>Registration Successful!</CardTitle>
            <CardDescription>
              Your subdealer registration has been completed successfully.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {gstDetails && (
              <div className="space-y-2 rounded-lg bg-muted p-4">
                <p className="text-sm font-medium">Registration Details:</p>
                <p className="text-sm text-muted-foreground">
                  <strong>Legal Name:</strong> {gstDetails.legalName}
                </p>
                <p className="text-sm text-muted-foreground">
                  <strong>GST Number:</strong> {gstDetails.gstNumber}
                </p>
                <p className="text-sm text-muted-foreground">
                  <strong>Phone:</strong> {phone}
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto max-w-4xl px-4 py-8">
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building2 className="h-5 w-5" />
            Subdealer Registration
          </CardTitle>
          <CardDescription>
            Complete your registration by providing your phone number and GST
            details
          </CardDescription>
          <div className="flex gap-2 mt-2">
            <Badge
              variant={step >= 1 ? "default" : "outline"}
              className="flex items-center gap-1"
            >
              <Phone className="h-3 w-3" />
              Phone
            </Badge>
            <Badge
              variant={step >= 2 ? "default" : "outline"}
              className="flex items-center gap-1"
            >
              <Building2 className="h-3 w-3" />
              GST
            </Badge>
            <Badge
              variant={step >= 3 ? "default" : "outline"}
              className="flex items-center gap-1"
            >
              <Shield className="h-3 w-3" />
              Verify
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {error && (
            <div className="flex items-start gap-2 rounded-md border border-destructive/50 bg-destructive/10 px-4 py-3 text-sm text-destructive">
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <FieldGroup className="space-y-6">
            {/* Step 1: Phone Number */}
            <Field>
              <FieldLabel htmlFor="phone">Phone Number</FieldLabel>
              <Input
                id="phone"
                type="tel"
                placeholder="Enter 10-digit phone number"
                value={phone}
                onChange={e => handlePhoneChange(e.target.value)}
                maxLength={10}
                disabled={step > 1 || loading}
                aria-invalid={
                  phone && !phoneValidation.isValid ? true : undefined
                }
                className="h-11 text-base"
              />
              {phone && !phoneValidation.isValid && (
                <FieldError>{phoneValidation.error}</FieldError>
              )}
              {step === 1 && phoneValidation.isValid && phone.length === 10 && (
                <FieldDescription className="text-green-600">
                  ✓ Valid phone number
                </FieldDescription>
              )}
            </Field>

            {/* Step 2: GST Number (shown when phone is valid) */}
            {step >= 2 && (
              <Field>
                <FieldLabel htmlFor="gst">GST Number</FieldLabel>
                <div className="flex flex-col sm:flex-row gap-2">
                  <div className="flex-1">
                    <Input
                      id="gst"
                      type="text"
                      placeholder="Enter 15-character GST number"
                      value={gstNumber}
                      onChange={e => handleGstChange(e.target.value)}
                      maxLength={15}
                      disabled={step > 2 || loading}
                      className="uppercase h-11 text-base"
                      aria-invalid={
                        gstNumber && !gstValidation.isValid ? true : undefined
                      }
                    />
                    {gstNumber && !gstValidation.isValid && (
                      <FieldError>{gstValidation.error}</FieldError>
                    )}
                  </div>
                  <div className="flex items-start sm:items-end">
                    <Button
                      onClick={handleFetchGst}
                      disabled={!gstValidation.isValid || loading || step > 2}
                      className="whitespace-nowrap w-full sm:w-auto"
                    >
                      {loading && step === 2 ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Fetching...
                        </>
                      ) : (
                        "Fetch GST Details"
                      )}
                    </Button>
                  </div>
                </div>
              </Field>
            )}

            {/* Step 3: Prefilled GST Details + Generate OTP */}
            {step >= 3 && gstDetails && (
              <div className="space-y-4 rounded-lg border bg-muted/50 p-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold flex items-center gap-2">
                    <Building2 className="h-4 w-4" />
                    GST Details
                  </h3>
                  {gstDetails.status && (
                    <Badge
                      variant={
                        gstDetails.status === "Active" ? "default" : "secondary"
                      }
                    >
                      {gstDetails.status}
                    </Badge>
                  )}
                </div>
                <Separator />
                <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                  <Field className="md:col-span-2">
                    <FieldLabel>Legal Name</FieldLabel>
                    <Input
                      value={gstDetails.legalName || ""}
                      readOnly
                      className="h-11 text-base min-w-0"
                    />
                  </Field>
                  <Field className="md:col-span-2">
                    <FieldLabel>Trade Name</FieldLabel>
                    <Input
                      value={gstDetails.tradeName || ""}
                      readOnly
                      className="h-11 text-base min-w-0"
                    />
                  </Field>
                  <Field className="md:col-span-2">
                    <FieldLabel>Address</FieldLabel>
                    <Textarea
                      value={gstDetails.address || ""}
                      readOnly
                      className="min-h-[60px] text-base min-w-0 resize-none"
                      rows={4}
                    />
                  </Field>
                  <Field>
                    <FieldLabel>City</FieldLabel>
                    <Input
                      value={gstDetails.city || ""}
                      readOnly
                      className="h-11 text-base min-w-0"
                    />
                  </Field>
                  <Field>
                    <FieldLabel>State</FieldLabel>
                    <Input
                      value={gstDetails.state || ""}
                      readOnly
                      className="h-11 text-base min-w-0"
                    />
                  </Field>
                  <Field>
                    <FieldLabel>Pincode</FieldLabel>
                    <Input
                      value={gstDetails.pincode || ""}
                      readOnly
                      className="h-11 text-base min-w-0"
                    />
                  </Field>
                  <Field>
                    <FieldLabel>PAN Number</FieldLabel>
                    <Input
                      value={gstDetails.panNumber || ""}
                      readOnly
                      className="h-11 text-base min-w-0"
                    />
                  </Field>
                  <Field>
                    <FieldLabel>Business Type</FieldLabel>
                    <Input
                      value={gstDetails.businessType || ""}
                      readOnly
                      className="h-11 text-base min-w-0"
                    />
                  </Field>
                  <Field className="md:col-span-2">
                    <FieldLabel htmlFor="email" className="flex items-center gap-2">
                      <Mail className="h-4 w-4" />
                      Email Address <span className="text-muted-foreground font-normal">(Optional)</span>
                    </FieldLabel>
                    <Input
                      id="email"
                      type="email"
                      placeholder="Enter email address (optional)"
                      value={email}
                      onChange={(e) => {
                        setEmail(e.target.value);
                        setError(null);
                      }}
                      disabled={loading || step > 3}
                      className="h-11 text-base min-w-0"
                      aria-invalid={email && !emailValidation.isValid ? true : undefined}
                    />
                    {email && !emailValidation.isValid && (
                      <FieldError>{emailValidation.error}</FieldError>
                    )}
                    {email && emailValidation.isValid && (
                      <FieldDescription className="text-green-600">
                        ✓ Valid email address
                      </FieldDescription>
                    )}
                    {!email && (
                      <FieldDescription>
                        Optional: Add your email address for notifications and communication
                      </FieldDescription>
                    )}
                  </Field>
                </div>
                {step === 3 && (
                  <Button
                    onClick={handleGenerateOtp}
                    disabled={loading || (email ? !emailValidation.isValid : false)}
                    className="w-full"
                  >
                    {loading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Generating OTP...
                      </>
                    ) : (
                      "Generate OTP"
                    )}
                  </Button>
                )}
              </div>
            )}

            {/* Step 4: OTP Verification */}
            {step >= 4 && (
              <Field>
                <FieldLabel htmlFor="otp">Enter OTP</FieldLabel>
                <Input
                  id="otp"
                  type="text"
                  placeholder="Enter 6-digit OTP"
                  value={otp}
                  onChange={e => {
                    const digitsOnly = e.target.value.replace(/\D/g, "");
                    setOtp(digitsOnly.slice(0, 6));
                    setError(null);
                  }}
                  maxLength={6}
                  disabled={step > 4 || loading}
                  aria-invalid={
                    otp && !otpValidation.isValid ? true : undefined
                  }
                  className="h-11 text-base"
                />
                {otp && !otpValidation.isValid && (
                  <FieldError>{otpValidation.error}</FieldError>
                )}
                <FieldDescription>
                  OTP has been sent to {phone}
                </FieldDescription>
                {step === 4 && (
                  <Button
                    onClick={handleVerifyOtp}
                    disabled={!otpValidation.isValid || loading || (email ? !emailValidation.isValid : false)}
                    className="mt-4 w-full"
                  >
                    {loading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Verifying...
                      </>
                    ) : (
                      "Verify OTP & Register"
                    )}
                  </Button>
                )}
              </Field>
            )}
          </FieldGroup>
        </CardContent>
      </Card>
    </div>
  );
}
