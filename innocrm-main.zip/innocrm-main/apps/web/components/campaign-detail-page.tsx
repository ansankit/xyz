"use client"

import React from "react"
import { Badge } from "@repo/ui"
import { Button } from "@repo/ui"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@repo/ui"
import { ArrowLeft, Download, FileText, Edit, RefreshCw } from "lucide-react"
import { Campaign } from "./campaign-table"
import { type CampaignDelivery, type AnalyticsEvent, type BrevoCampaign } from "@/lib/api/types"

interface CampaignDetailPageProps {
  campaign: Campaign
  brevoCampaign?: BrevoCampaign
  onBack: () => void
  onEdit?: () => void
  onRefresh?: () => void | Promise<void>
  refreshing?: boolean
  deliveries?: CampaignDelivery[]
  events?: AnalyticsEvent[]
  loading?: boolean
  error?: string | null
  onRetry?: () => void
}

interface StatCardProps {
  label: string
  value: string | number
  subValue?: string
}

const StatCard: React.FC<StatCardProps> = ({ label, value, subValue }) => {
  // Determine color for rates
  const getRateColor = (subValueText: string, labelText: string) => {
    // Extract percentage number from text
    const match = subValueText.match(/([\d.]+)%/);
    if (!match || !match[1]) return 'text-muted-foreground';
    
    const rate = parseFloat(match[1] as string);
    const lowerLabel = (labelText || '').toLowerCase();
    const lowerSubValue = subValueText.toLowerCase();
    
    // Bad metrics - red for high values
    if (lowerLabel.includes('unsubscribe') || lowerLabel.includes('spam') || lowerLabel.includes('bounce') ||
        lowerSubValue.includes('unsubscribe') || lowerSubValue.includes('spam') || lowerSubValue.includes('bounce')) {
      if (rate >= 2) return 'text-red-600';
      if (rate >= 1) return 'text-orange-500';
      return 'text-green-600';
    }
    
    // Good metrics - green for high values (check both label and subValue)
    if (lowerLabel.includes('delivery') || lowerLabel.includes('delivered') || lowerLabel.includes('open') || lowerLabel.includes('click') ||
        lowerSubValue.includes('delivery') || lowerSubValue.includes('open') || lowerSubValue.includes('click')) {
      if (rate >= 50) return 'text-green-600';
      if (rate >= 25) return 'text-blue-600';
      if (rate >= 10) return 'text-blue-500';
      return 'text-orange-500';
    }
    
    return 'text-muted-foreground';
  };

  const rateColor = subValue ? getRateColor(subValue, label) : 'text-muted-foreground';

  return (
    <div className="relative bg-white rounded-lg border p-6 shadow-lg w-[240px] overflow-hidden">
      {/* Glossy overlay effect */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/60 via-white/20 to-transparent pointer-events-none" />
      <div className="absolute top-0 left-0 right-0 h-1/3 bg-gradient-to-b from-white/40 to-transparent pointer-events-none" />
      
      <div className="relative z-10">
        <div className="text-sm text-muted-foreground mb-1">{label}</div>
        <div className="text-2xl font-semibold">{value}</div>
        {subValue && <div className={`text-sm mt-1 ${rateColor}`}>{subValue}</div>}
      </div>
    </div>
  );
}

const HorizontalSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="space-y-4">
    <h3 className="text-lg font-semibold">{title}</h3>
    <div className="flex flex-wrap gap-4">
      {children}
    </div>
  </div>
)

const formatDateTime = (value?: string | null) => {
  if (!value) return '-'
  const date = new Date(value)
  const time = date.toLocaleTimeString('en-GB', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true
  })
  const dateStr = date.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: '2-digit',
    year: '2-digit'
  })
  return `${time}, ${dateStr}`
}

export function CampaignDetailPage({ campaign, brevoCampaign, onBack, onEdit, onRefresh, refreshing = false, deliveries = [], events = [], loading = false, error = null, onRetry }: CampaignDetailPageProps) {
  const isWhatsApp = campaign.channel === 'WhatsApp'
  const isEmail = campaign.channel === 'Email'

  // Calculate statistics from Brevo campaign data or use defaults
  // Prioritize globalStats if available, otherwise fall back to legacy statistics structure
  const globalStats = brevoCampaign?.statistics?.globalStats;
  const legacyStats = brevoCampaign?.statistics;
  const safeRate = (num: number, den: number) => (den > 0 ? Number(((num / den) * 100).toFixed(1)) : 0);
  
  // Use globalStats fields if available, otherwise fall back to legacy fields
  const sent = globalStats?.sent || (legacyStats as any)?.sent || 0;
  const delivered = globalStats?.delivered || (legacyStats as any)?.delivered || 0;
  const opens = globalStats?.uniqueViews || (legacyStats as any)?.uniqueOpens || (legacyStats as any)?.opens || 0;
  const clicks = globalStats?.uniqueClicks || (legacyStats as any)?.uniqueClicks || (legacyStats as any)?.clicks || 0;
  const unsubscribes = globalStats?.unsubscriptions || (legacyStats as any)?.unsubscriptions || 0;
  const spamReports = globalStats?.complaints || (legacyStats as any)?.spamReports || 0;
  const bounces = (globalStats?.hardBounces || 0) + (globalStats?.softBounces || 0) || (legacyStats as any)?.bounces || 0;
  const hardBounces = globalStats?.hardBounces || (legacyStats as any)?.hardBounces || 0;
  const softBounces = globalStats?.softBounces || (legacyStats as any)?.softBounces || 0;
  const processing = globalStats?.deferred || (legacyStats as any)?.processing || 0;
  const totalOpens = globalStats?.viewed || (legacyStats as any)?.opens || (legacyStats as any)?.uniqueOpens || 0;
  const totalClicks = globalStats?.clickers || (legacyStats as any)?.clicks || (legacyStats as any)?.uniqueClicks || 0;
  const appleMPPOpens = globalStats?.appleMppOpens || 0;

  const emailStats = {
    delivered: delivered,
    deliveryRate: (legacyStats as any)?.deliveredPercentage ?? safeRate(delivered, sent),
    opens: opens,
    openRate: globalStats?.opensRate ?? (legacyStats as any)?.openPercentage ?? safeRate(opens, delivered || sent),
    clicks: clicks,
    clickThroughRate: (legacyStats as any)?.clickPercentage ?? safeRate(clicks, delivered || sent),
    unsubscribes: unsubscribes,
    unsubscribeRate: (legacyStats as any)?.unsubscriptionPercentage ?? safeRate(unsubscribes, delivered || sent),
    sentTo: sent,
    deliveredCount: delivered,
    inProcessing: processing,
    softBounces: softBounces,
    hardBounces: hardBounces,
    totalOpens: totalOpens,
    appleMPPOpens: appleMPPOpens,
    totalClicks: totalClicks,
    clickToOpenRate: safeRate(clicks, opens),
    spamComplaints: spamReports,
    spamComplaintRate: (legacyStats as any)?.spamPercentage ?? safeRate(spamReports, delivered || sent),
  }


  // Render WhatsApp campaign
  if (isWhatsApp) {
    const kpi = {
      total: deliveries.length,
      sent: deliveries.filter(x => x.status === 'sent').length,
      delivered: deliveries.filter(x => x.status === 'delivered').length,
      read: deliveries.filter(x => x.status === 'read').length,
      failed: deliveries.filter(x => x.status === 'failed').length,
    }
    return (
      <div className="container mx-auto p-6 space-y-6">
        <div className="flex items-center justify-between">
          <Button variant="ghost" onClick={onBack}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
        </div>
        
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <h1 className="text-3xl font-bold">{campaign.name}</h1>
            <Badge variant="secondary">{campaign.channel}</Badge>
            <Badge variant="secondary">{campaign.status}</Badge>
          </div>

          {loading ? (
            <div className="space-y-4">
              <div className="grid grid-cols-5 gap-4">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="rounded-lg border p-4">
                    <div className="h-3 w-20 bg-muted animate-pulse rounded mb-2" />
                    <div className="h-6 w-24 bg-muted animate-pulse rounded" />
                  </div>
                ))}
              </div>
              <div className="rounded-md border p-6">
                <div className="h-4 w-40 bg-muted animate-pulse rounded mb-4" />
                <div className="h-40 w-full bg-muted animate-pulse rounded" />
              </div>
            </div>
          ) : error ? (
            <div className="flex items-center justify-between rounded-md border p-4">
              <div className="text-red-600">{error}</div>
              <Button size="sm" variant="outline" onClick={onRetry}>Retry</Button>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-5 gap-4">
                <StatCard label="Total" value={kpi.total} />
                <StatCard label="Sent" value={kpi.sent} />
                <StatCard label="Delivered" value={kpi.delivered} />
                <StatCard label="Read" value={kpi.read} />
                <StatCard label="Failed" value={kpi.failed} />
              </div>

              <div className="space-y-4">
                <h2 className="text-xl font-semibold">Deliveries</h2>
                <div className="rounded-md border">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-muted/50">
                        <tr className="border-b">
                          <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Address</th>
                          <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Status</th>
                          <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Sent</th>
                          <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Delivered</th>
                          <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Read</th>
                          <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Error</th>
                        </tr>
                      </thead>
                      <tbody>
                        {deliveries.map(d => (
                          <tr key={d.id} className="border-b">
                            <td className="p-4 align-middle">{d.address}</td>
                            <td className="p-4 align-middle">{d.status}</td>
                            <td className="p-4 align-middle">{formatDateTime(d.sentAt)}</td>
                            <td className="p-4 align-middle">{formatDateTime(d.deliveredAt)}</td>
                            <td className="p-4 align-middle">{formatDateTime(d.readAt)}</td>
                            <td className="p-4 align-middle">{d.errorMessage || '-'}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <h2 className="text-xl font-semibold">Events</h2>
                <div className="rounded-md border p-4">
                  {events.length === 0 ? (
                    <div className="text-muted-foreground">No events yet.</div>
                  ) : (
                    <ul className="space-y-1 text-sm">
                      {events.map(e => (
                        <li key={e.id}>[{new Date(e.occurredAt).toLocaleTimeString()}] {e.eventType}</li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    )
  }

  // Render Email campaign
  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <Button variant="ghost" onClick={onBack}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
        
        <div className="flex items-center gap-2">
          {onEdit && (
            <Button variant="outline" size="sm" onClick={onEdit}>
              <Edit className="h-4 w-4 mr-2" />
              Edit
            </Button>
          )}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button size="sm" className="gap-2">
                <Download className="h-4 w-4" />
                Export Report
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>
                <FileText className="h-4 w-4 mr-2" />
                Download PDF
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Download className="h-4 w-4 mr-2" />
                Export CSV
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Campaign Info */}
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <h1 className="text-3xl font-bold">{campaign.name}</h1>
          <Badge variant="secondary" className="bg-green-100 text-green-800">
            {campaign.status}
          </Badge>
          <Badge variant="secondary">{campaign.channel}</Badge>
        </div>

        <div className="relative bg-white rounded-lg border p-6 shadow-lg overflow-hidden">
          {/* Glossy overlay effect */}
          <div className="absolute inset-0 bg-gradient-to-br from-white/60 via-white/20 to-transparent pointer-events-none" />
          <div className="absolute top-0 left-0 right-0 h-1/3 bg-gradient-to-b from-white/40 to-transparent pointer-events-none" />
          
          <div className="relative z-10">
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-1">
                <div className="text-sm text-muted-foreground">Date & Time</div>
                <div className="font-medium">{campaign.startDate}</div>
              </div>
              <div className="space-y-1">
                <div className="text-sm text-muted-foreground">Subject</div>
                <div className="font-medium">{campaign.subject || '-'}</div>
              </div>
              <div className="space-y-1">
                <div className="text-sm text-muted-foreground">From</div>
                <div className="font-medium">{campaign.fromEmail || '-'}</div>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4 mt-4">
              <div className="space-y-1">
                <div className="text-sm text-muted-foreground">Reply To</div>
                <div className="font-medium">{campaign.replyToEmail || '-'}</div>
              </div>
              {campaign.previewText && (
                <div className="space-y-1">
                  <div className="text-sm text-muted-foreground">Preview Text</div>
                  <div className="font-medium">{campaign.previewText}</div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Refresh Button */}
        {onRefresh && (
          <div className="flex justify-start mt-4">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={onRefresh}
              disabled={refreshing}
              className="gap-2"
            >
              <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
              {refreshing ? 'Refreshing...' : 'Refresh Statistics'}
            </Button>
          </div>
        )}
      </div>

      {/* Campaign Performance */}
      <div className="space-y-4">
        <h2 className="text-xl font-semibold">Campaign Performance</h2>
        <div className="flex flex-wrap gap-4">
          <StatCard label="Delivered" value={emailStats.delivered} subValue={`${emailStats.deliveryRate}% delivery rate`} />
          <StatCard label="Opens" value={emailStats.opens} subValue={`${emailStats.openRate}% open rate`} />
          <StatCard label="Clicks" value={emailStats.clicks} subValue={`${emailStats.clickThroughRate}% click-through rate`} />
          <StatCard label="Unsubscribes" value={emailStats.unsubscribes} subValue={`${emailStats.unsubscribeRate}% unsubscribe rate`} />
        </div>
      </div>

      {/* Deliverability Details */}
      <HorizontalSection title="Deliverability Details">
        <StatCard label="Sent to" value={emailStats.sentTo} />
        <StatCard label="Delivered" value={emailStats.deliveredCount} subValue={`${emailStats.deliveryRate}% delivery rate`} />
        <StatCard label="In Processing" value={emailStats.inProcessing} />
        <StatCard label="Soft Bounces" value={emailStats.softBounces} />
        <StatCard label="Hard Bounces" value={emailStats.hardBounces} />
      </HorizontalSection>

      {/* Opens Details */}
      <HorizontalSection title="Opens Details">
        <StatCard label="Opens" value={emailStats.opens} subValue={`${emailStats.openRate}% open rate`} />
        <StatCard label="Total Opens" value={emailStats.totalOpens} />
        <StatCard label="Apple MPP Opens" value={emailStats.appleMPPOpens} />
        <div></div>
        <div></div>
      </HorizontalSection>

      {/* Clicks Details */}
      <HorizontalSection title="Clicks Details">
        <StatCard label="Click-through Rate" value={`${emailStats.clickThroughRate}%`} />
        <StatCard label="Total Clicks" value={emailStats.totalClicks} />
        <StatCard label="Clicks" value={emailStats.clicks} />
        <StatCard label="Click to Open Rate" value={`${emailStats.clickToOpenRate}%`} />
        <div></div>
      </HorizontalSection>

      {/* Unsubscribers Details */}
      <HorizontalSection title="Unsubscribers Details">
        <StatCard label="Unsubscribers" value={emailStats.unsubscribes} />
        <StatCard label="Unsubscribe Rate" value={`${emailStats.unsubscribeRate}%`} />
        <StatCard label="Spam Complaints" value={emailStats.spamComplaints} />
        <StatCard label="Spam Complaint Rate" value={`${emailStats.spamComplaintRate}%`} />
        <div></div>
      </HorizontalSection>

    </div>
  )
}

