"use client";

import React, { useState } from "react";
import { Button } from "@repo/ui/components/ui/button";
import { Label } from "@repo/ui/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@repo/ui/components/ui/dialog";
import { Filter } from "lucide-react";
import { cn } from "@repo/ui/lib/utils";
import { ProductCategory } from "@/lib/api/types";

export interface ProductFilterValues {
  categoryId?: number;
  active?: boolean;
}

interface ProductFilterProps {
  filters: ProductFilterValues;
  categories: ProductCategory[];
  onCategoryChange: (categoryId: number | undefined) => void;
  onActiveChange: (active: boolean | undefined) => void;
  onClearFilters: () => void;
}

// Helper function to check if filters are active
export const hasActiveProductFilters = (filters: ProductFilterValues): boolean => {
  return filters.categoryId !== undefined || filters.active !== undefined;
};

export const ProductFilter: React.FC<ProductFilterProps> = ({
  filters,
  categories,
  onCategoryChange,
  onActiveChange,
  onClearFilters,
}) => {
  const [open, setOpen] = useState(false);
  const hasActive = hasActiveProductFilters(filters);

  const handleClear = () => {
    onClearFilters();
    setOpen(false);
  };

  return (
    <>
      <Button
        variant="outline"
        size="sm"
        onClick={() => setOpen(true)}
        className={cn("relative", hasActive && "bg-primary/10 border-primary")}
      >
        <Filter className="h-4 w-4 mr-2" />
        Filter
        {hasActive && <span className="ml-1 h-2 w-2 bg-primary rounded-full" />}
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Filter Products</DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-4">
            {/* Category Filter */}
            <div className="space-y-2">
              <Label htmlFor="category">Category</Label>
              <Select
                value={filters.categoryId?.toString() ?? "__all__"}
                onValueChange={(v) =>
                  onCategoryChange(v === "__all__" ? undefined : parseInt(v, 10))
                }
              >
                <SelectTrigger className="h-9">
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="__all__">All Categories</SelectItem>
                  {categories.map((category) => (
                    <SelectItem key={category.id} value={category.id.toString()}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Active Status Filter */}
            <div className="space-y-2">
              <Label htmlFor="active">Status</Label>
              <Select
                value={
                  filters.active === undefined
                    ? "__all__"
                    : filters.active
                    ? "active"
                    : "inactive"
                }
                onValueChange={(v) => {
                  if (v === "__all__") onActiveChange(undefined);
                  else if (v === "active") onActiveChange(true);
                  else onActiveChange(false);
                }}
              >
                <SelectTrigger className="h-9">
                  <SelectValue placeholder="All Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="__all__">All Status</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Action Buttons */}
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>
              Close
            </Button>
            <Button variant="outline" onClick={handleClear}>
              Clear Filters
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

