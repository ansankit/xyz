"use client"

import React from 'react';
import { Card, CardContent } from '@repo/ui';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { useKeyMetrics } from '../hooks/useDashboard';
import { StatGridSkeleton } from './skeletons';

interface MetricCardProps {
  title: string;
  value: string;
  change: string;
  changeType: 'positive' | 'negative';
}

interface MetricData {
  title: string;
  value: string;
  change: string;
  changeType: 'positive' | 'negative';
}

function MetricCard({ title, value, change, changeType }: MetricCardProps) {
  return (
    <Card className="h-full transition-all duration-200 hover:shadow-md hover:border-primary/20">
      <CardContent className="p-6 h-full flex flex-col">
        <div className="flex items-start justify-between mb-4">
          <p className="text-sm font-bold text-muted-foreground uppercase tracking-wide">{title}</p>
          <div className={`p-1.5 rounded-md ${
            changeType === 'positive' 
              ? ' text-green-600' 
              : ' text-red-600'
          }`}>
            {changeType === 'positive' ? (
              <TrendingUp className="h-4 w-4" />
            ) : (
              <TrendingDown className="h-4 w-4" />
            )}
          </div>
        </div>
        <div className="flex-1 flex flex-col justify-between">
          <div className="text-3xl font-bold tracking-tight text-foreground">{value}</div>
          <div className="flex items-center gap-2 mt-auto pt-3">
            <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs font-semibold ${
              changeType === 'positive' 
                ? ' text-green-700' 
                : ' text-red-700'
            }`}>
              {change}
            </span>
            <span className="text-xs text-muted-foreground">vs last month</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export function KeyMetrics() {
  const { data: metrics, isLoading, error } = useKeyMetrics();

  if (isLoading) {
    return <StatGridSkeleton count={6} />;
  }

  if (error) {
    return (
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
        <Card className="h-full col-span-full">
          <CardContent className="p-6 flex items-center justify-center">
            <div className="text-center">
              <div className="text-lg font-medium text-red-600">Error loading metrics</div>
              <div className="text-sm text-gray-500">Please try again later</div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
      {metrics?.map((metric: MetricData, index: number) => (
        <MetricCard
          key={index}
          title={metric.title}
          value={metric.value}
          change={metric.change}
          changeType={metric.changeType}
        />
      ))}
    </div>
  );
}
