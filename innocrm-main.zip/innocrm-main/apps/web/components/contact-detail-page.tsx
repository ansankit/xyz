"use client"

import * as React from "react"
import { 
  Button,
  Badge,
  Select,
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
  TabsContents,
  Input,
  Textarea,
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  Avatar,
  InfoField
} from "@repo/ui"
import {
  ArrowLeft,
  Edit,
  Mail,
  MessageCircle,
  Plus,
  User,
  Building2,
  ChevronDown,
  Calendar,
  MoreHorizontal,
  Upload,
  Download
} from "lucide-react"
import { DetailPageHeader } from "@repo/ui"
import { toast } from "sonner"
import ContactEditModal from "./contact-edit-modal"
import { useContact, useUpdateContact } from "../hooks/useContacts"
import type { Contact as ApiContact } from "../lib/api/types"
import { validateEmail, validatePhoneOptional, validateName } from "../lib/validation"
import { ActivityFeedSkeleton, DetailHeaderSkeleton, DetailSidebarSkeleton, ListSkeleton, SectionSkeleton, StatGridSkeleton } from "./skeletons"

interface Contact {
  id: string
  name: string
  accountName: string
  position: string
  email: string
  phone: string
  mailingAddress: string
  city: string
  state: string
  zipCode: string
  country: string
  description: string
  linkedin: string
  preferredContactMethod: string
  alternateEmail: string
  timeZone: string
  createdBy: string
  lastUpdatedBy: string
  contactStatus: string
  assignedAtDisplay?: string
}

interface ContactDetailPageProps {
  contactId: number
  onBack?: () => void
  onEdit?: () => void
  onDelete?: () => void
  onSendEmail?: () => void
  onSendWhatsApp?: () => void
  onScheduleMeeting?: () => void
  onUpload?: () => void
  onDownload?: () => void
  onSave?: () => void
  onCancel?: () => void
}

export function ContactDetailPage({
  contactId,
  onBack,
  onEdit,
  onDelete,
  onSendEmail,
  onSendWhatsApp,
  onScheduleMeeting,
  onUpload,
  onDownload,
  onSave,
  onCancel,
}: ContactDetailPageProps) {
  const [isEditing, setIsEditing] = React.useState(false)
  const [editModalOpen, setEditModalOpen] = React.useState(false)

  // API hooks
  const { data: contact, isLoading: contactLoading, error: contactError } = useContact(contactId)
  const updateContactMutation = useUpdateContact()


  // Transform API contact data to expected format
  const transformedContact = React.useMemo(() => {
    if (!contact) return null;
    const latestAssignedAt = contact.convertedLeads
      ?.map((lead) => lead.assignedAt)
      ?.filter((value): value is string => Boolean(value))
      ?.sort(
        (a, b) => new Date(b).getTime() - new Date(a).getTime()
      )?.[0];
    const assignedAtDisplay = latestAssignedAt
      ? new Date(latestAssignedAt).toLocaleString("en-GB", {
          day: "2-digit",
          month: "2-digit",
          year: "2-digit",
          hour: "2-digit",
          minute: "2-digit",
          hour12: true,
        })
      : "Not assigned yet";
    
    return {
      id: contact.id.toString(),
      name: contact.name || 'Unknown',
      accountName: contact.account?.name || 'N/A',
      position: contact.position || 'N/A',
      email: contact.email || 'N/A',
      phone: contact.phone || 'N/A',
      mailingAddress: 'N/A', // Not available from API
      city: 'N/A', // Not available from API
      state: 'N/A', // Not available from API
      zipCode: 'N/A', // Not available from API
      country: 'N/A', // Not available from API
      description: contact.position && contact.account?.name 
        ? `${contact.name} is a ${contact.position} at ${contact.account.name}, responsible for driving business growth and maintaining client relationships.`
        : contact.position 
          ? `${contact.name} is a ${contact.position}, responsible for driving business growth and maintaining client relationships.`
          : contact.account?.name
            ? `${contact.name} works at ${contact.account.name}, responsible for driving business growth and maintaining client relationships.`
            : `${contact.name} is a contact in our system, responsible for driving business growth and maintaining client relationships.`,
      linkedin: 'N/A', // Not available from API
      preferredContactMethod: 'N/A', // Not available from API
      alternateEmail: 'N/A', // Not available from API
      timeZone: 'N/A', // Not available from API
      createdBy: new Date(contact.createdAt).toLocaleDateString(),
      lastUpdatedBy: new Date(contact.updatedAt).toLocaleDateString(),
      contactStatus: 'N/A', // Not available from API
      assignedAtDisplay,
    };
  }, [contact]);

  // Local state for editing
  const [editedContact, setEditedContact] = React.useState<Partial<Contact>>({})

  // Update edited contact when contact data changes, but only if not currently editing
  React.useEffect(() => {
    if (transformedContact && !isEditing) {
      setEditedContact(transformedContact)
    }
  }, [transformedContact, isEditing])

  // Initialize edited contact when entering edit mode
  React.useEffect(() => {
    if (isEditing && transformedContact) {
      setEditedContact(transformedContact)
    }
  }, [isEditing, transformedContact])

  const getStatusVariant = (status: string) => {
    switch (status.toLowerCase()) {
      case "active":
        return "default"
      case "inactive":
        return "secondary"
      case "prospect":
        return "outline"
      default:
        return "default"
    }
  }

  const handleSave = async () => {
    // Validate name (required)
    const nameValidation = validateName(editedContact.name || "")
    if (!nameValidation.isValid) {
      toast.error(nameValidation.error || "Contact name is required")
      return
    }

    // Validate email (optional but must be valid if provided)
    if (editedContact.email?.trim()) {
      const emailValidation = validateEmail(editedContact.email)
      if (!emailValidation.isValid) {
        toast.error(emailValidation.error || "Invalid email address")
        return
      }
    }

    // Validate phone (optional but must be valid if provided)
    if (editedContact.phone?.trim()) {
      const phoneValidation = validatePhoneOptional(editedContact.phone)
      if (!phoneValidation.isValid) {
        toast.error(phoneValidation.error || "Invalid phone number")
        return
      }
    }
    
    try {
      console.log('Attempting to update contact:', {
        contactId,
        data: editedContact
      })
      
      const apiData = {
        name: editedContact.name,
        email: editedContact.email,
        phone: editedContact.phone,
        position: editedContact.position,
      } as Partial<ApiContact>

      const result = await updateContactMutation.mutateAsync({
        id: contactId,
        data: apiData
      })
      
      console.log('Contact update successful:', result)
      setIsEditing(false)
      toast.success('Contact updated successfully!')
      onSave?.()
    } catch (error) {
      console.error('Failed to update contact:', error)
      toast.error(`Failed to update contact: ${error instanceof Error ? error.message : 'Unknown error'}`)
    }
  }

  const handleCancel = () => {
    setIsEditing(false)
    if (transformedContact) {
      setEditedContact(transformedContact) // Reset to original values
    }
    onCancel?.()
  }

  const handleFieldChange = (field: keyof Contact, value: string) => {
    setEditedContact(prev => ({
      ...prev,
      [field]: value
    }))
  }

  const handleScheduleMeeting = () => {
    try {
      onScheduleMeeting?.()
      toast.success('Meeting scheduled successfully!')
    } catch (error) {
      console.error('Failed to schedule meeting:', error)
      toast.error('Failed to schedule meeting. Please try again.')
    }
  }

  const handleSendEmail = () => {
    try {
      onSendEmail?.()
      toast.success('Email sent successfully!')
    } catch (error) {
      console.error('Failed to send email:', error)
      toast.error('Failed to send email. Please try again.')
    }
  }

  const handleSendWhatsApp = () => {
    try {
      onSendWhatsApp?.()
      toast.success('WhatsApp message sent successfully!')
    } catch (error) {
      console.error('Failed to send WhatsApp message:', error)
      toast.error('Failed to send WhatsApp message. Please try again.')
    }
  }

  const handleUpload = () => {
    try {
      onUpload?.()
      toast.success('File uploaded successfully!')
    } catch (error) {
      console.error('Failed to upload file:', error)
      toast.error('Failed to upload file. Please try again.')
    }
  }

  const handleDownload = () => {
    try {
      onDownload?.()
      toast.success('File downloaded successfully!')
    } catch (error) {
      console.error('Failed to download file:', error)
      toast.error('Failed to download file. Please try again.')
    }
  }

  const actions = React.useMemo(() => {
    const actionList = []

    if (onEdit) {
      actionList.push({
        label: "Edit",
        icon: <Edit className="h-4 w-4" />,
        onClick: () => setEditModalOpen(true),
        variant: "outline" as const
      })
    }

    return actionList
  }, [onEdit])

  // Loading and error states
  if (contactLoading) {
    return (
      <div className="min-h-screen bg-gray-50 p-6 space-y-6">
        <DetailHeaderSkeleton />
        <SectionSkeleton>
          <StatGridSkeleton count={4} />
        </SectionSkeleton>
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-6">
            <SectionSkeleton>
              <ListSkeleton rows={4} />
            </SectionSkeleton>
            <ActivityFeedSkeleton items={3} />
          </div>
          <div className="space-y-6">
            <DetailSidebarSkeleton />
            <DetailSidebarSkeleton items={4} />
          </div>
        </div>
      </div>
    )
  }

  if (contactError || !contact || !transformedContact) {
    return (
      <div className="min-h-screen bg-gray-50 p-6 flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600 mb-4">Failed to load contact details</p>
          <Button onClick={onBack} variant="outline">
            Go Back
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      {/* @ts-ignore */}
      <DetailPageHeader
        title={isEditing ? (editedContact.name || '') : (transformedContact?.name || 'Contact')}
        onBack={onBack}
        actions={actions}
      />

      {/* Basic Information Bar */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {/* @ts-ignore */}
        <InfoField 
          label="Account Name" 
          value={editedContact.accountName || ''} 
          editable={isEditing}
          onChange={(value) => handleFieldChange('accountName', value)}
        />
        {/* @ts-ignore */}
        <InfoField 
          label="Position" 
          value={editedContact.position || ''} 
          editable={isEditing}
          onChange={(value) => handleFieldChange('position', value)}
        />
        {/* @ts-ignore */}
        <InfoField 
          label="Email" 
          value={editedContact.email || ''} 
          editable={isEditing}
          onChange={(value) => handleFieldChange('email', value)}
        />
        {/* @ts-ignore */}
        <InfoField 
          label="Phone" 
          value={editedContact.phone || ''} 
          editable={isEditing}
          onChange={(value) => handleFieldChange('phone', value)}
        />
        {/* @ts-ignore */}
        <InfoField
          label="Assigned On"
          value={editedContact.assignedAtDisplay || 'Not assigned yet'}
          editable={false}
        />
      </div>

      {/* Tabs */}
      <Tabs defaultValue="related">
        <TabsList>
          <TabsTrigger value="related">Related</TabsTrigger>
          <TabsTrigger value="details">Details</TabsTrigger>
        </TabsList>
        
        <TabsContents className="mt-6">
          <TabsContent value="related">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Left Column */}
              <div className="space-y-6">
                {/* Account Information */}
                {/* @ts-ignore */}
                <Card>
                  {/* @ts-ignore */}
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      {/* @ts-ignore */}
                      <CardTitle className="text-lg">Account Information</CardTitle>
                      <Button size="sm" className="bg-black hover:bg-gray-800">
                        View Full Account
                      </Button>
                    </div>
                  </CardHeader>
                  {/* @ts-ignore */}
                  <CardContent>
                    <div className="grid grid-cols-2 gap-4">
                      {/* @ts-ignore */}
                      <InfoField 
                        label="Account Name" 
                        value={transformedContact.accountName || ''} 
                        editable={false}
                      />
                      {/* @ts-ignore */}
                      <InfoField 
                        label="Industry" 
                        value="N/A" 
                        editable={false}
                      />
                      {/* @ts-ignore */}
                      <InfoField 
                        label="Website" 
                        value="N/A" 
                        editable={false}
                      />
                      {/* @ts-ignore */}
                      <InfoField 
                        label="Account Owner" 
                        value={transformedContact.name || ''} 
                        editable={false}
                      />
                    </div>
                  </CardContent>
                </Card>

                {/* Opportunities */}
                 {/* @ts-ignore */}
              
              </div>

              {/* Right Column */}
              <div className="space-y-6">
                {/* Quick Actions */}
          
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="details">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Left Column */}
              <div className="space-y-6">
                {/* Address Information */}
                {/* @ts-ignore */}
                <Card>
                  {/* @ts-ignore */}
                  <CardHeader>
                      {/* @ts-ignore */}
                    <CardTitle className="text-lg">Address Information</CardTitle>
                    {/* @ts-ignore */}
                  </CardHeader>
                  {/* @ts-ignore */}
                  <CardContent className="space-y-4">
                    <div className="space-y-1">
                      <label className="text-sm font-medium text-muted-foreground mb-4">Mailing Address</label>
                      {isEditing ? (
                        <Input 
                          value={editedContact.mailingAddress}
                          onChange={(e) => handleFieldChange('mailingAddress', e.target.value)}
                        />
                      ) : (
                        <div className="px-3 py-2 bg-muted/50 rounded-md text-sm border">
                          {editedContact.mailingAddress}
                        </div>
                      )}
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-sm font-medium text-muted-foreground mb-4">City</label>
                        {isEditing ? (
                          <Input 
                            value={editedContact.city}
                            onChange={(e) => handleFieldChange('city', e.target.value)}
                          />
                        ) : (
                          <div className="px-3 py-2 bg-muted/50 rounded-md text-sm border">
                            {editedContact.city}
                          </div>
                        )}
                      </div>
                      <div className="space-y-1">
                        <label className="text-sm font-medium text-muted-foreground mb-4">State</label>
                        {isEditing ? (
                          <Input 
                            value={editedContact.state}
                            onChange={(e) => handleFieldChange('state', e.target.value)}
                          />
                        ) : (
                          <div className="px-3 py-2 bg-muted/50 rounded-md text-sm border">
                            {editedContact.state}
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-sm font-medium text-muted-foreground mb-4">Zip Code</label>
                        {isEditing ? (
                          <Input 
                            value={editedContact.zipCode}
                            onChange={(e) => handleFieldChange('zipCode', e.target.value)}
                          />
                        ) : (
                          <div className="px-3 py-2 bg-muted/50 rounded-md text-sm border">
                            {editedContact.zipCode}
                          </div>
                        )}
                      </div>
                      <div className="space-y-1">
                        <label className="text-sm font-medium text-muted-foreground mb-4">Country</label>
                        {isEditing ? (
                          <Input 
                            value={editedContact.country}
                            onChange={(e) => handleFieldChange('country', e.target.value)}
                          />
                        ) : (
                          <div className="px-3 py-2 bg-muted/50 rounded-md text-sm border">
                            {editedContact.country}
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Additional Information */}
                {/* @ts-ignore */}
                <Card>
                  {/* @ts-ignore */}
                  <CardHeader>
                    {/* @ts-ignore */}
                    <CardTitle className="text-lg">Additional Information</CardTitle>
                  </CardHeader>
                  {/* @ts-ignore */}
                  <CardContent className="space-y-4">
                    <div className="space-y-1">
                      <label className="text-sm font-medium text-muted-foreground mb-4">Description/Notes</label>
                      {isEditing ? (
                        <>
                        {/* @ts-ignore */}
                        <Textarea 
                          value={editedContact.description}
                          className="min-h-[100px]"
                          onChange={(e) => handleFieldChange('description', e.target.value)}
                        />
                        </>
                      ) : (
                        <div className="px-3 py-2 bg-muted/50 rounded-md text-sm border min-h-[100px]">
                          {editedContact.description}
                        </div>
                      )}
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-sm font-medium text-muted-foreground mb-4">LinkedIn</label>
                        {isEditing ? (
                          <Input 
                            value={editedContact.linkedin}
                            onChange={(e) => handleFieldChange('linkedin', e.target.value)}
                          />
                        ) : (
                          <div className="px-3 py-2 bg-muted/50 rounded-md text-sm border">
                            {editedContact.linkedin}
                          </div>
                        )}
                      </div>
                      <div className="space-y-1">
                        <label className="text-sm font-medium text-muted-foreground mb-4">Preferred Contact Method</label>
                        {isEditing ? (
                          <Input 
                            value={editedContact.preferredContactMethod}
                            onChange={(e) => handleFieldChange('preferredContactMethod', e.target.value)}
                          />
                        ) : (
                          <div className="px-3 py-2 bg-muted/50 rounded-md text-sm border">
                            {editedContact.preferredContactMethod}
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-sm font-medium text-muted-foreground mb-4">Alternate Email</label>
                        {isEditing ? (
                          <Input 
                            value={editedContact.alternateEmail}
                            onChange={(e) => handleFieldChange('alternateEmail', e.target.value)}
                          />
                        ) : (
                          <div className="px-3 py-2 bg-muted/50 rounded-md text-sm border">
                            {editedContact.alternateEmail}
                          </div>
                        )}
                      </div>
                      <div className="space-y-1">
                        <label className="text-sm font-medium text-muted-foreground mb-4">Time Zone</label>
                        {isEditing ? (
                          <Input 
                            value={editedContact.timeZone}
                            onChange={(e) => handleFieldChange('timeZone', e.target.value)}
                          />
                        ) : (
                          <div className="px-3 py-2 bg-muted/50 rounded-md text-sm border">
                            {editedContact.timeZone}
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Right Column */}
              <div className="space-y-6">
                {/* System Information */}
                {/* @ts-ignore */}
                <Card>
                  {/* @ts-ignore */}
                  <CardHeader>
                    {/* @ts-ignore */}
                    <CardTitle className="text-lg">System Information</CardTitle>
                  </CardHeader>
                  {/* @ts-ignore */}
                  <CardContent className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Created By:</span>
                      <span className="text-sm">{transformedContact.createdBy}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Last Updated By:</span>
                      <span className="text-sm">{transformedContact.lastUpdatedBy}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Contact Status:</span>
                      <Badge 
                        variant={transformedContact.contactStatus === "N/A" ? "outline" : "default"}
                        className={transformedContact.contactStatus === "N/A" ? "text-muted-foreground" : ""}
                      >
                        {transformedContact.contactStatus}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
            {isEditing && (
              <div className="flex justify-end gap-2 mt-6 pt-4 border-t">
                <Button 
                  variant="outline" 
                  onClick={handleCancel}
                >
                  Cancel
                </Button>
                <Button 
                  onClick={handleSave}
                >
                  Save Changes
                </Button>
              </div>
            )}
          </TabsContent>
        </TabsContents>
      </Tabs>


      {/* Edit Contact Modal */}
      <ContactEditModal
        open={editModalOpen}
        onOpenChange={setEditModalOpen}
        initialValues={{
          name: transformedContact.name,
          email: transformedContact.email,
          phone: transformedContact.phone === 'N/A' ? '' : transformedContact.phone,
          position: transformedContact.position === 'N/A' ? '' : transformedContact.position,
        }}
        isSaving={updateContactMutation.isPending}
        onSave={async (vals) => {
          try {
            await updateContactMutation.mutateAsync({ id: contactId, data: vals as Partial<ApiContact> })
            toast.success('Contact updated successfully!')
            onSave?.()
          } catch (error) {
            toast.error(`Failed to update contact: ${error instanceof Error ? error.message : 'Unknown error'}`)
            throw error
          }
        }}
      />
    </div>
  )
}
