"use client"

import React from "react"
import Link from "next/link"
import { Badge } from "@repo/ui/components/ui/badge"
import { Button } from "@repo/ui/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuCheckboxItem, DropdownMenuSeparator } from "@repo/ui/components/ui/dropdown-menu"
import { Input } from "@repo/ui/components/ui/input"
import { Checkbox } from "@repo/ui/components/ui/checkbox"
import { MoreVertical, Filter, User, ChevronDown, Columns } from "lucide-react"
import { useState, useEffect, useMemo } from "react"
import { getColumnPreferences, setColumnPreferences } from "../lib/user-preferences"

export interface TableColumn<T> {
  key: keyof T | string
  label: string
  render?: (value: any, item: T) => React.ReactNode
  className?: string
}

export interface DataTableProps<T> {
  data: T[]
  columns: TableColumn<T>[]
  title: string
  count: number
  actionItems?: Array<{
    label: string
    onClick: (item: T) => void
    className?: string
  }>
  customActions?: (item: T) => React.ReactNode
  onNameClick?: (item: T) => void
  onRowClick?: (item: T) => void
  getRowHref?: (item: T) => string | undefined
  // Pagination props
  currentPage?: number
  totalPages?: number
  itemsPerPage?: number
  onPageChange?: (page: number) => void
  onItemsPerPageChange?: (itemsPerPage: number) => void
  // Filter props
  showFilter?: boolean
  customFilter?: React.ReactNode
  filterBadges?: React.ReactNode
  // Checkbox props
  showCheckboxes?: boolean
  selectedItems?: string[]
  onSelectionChange?: (selectedIds: string[]) => void
  // Search props
  searchQuery?: string
  isSearchMode?: boolean
  columnPreferenceKey?: string
}

export function DataTable<T extends Record<string, any>>({
  data,
  columns,
  title,
  count,
  actionItems = [],
  customActions,
  onNameClick,
  onRowClick,
  getRowHref,
  currentPage = 1,
  totalPages = 1,
  itemsPerPage = 10,
  onPageChange,
  onItemsPerPageChange,
  showFilter = false,
  customFilter,
  filterBadges,
  showCheckboxes = false,
  selectedItems = [],
  onSelectionChange,
  searchQuery,
  isSearchMode = false,
  columnPreferenceKey,
}: DataTableProps<T>) {
  const defaultActionItems = [
    { label: "View Details", onClick: () => {} },
    { label: "Edit", onClick: () => {} },
    { label: "Delete", onClick: () => {}, className: "text-red-600" }
  ]

  const allActionItems = actionItems.length > 0 ? actionItems : defaultActionItems

  // Column visibility state - initialize with all columns visible
  const [visibleColumns, setVisibleColumns] = useState<Set<string>>(() => {
    const defaultColumns = new Set(columns.map(col => String(col.key)))
    if (typeof window === "undefined" || !columnPreferenceKey) {
      return defaultColumns
    }
    const saved = getColumnPreferences(columnPreferenceKey)
    if (!saved?.visibleColumns?.length) {
      return defaultColumns
    }
    const validSaved = saved.visibleColumns.filter((key) =>
      columns.some((col) => String(col.key) === key)
    )
    return validSaved.length > 0 ? new Set(validSaved) : defaultColumns
  })

  // Update visible columns when columns prop changes
  useEffect(() => {
    const currentKeys = new Set(columns.map(col => String(col.key)))
    setVisibleColumns(prev => {
      // Keep existing selections if columns haven't changed
      const newSet = new Set(prev)
      // Add any new columns (default to visible)
      currentKeys.forEach(key => {
        if (!newSet.has(key)) {
          newSet.add(key)
        }
      })
      // Remove columns that no longer exist
      newSet.forEach(key => {
        if (!currentKeys.has(key)) {
          newSet.delete(key)
        }
      })
      if (newSet.size === 0 && currentKeys.size > 0) {
        const [firstKey] = Array.from(currentKeys)
        if (firstKey) {
          newSet.add(firstKey)
        }
      }
      return newSet
    })
  }, [columns])

  useEffect(() => {
    if (!columnPreferenceKey) return
    const saved = getColumnPreferences(columnPreferenceKey)
    if (!saved?.visibleColumns?.length) return

    const validSaved = saved.visibleColumns.filter((key) =>
      columns.some((col) => String(col.key) === key)
    )

    if (validSaved.length === 0) return

    setVisibleColumns(prev => {
      const prevKeys = Array.from(prev)
      const isSame =
        prevKeys.length === validSaved.length &&
        prevKeys.every((key, index) => key === validSaved[index])
      if (isSame) return prev
      return new Set(validSaved)
    })
  }, [columnPreferenceKey, columns])

  useEffect(() => {
    if (!columnPreferenceKey) return
    setColumnPreferences(columnPreferenceKey, {
      visibleColumns: Array.from(visibleColumns),
    })
  }, [visibleColumns, columnPreferenceKey])

  // Filter columns based on visibility
  const visibleColumnsList = useMemo(() => {
    return columns.filter(col => visibleColumns.has(String(col.key)))
  }, [columns, visibleColumns])

  // Items per page state
  const [showCustomInput, setShowCustomInput] = useState(false)
  const [customValue, setCustomValue] = useState("")

  // Calculate pagination values
  const startItem = (currentPage - 1) * itemsPerPage + 1
  const endItem = Math.min(currentPage * itemsPerPage, count)

  // Handle items per page change
  const handleItemsPerPageChange = (value: number) => {
    onItemsPerPageChange?.(value)
    setShowCustomInput(false)
    setCustomValue("")
  }

  const handleCustomSubmit = () => {
    const value = parseInt(customValue)
    if (value >= 1 && value <= 100) {
      handleItemsPerPageChange(value)
    }
  }

  // Checkbox handlers
  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      const allIds = data.map(item => item.id?.toString() || '')
      onSelectionChange?.(allIds)
    } else {
      onSelectionChange?.([])
    }
  }

  const handleSelectItem = (itemId: string, checked: boolean) => {
    if (checked) {
      onSelectionChange?.([...selectedItems, itemId])
    } else {
      onSelectionChange?.(selectedItems.filter(id => id !== itemId))
    }
  }

  const isAllSelected = data.length > 0 && selectedItems.length === data.length
  const isIndeterminate = selectedItems.length > 0 && selectedItems.length < data.length

  // Column toggle handlers
  const handleToggleColumn = (columnKey: string, checked: boolean) => {
    setVisibleColumns(prev => {
      const newSet = new Set(prev)
      if (checked) {
        newSet.add(columnKey)
      } else {
        // Prevent hiding all columns - ensure at least one remains visible
        if (newSet.size > 1) {
          newSet.delete(columnKey)
        }
      }
      return newSet
    })
  }

  const handleSelectAllColumns = () => {
    setVisibleColumns(new Set(columns.map(col => String(col.key))))
  }

  const handleDeselectAllColumns = () => {
    // Keep only the first column visible
    if (columns.length > 0 && columns[0]) {
      setVisibleColumns(new Set([String(columns[0].key)]))
    }
  }

  return (
    <div className="space-y-2">
      {/* Table Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <User className="h-5 w-5 text-muted-foreground" />
          <h3 className="text-lg font-semibold">
            {title} ({count})
            {isSearchMode && searchQuery && (
              <span className="text-sm font-normal text-muted-foreground"> - Search results for "{searchQuery}"</span>
            )}
          </h3>
        </div>
        <div className="flex items-center gap-2">
          {/* Column Selection Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm">
                <Columns className="h-4 w-4 mr-2" />
                Columns
                <ChevronDown className="h-4 w-4 ml-2" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <div className="px-2 py-1.5 text-sm font-semibold">Toggle columns</div>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleSelectAllColumns}>
                Select All
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleDeselectAllColumns}>
                Deselect All
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              {columns.map((column) => {
                const columnKey = String(column.key)
                const isVisible = visibleColumns.has(columnKey)
                return (
                  <DropdownMenuCheckboxItem
                    key={columnKey}
                    checked={isVisible}
                    onCheckedChange={(checked) => handleToggleColumn(columnKey, checked === true)}
                    disabled={isVisible && visibleColumns.size === 1}
                  >
                    {column.label}
                  </DropdownMenuCheckboxItem>
                )
              })}
            </DropdownMenuContent>
          </DropdownMenu>
          {showFilter && customFilter ? (
            customFilter
          ) : (
            <Button variant="outline" size="sm">
              <Filter className="h-4 w-4 mr-2" />
              Filter
            </Button>
          )}
        </div>
      </div>

      {/* Filter Badges */}
      {filterBadges && (
        <div className="w-full flex justify-end">
          {filterBadges}
        </div>
      )}

      {/* Table */}
      <div className="rounded-md border">
        <div className={`overflow-x-auto overflow-y-auto ${onPageChange ? 'max-h-[300px]' : 'max-h-[600px]'}`}>
          <table className="w-full">
            <thead className="bg-muted">
              <tr>
                {showCheckboxes && (
                  <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground w-6 sticky top-0 z-10 bg-muted">
                    <Checkbox
                      checked={isAllSelected}
                      onCheckedChange={(checked) => handleSelectAll(checked === true)}
                    />
                  </th>
                )}
                {visibleColumnsList.map((column, index) => (
                  <th key={index} className="h-12 px-4 text-left align-middle font-medium sticky top-0 z-10 bg-muted">
                    {column.label}
                  </th>
                ))}
                {customActions && (
                  <th className="h-12 px-4 text-left align-middle font-medium sticky top-0 z-10 bg-muted">
                    Actions
                  </th>
                )}

              </tr>
            </thead>
            <tbody>
              {data.map((item, rowIndex) => {
                const rowHref = getRowHref?.(item)
                const hasHref = !!rowHref

                return (
                  <tr
                    key={item.id || rowIndex}
                    className={`border-b ${(onRowClick || hasHref) ? 'cursor-pointer hover:bg-muted/50' : ''}`}
                    onClick={() => onRowClick?.(item)}
                  >
                    {showCheckboxes && (
                      <td className="px-4 align-middle w-6">
                        <Checkbox
                          checked={selectedItems.includes(item.id?.toString() || '')}
                          onCheckedChange={(checked) => {
                            handleSelectItem(item.id?.toString() || '', checked === true)
                          }}
                          onClick={(e: React.MouseEvent) => e.stopPropagation()}
                        />
                      </td>
                    )}
                    {visibleColumnsList.map((column, colIndex) => (
                      <td key={colIndex} className={`px-2 py-0 m-0 align-middle ${column.className || ''}`}>
                        {(() => {
                          const cellContent = column.render
                            ? column.render(item[column.key], item)
                            : item[column.key]

                          // If href is provided and this is the name column, wrap in Link
                          if (hasHref && (column.key === 'name' || column.label.toLowerCase() === 'name')) {
                            return (
                              <Link
                                href={rowHref}
                                prefetch={true}
                                className="p-0 m-0 inline-block hover:underline"
                                onClick={(e: React.MouseEvent) => {
                                  e.stopPropagation()
                                  onNameClick?.(item)
                                }}
                              >
                                {cellContent}
                              </Link>
                            )
                          }

                          // Make the Name column clickable if onNameClick is provided (fallback for non-href)
                          if (onNameClick && (column.key === 'name' || column.label.toLowerCase() === 'name') && !hasHref) {
                            return (
                              <button
                                type="button"
                                className="pl-2"
                                onClick={(e: React.MouseEvent<HTMLButtonElement>) => {
                                  e.stopPropagation()
                                  onNameClick(item)
                                }}
                              >
                                {cellContent}
                              </button>
                            )
                          }
                          return cellContent
                        })()}
                      </td>
                    ))}
                    {customActions && (
                      <td className="px-2 align-middle">
                        <div onClick={(e: React.MouseEvent) => e.stopPropagation()}>
                          {customActions(item)}
                        </div>
                      </td>
                    )}

                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pagination - only show if onPageChange is provided */}
      {onPageChange && (
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="text-sm text-muted-foreground">
              Showing {startItem}-{endItem} of {count} records
            </div>
            {onItemsPerPageChange && (
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">Items per page:</span>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="sm" className="h-8">
                      {itemsPerPage}
                      <ChevronDown className="h-4 w-4 ml-2" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => handleItemsPerPageChange(10)}>
                      10
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleItemsPerPageChange(20)}>
                      20
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleItemsPerPageChange(30)}>
                      30
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleItemsPerPageChange(40)}>
                      40
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleItemsPerPageChange(50)}>
                      50
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setShowCustomInput(true)}>
                      Custom
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
                {showCustomInput && (
                  <div className="flex items-center gap-2">
                    <Input
                      type="number"
                      placeholder="1-100"
                      value={customValue}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setCustomValue(e.target.value)}
                      className="w-20 h-8"
                      min="1"
                      max="100"
                    />
                    <Button size="sm" onClick={handleCustomSubmit} className="h-8">
                      Set
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline" 
                      onClick={() => {
                        setShowCustomInput(false)
                        setCustomValue("")
                      }}
                      className="h-8"
                    >
                      Cancel
                    </Button>
                  </div>
                )}
              </div>
            )}
          </div>
          <div className="flex items-center gap-2">
            <Button 
              variant="outline" 
              size="sm" 
              disabled={currentPage === 1}
              onClick={() => {
                console.log('⬅️ Previous button clicked - currentPage:', currentPage);
                onPageChange?.(currentPage - 1);
              }}
            >
              Previous
            </Button>
            {(() => {
              // Smart pagination logic
              const pages = []
              const showEllipsis = totalPages > 7
              
              if (!showEllipsis) {
                // Show all pages if 7 or fewer
                for (let i = 1; i <= totalPages; i++) {
                  pages.push(
                    <Button 
                      key={i}
                      variant={currentPage === i ? "default" : "outline"} 
                      size="sm"
                      onClick={() => onPageChange?.(i)}
                    >
                      {i}
                    </Button>
                  )
                }
              } else {
                // Smart pagination with ellipsis
                const startPage = Math.max(1, currentPage - 2)
                const endPage = Math.min(totalPages, currentPage + 2)
                
                // Always show page 1
                pages.push(
                  <Button 
                    key={1}
                    variant={currentPage === 1 ? "default" : "outline"} 
                    size="sm"
                    onClick={() => onPageChange?.(1)}
                  >
                    1
                  </Button>
                )
                
                // Show left ellipsis if needed
                if (startPage > 2) {
                  pages.push(
                    <span key="left-ellipsis" className="px-2 text-muted-foreground">
                      ...
                    </span>
                  )
                }
                
                // Show pages around current page
                for (let i = startPage; i <= endPage; i++) {
                  if (i !== 1 && i !== totalPages) {
                    pages.push(
                      <Button 
                        key={i}
                        variant={currentPage === i ? "default" : "outline"} 
                        size="sm"
                        onClick={() => onPageChange?.(i)}
                      >
                        {i}
                      </Button>
                    )
                  }
                }
                
                // Show right ellipsis if needed
                if (endPage < totalPages - 1) {
                  pages.push(
                    <span key="right-ellipsis" className="px-2 text-muted-foreground">
                      ...
                    </span>
                  )
                }
                
                // Always show last page
                if (totalPages > 1) {
                  pages.push(
                    <Button 
                      key={totalPages}
                      variant={currentPage === totalPages ? "default" : "outline"} 
                      size="sm"
                      onClick={() => onPageChange?.(totalPages)}
                    >
                      {totalPages}
                    </Button>
                  )
                }
              }
              
              return pages
            })()}
            <Button 
              variant="outline" 
              size="sm" 
              disabled={currentPage === totalPages}
              onClick={() => {
                console.log('➡️ Next button clicked - currentPage:', currentPage, 'totalPages:', totalPages);
                onPageChange?.(currentPage + 1);
              }}
            >
              Next
            </Button>
          </div>
        </div>
      )}
      
      {/* Show total count when pagination is disabled */}
      {!onPageChange && (
        <div className="flex items-center justify-between">
          <div className="text-sm text-muted-foreground">
            Showing {count} {count === 1 ? 'record' : 'records'}
          </div>
        </div>
      )}
    </div>
  )
}
