"use client"

import { Header } from "@repo/ui"
import { Tabs, TabsList, TabsTrigger } from "@repo/ui/components/ui/tabs"
import { useAuth } from "../contexts/AuthContext"
import { useHealth } from "../hooks/useWebhook"
import { Badge } from "@repo/ui/components/ui/badge"
import { useState } from "react"
import { ChangePasswordModal } from "./change-password-modal"

interface HeaderWrapperProps {
  notificationCount?: number
  icon?: React.ReactNode
  showLeadTabs?: boolean
  activeTab?: string
  onTabChange?: (value: string) => void
  hideNotifications?: boolean
  className?: string
}

export function HeaderWrapper({ 
  notificationCount = 0, 
  icon, 
  showLeadTabs = false, 
  activeTab = 'lead-master', 
  onTabChange,
  hideNotifications = false,
  className
}: HeaderWrapperProps) {
  const { user, logout } = useAuth()
  const { data: health, isLoading: healthLoading } = useHealth()
  const [showChangePassword, setShowChangePassword] = useState(false)

  if (!user) {
    return null
  }

  const getHealthStatus = () => {
    if (healthLoading) return { text: "Loading...", variant: "secondary" as const }
    if (!health) return { text: "Offline", variant: "destructive" as const }
    if (health.status === 'ok' && health.database === 'connected') {
      return { text: "Online", variant: "default" as const }
    }
    return { text: "Issues", variant: "destructive" as const }
  }

  const healthStatus = getHealthStatus()


  // Hide edit profile and manage notifications for SALES users
  const isSalesUser = user.role === 'SALES'

  return (
    <>
    <Header
      className={className}
      icon={icon? icon :         <div className="flex items-center space-x-2">
        <div className="h-8 w-8 bg-primary rounded-md flex items-center justify-center">
          <span className="text-primary-foreground font-bold text-lg">C</span>
        </div>
        <span className="font-bold text-xl">CRM Suite</span>
        <Badge variant={healthStatus.variant} className="ml-2">
          {healthStatus.text}
        </Badge>
      </div>}
      notificationCount={notificationCount}
      user={{
        name: user.name || 'Unknown User',
        email: user.email || 'No email provided',
        role: user.role || 'User',
        // avatar: "/placeholder-avatar.jpg",
        isOnline: true,
      }}
      onNotificationClick={hideNotifications ? undefined : () => console.log("Notifications clicked")}
      onEditProfile={isSalesUser ? undefined : () => console.log("Edit profile clicked")}
      onManageNotifications={isSalesUser ? undefined : () => console.log("Manage notifications clicked")}
      onLogout={logout}
      onChangePassword={() => setShowChangePassword(true)}
    />
    <ChangePasswordModal open={showChangePassword} onClose={() => setShowChangePassword(false)} />
    </>
  )
}
