"use client";

import { Eye, EyeOff, Loader2 } from "lucide-react";
import { useState, useEffect, useMemo } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { cn } from "@repo/ui/lib/utils";
import { Button } from "@repo/ui/components/ui/button";
import { Card, CardContent } from "@repo/ui/components/ui/card";
import {
  Field,
  FieldDescription,
  FieldGroup,
  FieldLabel,
  FieldSeparator,
} from "@repo/ui/components/ui/field";
import { Input } from "@repo/ui/components/ui/input";
import Image from 'next/image';
import logo from '../app/assets/images/logos/logo_v1.png';
import loginImg1 from '../app/assets/images/login_img1.jpg';
import loginImg2 from '../app/assets/images/login_img2.jpg';
import { useAuth } from '../contexts/AuthContext';
import { validateEmailBasic } from '../lib/validation';

export function LoginForm({
  className,
  ...props
}: React.ComponentProps<"div">) {
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [currentImage, setCurrentImage] = useState(0);
  const [showSlash, setShowSlash] = useState(false);
  const { login, error, clearError, user, isAuthenticated, isLoading } = useAuth();
  const router = useRouter();

  const emailError = useMemo(() => {
    if (!email) return undefined;
    const validation = validateEmailBasic(email);
    return validation.isValid ? undefined : validation.error;
  }, [email]);
  
  const loginImages = [loginImg1, loginImg2];

  // Rotate images every 5 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImage((prev) => (prev + 1) % loginImages.length);
    }, 3000);
    return () => clearInterval(interval);
  }, [loginImages.length]);

  // Trigger the skew stripe width animation after mount
  useEffect(() => {
    setShowSlash(true);
  }, []);

  // Check if user is already authenticated and redirect accordingly
  useEffect(() => {
    // Wait for auth check to complete
    if (isLoading) return;

    // If user is authenticated, redirect based on role
    if (isAuthenticated && user) {
      const role = user.role?.toUpperCase();
      
      if (role === 'SALES') {
        router.push('/sales-user');
      } else {
        router.push('/');
      }
    }
  }, [isAuthenticated, user, isLoading, router]);

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    clearError();

    try {
      const loggedInUser = await login({ email, password });
      const role = loggedInUser?.role?.toUpperCase();

      if (role === 'SALES') {
        router.push('/sales-user');
      } else {
        router.push('/');
      }
    } catch (err) {
      // Error is handled by the auth context
    } finally {
      setIsSubmitting(false);
    }
  };

  // Show loading state while checking authentication
  if (isLoading) {
    return (
      <div className="bg-muted flex min-h-svh flex-col items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className={cn("flex flex-col w-full gap-2 h-full justify-between", className)} {...props}>
      <Card className="overflow-hidden p-0 max-h-full rounded-none">
        <CardContent className="grid p-0 md:grid-cols-2 h-screen">
          
          <div
            className={cn(
              // Top-left skew stripe (:after) anchored to form wrapper
              "relative after:content-[''] after:absolute after:bg-[#FFD20A] after:z-0 after:transition-all after:duration-700 after:delay-500 after:w-0 h-[200px] md:h-full after:h-full after:top-[-100px] md:after:top-0 after:left-[5px] md:after:left-0 after:skew-x-0 md:after:skew-x-[-45deg] after:origin-top-left after:[clip-path:polygon(0_0,100%_0%,55%_100%,0%_100%)] md:after:[clip-path:none]",
              showSlash ? "after:w-[400px] md:after:w-[300px]" : "",

              // Bottom-right skew stripe (:before) anchored to form wrapper
              "before:content-[''] before:absolute before:bg-[#FFD20A] before:z-0 before:transition-all before:duration-700 before:delay-500 before:w-0 before:h-full before:bottom-0 before:right-0 before:skew-x-[-45deg] before:origin-bottom-right",
              showSlash ? "md:before:w-[200px]" :  ""
            )}
          >
            <div className="relative z-10 min-h-screen">
              <form className=" flex flex-col justify-center items-center h-screen max-h-full" onSubmit={handleSubmit}>
                <div className="flex items-center w-full justify-start rounded-md mt-10 px-0 relative z-20">
                    <Image 
                      src={logo}
                      alt="Company Logo"
                      width={200}
                      height={200}
                      className=""
                    />
                  </div>
              <FieldGroup className="h-screen flex flex-col justify-center items-center max-w-sm px-10"> 
            
                <div className="flex flex-col items-center justify-center text-center">
                  <a
                  href="#"
                  className="flex flex-col items-center gap-2 font-medium"
                  >
                  <span className="sr-only">{process.env.NEXT_PUBLIC_COMPANY_NAME || "Innovun Global"}</span>
                </a>
                {/* <h1 className="text-2xl font-bold">Welcome back</h1> */}
                <p className="text-foreground text-balance font-bold">
                  Login to your CRM Portal
                </p>
              </div>
              
              {error && (
                <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-md">
                  {error}
                </div>
              )}

              <Field>
                <FieldLabel htmlFor="email">Email</FieldLabel>
                <Input
                  id="email"
                  type="email"
                  placeholder="m@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  aria-invalid={!!emailError}
                  aria-describedby={emailError ? "email-error" : undefined}
                />
                {emailError && (
                  <p id="email-error" className="text-xs text-red-600 mt-1">
                    {emailError}
                  </p>
                )}
              </Field>

              <Field>
                <div className="flex items-center">
                  <FieldLabel htmlFor="password">Password</FieldLabel>
                  <Link
                    href="/forgot-password"
                    className="ml-auto text-sm underline-offset-2 hover:underline"
                  >
                    Forgot your password?
                  </Link>
                </div>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="********"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className="pr-10"
                  />
                  <button
                    type="button"
                    onClick={togglePasswordVisibility}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                    aria-label={showPassword ? "Hide password" : "Show password"}
                    suppressHydrationWarning
                  >
                    {!showPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </button>
                </div>
              </Field>

              <Field>
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting && (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  )}
                  {isSubmitting ? 'Logging in...' : 'Login'}
                </Button>
              </Field>

              {/* <FieldDescription className="text-center">
                Forgot your password? <Link href="/forgot-password">Reset password</Link>
              </FieldDescription> */}
              {/* <FieldDescription className="text-center">
        By clicking continue, you agree to our <a href="#">Terms of Service</a>{" "}
        and <a href="#">Privacy Policy</a>.
      </FieldDescription> */}
            </FieldGroup>
              </form>
            </div>
          </div>

          <div className="bg-muted relative hidden md:block overflow-hidden">
            <div className="absolute inset-0 h-full w-full">
              {loginImages.map((img, index) => (
                <Image
                  key={index}
                  src={img}
                  alt="Login background"
                  fill
                  className={`object-cover transition-opacity duration-1000 ${
                    index === currentImage ? 'opacity-100' : 'opacity-0'
                  }`}
                  priority={index === 0}
                />
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}