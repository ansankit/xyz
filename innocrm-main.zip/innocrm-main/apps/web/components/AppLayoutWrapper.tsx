'use client';

import { usePathname, useRouter } from "next/navigation";
import { HeaderWrapper } from "./header-wrapper";
import { AppSidebar } from "./appSidebar";
import { useLeadManagementContext } from "../contexts/LeadManagementContext";
import logo from '../app/assets/images/logos/logo_v2.png';
import Image from "next/image";
import { useAuth } from "../contexts/AuthContext";
import { useEffect } from "react";

interface AppLayoutWrapperProps {
  children: React.ReactNode;
}

export function AppLayoutWrapper({ children }: AppLayoutWrapperProps) {
  const pathname = usePathname();
  const router = useRouter();
  const { isDeveloper, isAuthenticated } = useAuth();
  
  // Try to get lead management context, but don't fail if not available
  let leadContext = null;
  try {
    leadContext = useLeadManagementContext();
  } catch {
    // Context not available, which is fine for non-lead pages
  }
  
  // Pages that should not show sidebar and header
  const authPages = ['/login', '/signup', '/forgot-password', '/new-registration-subdealer', '/developer-login', '/integration-manager'];
  const isAuthPage = authPages.includes(pathname);

  useEffect(() => {
    if (!isAuthenticated || !isDeveloper) {
      return;
    }

    if (pathname !== '/integration-manager') {
      router.replace('/integration-manager');
    }
  }, [isAuthenticated, isDeveloper, pathname, router]);
  
  // Pages that should show simplified layout (no sidebar, custom header)
  // Exclude /sales/products from simplified layout as it needs sidebar/header
  const simplifiedPages = ['/sales'];
  const isSimplifiedPage = simplifiedPages.some(page => 
    pathname.startsWith(page) && !pathname.startsWith('/sales/products')
  );
  
  // Show lead tabs only on leads page and when context is available
  const showLeadTabs = pathname === '/leads' && leadContext !== null;
  const activeTab = leadContext?.activeTab || 'lead-master';

  if (isAuthPage) {
    return (
      <div className="h-screen w-full overflow-y-auto">
        {children}
      </div>
    );
  }

  // Simplified layout for sales pages (no sidebar, custom header in page)
  if (isSimplifiedPage) {
    return (
      <div className="h-full flex flex-col">
        <main className="flex-1 overflow-y-auto">
          {children}
        </main>
      </div>
    );
  }

  return (
    <div className="h-full flex max-w-screen-3xl mx-auto flex-col justify-center">
      <HeaderWrapper
        icon={<Image src={logo} alt="Stanley Black & Decker Logo" width={200} height={60} className="object-contain h-auto" />}
        className="bg-yellow-50"
      />
      <div className="flex flex-1 overflow-hidden">
        <div className="shrink-0">
          <AppSidebar />
        </div>
        <main className="flex-1 overflow-y-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
