"use client";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarItem,
  SidebarCollapsibleItem,
  SidebarProvider,
} from "@repo/ui";
import { ChartNoAxesCombined, Users, Settings, Megaphone, FileText, Bot, ListChecks, UserCheck, Share2, Building2, BookUser, Mail, MessageCircle, UserLock, TrendingUp, BarChart, Package } from "lucide-react";
import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import { useIsAdminRole } from "./guards/RoleGuard";

export function AppSidebar() {
  const pathname = usePathname();
  const [isClient, setIsClient] = useState(false);
  const isAdmin = useIsAdminRole();

  useEffect(() => {
    setIsClient(true);
  }, []);

  // Check if we're on any lead management route
  const isLeadManagementActive = pathname.startsWith("/leads");
  const isCampaignsActive = pathname.startsWith("/campaigns");
  const isSalesManagementActive = pathname.startsWith("/sales");

  return (
    <SidebarProvider>
      <Sidebar className="h-full">

        <SidebarContent className="[&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
          <SidebarGroup title="">
            <SidebarItem 
              icon={ChartNoAxesCombined as any} 
              label="Dashboard" 
              href="/" 
              active={isClient && pathname === "/"} 
            />
            <SidebarItem 
              icon={FileText as any} 
              label="Landing Page Builder" 
              href="/landing-page" 
              active={isClient && pathname === "/landing-page"} 
            />
            <SidebarCollapsibleItem 
              icon={Users as any} 
              label="Lead Management" 
              active={isClient && isLeadManagementActive}
              defaultOpen={isClient && isLeadManagementActive}
            >
              <SidebarItem 
                label="Lead Master" 
                href="/leads/lead-master"
                active={isClient && pathname === '/leads/lead-master'} 
                icon={ListChecks as any}
              />
              <SidebarItem 
                label="Assigned Leads" 
                href="/leads/assigned"
                active={isClient && pathname === '/leads/assigned'} 
                icon={UserCheck as any}
              />
              <SidebarItem 
                label="Unassigned Leads" 
                href="/leads/unassigned-leads"
                active={isClient && pathname === '/leads/unassigned-leads'} 
                icon={Share2 as any}
              />
              <SidebarItem 
                label="Accounts" 
                href="/leads/accounts"
                active={isClient && pathname === '/leads/accounts'} 
                icon={Building2 as any}
              />
              <SidebarItem 
                label="Contacts" 
                href="/leads/contacts"
                active={isClient && pathname === '/leads/contacts'} 
                icon={BookUser as any}
              />
            </SidebarCollapsibleItem>
            <SidebarCollapsibleItem 
              icon={Megaphone as any} 
              label="Campaign Management"
              active={isClient && isCampaignsActive}
              defaultOpen={isClient && isCampaignsActive}
            >
              <SidebarItem 
                label="Email Campaigns" 
                href="/campaigns/email"
                active={isClient && pathname.startsWith('/campaigns/email')} 
                icon={Mail as any}
              />
              <SidebarItem 
                label="WhatsApp Campaigns" 
                href="/campaigns/whatsapp"
                active={isClient && pathname.startsWith('/campaigns/whatsapp')} 
                icon={MessageCircle as any}
              />
            </SidebarCollapsibleItem>
            <SidebarCollapsibleItem 
              icon={TrendingUp as any} 
              label="Sales Management"
              active={isClient && isSalesManagementActive}
              defaultOpen={isClient && isSalesManagementActive}
            >
              <SidebarItem 
                label="Dashboard" 
                href="/sales/dashboard"
                active={isClient && pathname === '/sales/dashboard'} 
                icon={BarChart as any}
              />
              <SidebarItem 
                label="Product Configuration" 
                href="/sales/products"
                active={isClient && pathname.startsWith('/sales/products')}
                icon={Package as any}
              />
            </SidebarCollapsibleItem>
            <SidebarItem 
              icon={Bot as any} 
              label="Chatbot" 
              href="/chatbot" 
              active={isClient && pathname === "/chatbot"} 
            />
            {!isAdmin && (
              <SidebarItem 
                icon={UserLock as any} 
                label="User Management" 
                href="/admin/user-management" 
                active={isClient && pathname === "/admin/user-management"} 
              />
            )}
            <SidebarItem 
              icon={Settings as any} 
              label="Settings" 
              href="/settings" 
              active={isClient && pathname === "/settings"} 
            /> {/* Settings can have notification management and other user related settings such as name */}
          </SidebarGroup>
        </SidebarContent>
        <SidebarFooter>
          <p className="text-xs text-gray-500">© {new Date().getFullYear()} CRM Suite</p>
        </SidebarFooter>
      </Sidebar>
    </SidebarProvider>
  );
}
