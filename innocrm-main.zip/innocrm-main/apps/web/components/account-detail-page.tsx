"use client"

import * as React from "react"
import Link from "next/link"
import {
  DetailPageHeader, 
  DetailCard, 
  InfoField,
  InfoGrid,
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  Button,
  Badge,
  Select,
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
  TabsContents,
  Avatar
} from "@repo/ui"
import {
  ArrowLeft,
  Edit,
  Mail,
  MessageCircle,
  Plus,
  User,
  Building2,
  ChevronDown,
  Calendar,
  MoreHorizontal
} from "lucide-react"
import { DataTable, TableColumn } from "./data-table"
import { toast } from "sonner"
import { useRouter } from "next/navigation"
import { useAccount, useUpdateAccount } from "../hooks/useAccounts"
import AccountEditModal from "./account-edit-modal"
import { useSearchContacts } from "../hooks/useSearchContacts"
import { ContactSearchSection } from "./contact-search-section"
import { Account as ApiAccount } from "../lib/api/types"
import { validateName, validatePhoneOptional, validateWebsite } from "../lib/validation"
import { ActivityFeedSkeleton, DetailHeaderSkeleton, DetailSidebarSkeleton, SectionSkeleton, StatGridSkeleton, TableSkeleton } from "./skeletons"

interface Account {
  id: string
  name: string
  industry: string
  website: string
  accountOwner: string
  accountOwnerId: number | null
  phone: string
  description: string
  annualRevenue: string
  companySize: string
  billingAddress: {
    street: string
    city: string
    state: string
    zipCode: string
    country: string
  }
  shippingAddress: {
    street: string
    city: string
    state: string
    zipCode: string
    country: string
    sameAsBilling: boolean
  }
  createdBy: string
  lastUpdatedBy: string
  accountStatus: string
}

interface Contact {
  id: string
  name: string
  email: string
  phone: string
  position: string
  createdAt: string
}


interface AccountDetailPageProps {
  accountId: number
  onBack?: () => void
  onEdit?: () => void
  onDelete?: () => void
  onSendEmail?: () => void
  onSendWhatsApp?: () => void
  onScheduleMeeting?: () => void
  onAddContact?: () => void
  onAddOpportunity?: () => void
  onReassign?: () => void
  onSave?: () => void
  onCancel?: () => void
}

export const AccountDetailPage = React.memo(function AccountDetailPage({
  accountId,
  onBack,
  onEdit,
  onDelete,
  onSendEmail,
  onSendWhatsApp,
  onScheduleMeeting,
  onAddContact,
  onAddOpportunity,
  onReassign,
  onSave,
  onCancel,
}: AccountDetailPageProps) {
  const router = useRouter()
  const [activeTab, setActiveTab] = React.useState("related")
  const [isEditing, setIsEditing] = React.useState(false)
  const [editModalOpen, setEditModalOpen] = React.useState(false)
  // API hooks
  const { data: apiAccount, isLoading: accountLoading, error: accountError } = useAccount(accountId)
  const updateAccountMutation = useUpdateAccount()
  
  // Contact search state
  const [contactSearchQuery, setContactSearchQuery] = React.useState('')
  
  // Contact search functionality
  const {
    data: searchedContacts,
    isSearching: isSearchingContacts,
    hasResults: hasSearchResults,
    isEmpty: isSearchEmpty,
  } = useSearchContacts(contactSearchQuery, accountId, {
    debounceMs: 500,
    minQueryLength: 2
  })

  // Handle search query changes
  const handleSearchQueryChange = React.useCallback((query: string) => {
    setContactSearchQuery(query)
  }, [])

  // Transform API account data to expected format
  const account = React.useMemo(() => {
    if (!apiAccount) return null;
    
    return {
      id: apiAccount.id.toString(),
      name: apiAccount.name || 'Unknown',
      industry: apiAccount.industry || 'N/A',
      website: apiAccount.website || 'N/A',
      accountOwner: apiAccount.contacts?.[0]?.name || 'N/A',
      accountOwnerId: apiAccount.contacts?.[0]?.id || null,
      phone: apiAccount.phone || 'N/A',
      description: apiAccount.description || `${apiAccount.name} is a leading company in the ${apiAccount.industry || 'business'} industry, providing innovative solutions and services to clients worldwide.`,
      annualRevenue: 'N/A', // Not available from API
      companySize: 'N/A', // Not available from API
      billingAddress: {
        street: 'N/A', // Not available from API
        city: 'N/A', // Not available from API
        state: 'N/A', // Not available from API
        zipCode: 'N/A', // Not available from API
        country: 'N/A' // Not available from API
      },
      shippingAddress: {
        street: 'N/A', // Not available from API
        city: 'N/A', // Not available from API
        state: 'N/A', // Not available from API
        zipCode: 'N/A', // Not available from API
        country: 'N/A', // Not available from API
        sameAsBilling: true
      },
      createdBy: new Date(apiAccount.createdAt).toLocaleDateString(),
      lastUpdatedBy: new Date(apiAccount.updatedAt).toLocaleDateString(),
      accountStatus: 'Active' // Mock data
    };
  }, [apiAccount]);

  // Transform API contacts data to expected format
  const allContacts: Contact[] = React.useMemo(() => {
    if (!apiAccount?.contacts) return [];
    
    return apiAccount.contacts.map((contact: any) => ({
      id: contact.id.toString(),
      name: contact.name || 'Unknown',
      email: contact.email || 'N/A',
      phone: contact.phone || 'N/A',
      position: contact.position || 'N/A',
      createdAt: new Date(contact.createdAt).toLocaleDateString()
    }));
  }, [apiAccount?.contacts]);

  // Transform search results to expected format
  const searchContacts: Contact[] = React.useMemo(() => {
    if (!searchedContacts) return [];
    
    return searchedContacts.map((contact: any) => ({
      id: contact.id.toString(),
      name: contact.name || 'Unknown',
      email: contact.email || 'N/A',
      phone: contact.phone || 'N/A',
      position: contact.position || 'N/A',
      createdAt: new Date(contact.createdAt).toLocaleDateString()
    }));
  }, [searchedContacts]);

  // Determine which contacts to display
  const contacts = React.useMemo(() => {
    return contactSearchQuery.length > 0 ? searchContacts : allContacts;
  }, [contactSearchQuery, searchContacts, allContacts]);


  // Local state for editing
  const [editedAccount, setEditedAccount] = React.useState<Account | null>(null)

  // Update edited account when account data changes
  React.useEffect(() => {
    if (account && !isEditing) {
      setEditedAccount(account)
    }
  }, [account, isEditing])

  // Initialize edited account when entering edit mode
  React.useEffect(() => {
    if (isEditing && account) {
      setEditedAccount(account)
    }
  }, [isEditing, account])

  const handleSave = () => {
    if (!safeEditedAccount) return;
    
    // Validate name (required)
    const nameValidation = validateName(safeEditedAccount.name || "")
    if (!nameValidation.isValid) {
      toast.error(nameValidation.error || "Account name is required")
      return
    }

    // Validate website (required in this component)
    if (!safeEditedAccount.website?.trim()) {
      toast.error('Website is required')
      return
    }
    const websiteValidation = validateWebsite(safeEditedAccount.website)
    if (!websiteValidation.isValid) {
      toast.error(websiteValidation.error || "Please enter a valid website URL (starting with http:// or https://)")
      return
    }

    // Validate phone (optional but must be valid if provided)
    if (safeEditedAccount.phone?.trim()) {
      const phoneValidation = validatePhoneOptional(safeEditedAccount.phone)
      if (!phoneValidation.isValid) {
        toast.error(phoneValidation.error || "Invalid phone number")
        return
      }
    }
    
    try {
      setIsEditing(false)
      onSave?.()
      toast.success('Account updated successfully!')
      // Here you would typically call an API to save the changes
      console.log('Saving account changes:', safeEditedAccount)
    } catch (error) {
      console.error('Failed to save account:', error)
      toast.error('Failed to save account. Please try again.')
    }
  }

  const handleCancel = () => {
    setIsEditing(false)
    setEditedAccount(account) // Reset to original values
    onCancel?.()
  }

  const handleFieldChange = (field: keyof Account, value: string) => {
    if (!safeEditedAccount) return;
    
    setEditedAccount(prev => prev ? ({
      ...prev,
      [field]: value
    }) : null)
  }

  const handleAddressChange = (addressType: 'billingAddress' | 'shippingAddress', field: string, value: string) => {
    if (!safeEditedAccount) return;
    
    setEditedAccount(prev => prev ? ({
      ...prev,
      [addressType]: {
        ...prev[addressType],
        [field]: value
      }
    }) : null)
  }

  const handleScheduleMeeting = () => {
    try {
      onScheduleMeeting?.()
      toast.success('Meeting scheduled successfully!')
    } catch (error) {
      console.error('Failed to schedule meeting:', error)
      toast.error('Failed to schedule meeting. Please try again.')
    }
  }

  const handleSendEmail = () => {
    try {
      onSendEmail?.()
      toast.success('Email sent successfully!')
    } catch (error) {
      console.error('Failed to send email:', error)
      toast.error('Failed to send email. Please try again.')
    }
  }

  const handleSendWhatsApp = () => {
    try {
      onSendWhatsApp?.()
      toast.success('WhatsApp message sent successfully!')
    } catch (error) {
      console.error('Failed to send WhatsApp message:', error)
      toast.error('Failed to send WhatsApp message. Please try again.')
    }
  }

  const getStatusVariant = (status: string) => {
    switch (status.toLowerCase()) {
      case "active":
        return "default"
      case "inactive":
        return "secondary"
      case "prospect":
        return "outline"
      default:
        return "default"
    }
  }

  const actions = React.useMemo(() => {
    const actionList = []

    if (onEdit) {
      actionList.push({
        label: "Edit",
        icon: <Edit className="h-4 w-4" />,
        onClick: () => setEditModalOpen(true),
        variant: "outline" as const
      })
    }

    return actionList
  }, [onEdit])

  const RelatedTab = () => (
    <div className="space-y-6">
      {(() => {
        const contactColumns: TableColumn<Contact>[] = [
          {
            key: "name",
            label: "Contact Name",
            render: (value) => (
              <div className="flex items-center gap-2">
                <span className="font-medium text-blue-600 hover:text-blue-800">{value}</span>
              </div>
            )
          },
          { key: "email", label: "Email" },
          { key: "phone", label: "Phone" },
          { key: "position", label: "Position/Title" },
          { key: "createdAt", label: "Created At" }
        ]

        const handleOpenContact = (item: Contact) => router.push(`/contacts/${item.id}`)

        return (
          <DataTable<Contact>
            data={contacts}
            columns={contactColumns}
            title="Contacts"
            count={contacts.length}
            onNameClick={handleOpenContact}
            onRowClick={handleOpenContact}
            getRowHref={(contact) => `/leads/contacts/${contact.id}`}
            searchQuery={contactSearchQuery}
            isSearchMode={contactSearchQuery.length > 0}
            showFilter={true}
            customFilter={<></>}
          />
        )
      })()} 
    </div>
  )

  const DetailsTab = () => (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Left Column */}
      <div className="space-y-6">
        {/* Address Information */}
        {/* @ts-ignore */}
        <DetailCard title="Address Information">
          <div className="space-y-4">
            <div>
              <h4 className="font-medium mb-2">Billing Address</h4>
              {/* @ts-ignore */}
              {/* @ts-ignore */}
          <InfoGrid columns={1}>
                {/* @ts-ignore */}
                {/* @ts-ignore */}
            {/* @ts-ignore */}
        <InfoField 
                  label="Street Address" 
                  value={safeEditedAccount.billingAddress.street}
                  editable={isEditing}
                  onChange={(value) => handleAddressChange('billingAddress', 'street', value)}
                />
                <div className="grid grid-cols-2 gap-4">
                  {/* @ts-ignore */}
                {/* @ts-ignore */}
            {/* @ts-ignore */}
        <InfoField 
                    label="City" 
                    value={safeEditedAccount.billingAddress.city}
                    editable={isEditing}
                    onChange={(value) => handleAddressChange('billingAddress', 'city', value)}
                  />
                  {/* @ts-ignore */}
                {/* @ts-ignore */}
            {/* @ts-ignore */}
        <InfoField 
                    label="State" 
                    value={safeEditedAccount.billingAddress.state}
                    editable={isEditing}
                    onChange={(value) => handleAddressChange('billingAddress', 'state', value)}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  {/* @ts-ignore */}
                {/* @ts-ignore */}
            {/* @ts-ignore */}
        <InfoField 
                    label="Zip Code" 
                    value={safeEditedAccount.billingAddress.zipCode}
                    editable={isEditing}
                    onChange={(value) => handleAddressChange('billingAddress', 'zipCode', value)}
                  />
                  {/* @ts-ignore */}
                {/* @ts-ignore */}
            {/* @ts-ignore */}
        <InfoField 
                    label="Country" 
                    value={safeEditedAccount.billingAddress.country}
                    editable={isEditing}
                    onChange={(value) => handleAddressChange('billingAddress', 'country', value)}
                  />
                </div>
              </InfoGrid>
            </div>
            
            <div>
              <h4 className="font-medium mb-2">Shipping Address</h4>
              <div className="flex items-center gap-2 mb-2">
                <input 
                  type="checkbox" 
                  checked={safeEditedAccount.shippingAddress.sameAsBilling}
                  disabled={!isEditing}
                  onChange={(e) => handleAddressChange('shippingAddress', 'sameAsBilling', e.target.checked.toString())}
                />
                <label className="text-sm">Same as billing address</label>
              </div>
              {/* @ts-ignore */}
              {/* @ts-ignore */}
          <InfoGrid columns={1}>
                {/* @ts-ignore */}
                {/* @ts-ignore */}
            {/* @ts-ignore */}
        <InfoField 
                  label="Street Address" 
                  value={safeEditedAccount.shippingAddress.street}
                  editable={isEditing}
                  onChange={(value) => handleAddressChange('shippingAddress', 'street', value)}
                />
                <div className="grid grid-cols-2 gap-4">
                  {/* @ts-ignore */}
                {/* @ts-ignore */}
            {/* @ts-ignore */}
        <InfoField 
                    label="City" 
                    value={safeEditedAccount.shippingAddress.city}
                    editable={isEditing}
                    onChange={(value) => handleAddressChange('shippingAddress', 'city', value)}
                  />
                  {/* @ts-ignore */}
                {/* @ts-ignore */}
            {/* @ts-ignore */}
        <InfoField 
                    label="State" 
                    value={safeEditedAccount.shippingAddress.state}
                    editable={isEditing}
                    onChange={(value) => handleAddressChange('shippingAddress', 'state', value)}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  {/* @ts-ignore */}
                {/* @ts-ignore */}
            {/* @ts-ignore */}
        <InfoField 
                    label="Zip Code" 
                    value={safeEditedAccount.shippingAddress.zipCode}
                    editable={isEditing}
                    onChange={(value) => handleAddressChange('shippingAddress', 'zipCode', value)}
                  />
                  {/* @ts-ignore */}
                {/* @ts-ignore */}
            {/* @ts-ignore */}
        <InfoField 
                    label="Country" 
                    value={safeEditedAccount.shippingAddress.country}
                    editable={isEditing}
                    onChange={(value) => handleAddressChange('shippingAddress', 'country', value)}
                  />
                </div>
              </InfoGrid>
            </div>
          </div>
        </DetailCard>
      </div>

      {/* Right Column */}
      <div className="space-y-6">
        {/* Additional Information */}
        {/* @ts-ignore */}
        <DetailCard title="Additional Information">
          {/* @ts-ignore */}
          <InfoGrid columns={1}>
            {/* @ts-ignore */}
        <InfoField 
              label="Description/Notes" 
              value={safeEditedAccount.description}
              editable={isEditing}
              onChange={(value) => handleFieldChange('description', value)}
            />
            {/* @ts-ignore */}
        <InfoField 
              label="Annual Revenue" 
              value={safeEditedAccount.annualRevenue}
              editable={isEditing}
              onChange={(value) => handleFieldChange('annualRevenue', value)}
            />
            {/* @ts-ignore */}
        <InfoField 
              label="Company Size" 
              value={safeEditedAccount.companySize}
              editable={isEditing}
              onChange={(value) => handleFieldChange('companySize', value)}
            />
          </InfoGrid>
        </DetailCard>

        {/* System Information */}
        {/* @ts-ignore */}
        <DetailCard title="System Information">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-start gap-4">
                {/* @ts-ignore */}
                <Avatar className="h-12 w-12 mt-1">
                  <User className="h-6 w-6" />
                </Avatar>
                <div>
                  <div className="font-medium text-base">{safeAccount.accountOwner}</div>
                  <p className="text-sm text-muted-foreground">CTO</p>
                </div>
              </div>
              {/* <Button size="sm" onClick={onReassign} className="bg-black hover:bg-gray-800  px-6 py-2.5 flex items-center justify-center">
                Reassign
              </Button> */}
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Created By:</span>
                <span className="text-sm">
                  {apiAccount?.createdAt 
                    ? new Date(apiAccount.createdAt).toLocaleString('en-GB', {
                        day: '2-digit',
                        month: '2-digit',
                        year: '2-digit',
                        hour: '2-digit',
                        minute: '2-digit',
                        hour12: true
                      })
                    : safeAccount.createdBy}
                </span>
              </div>
              {/* <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Last Updated By:</span>
                <span className="text-sm">
                  {apiAccount?.updatedAt 
                    ? new Date(apiAccount.updatedAt).toLocaleString('en-GB', {
                        day: '2-digit',
                        month: '2-digit',
                        year: '2-digit',
                        hour: '2-digit',
                        minute: '2-digit',
                        hour12: true
                      })
                    : safeAccount.lastUpdatedBy}
                </span>
              </div> */}
            </div>
          </div>
        </DetailCard>

        {/* Quick Actions */}
        {/* @ts-ignore */}
      </div>
      {isEditing && (
        <div className="flex justify-end gap-2 mt-6 pt-4 border-t">
          <Button variant="outline" onClick={handleCancel}>
            Cancel
          </Button>
          <Button onClick={handleSave}>
            Save Changes
          </Button>
        </div>
      )}
    </div>
  )

  // Loading and error states
  if (accountLoading) {
    return (
      <div className="min-h-screen bg-gray-50 p-6 space-y-6">
        <DetailHeaderSkeleton />
        <SectionSkeleton>
          <StatGridSkeleton count={3} />
        </SectionSkeleton>
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-6">
            <SectionSkeleton>
              <TableSkeleton rows={5} />
            </SectionSkeleton>
            <ActivityFeedSkeleton items={3} />
          </div>
          <div className="space-y-6">
            <DetailSidebarSkeleton />
            <SectionSkeleton>
              <TableSkeleton rows={3} />
            </SectionSkeleton>
          </div>
        </div>
      </div>
    )
  }

  if (accountError || !account || !editedAccount) {
    return (
      <div className="min-h-screen bg-gray-50 p-6 flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600 mb-4">Failed to load account details</p>
          <Button onClick={onBack} variant="outline">
            Go Back
          </Button>
        </div>
      </div>
    )
  }

  // At this point, we know account and editedAccount are not null
  const safeAccount = account!;
  const safeEditedAccount = editedAccount!;

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      {/* @ts-ignore */}
      <DetailPageHeader
        title={"Account Details"}
        onBack={onBack}
        actions={actions}
      />

      {/* Account Overview */}
      <Card className="mb-6 border shadow-sm">
        <CardContent className="p-6">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
            {/* Account Info Section */}
            <div className="flex items-center gap-4">
              <div className="relative">
                <div className="w-16 h-16 bg-primary/10 rounded-lg flex items-center justify-center">
                  <Building2 className="h-8 w-8 text-primary" />
                </div>
                {/* <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-background"></div> */}
              </div>
              <div>
                <h2 className="text-2xl font-semibold text-foreground">{safeEditedAccount.name}</h2>
                {/* {safeEditedAccount.industry && (
                  <p className="text-sm text-muted-foreground mt-1">{safeEditedAccount.industry}</p>
                )} */}
              </div>
            </div>

            {/* Stats Section */}
            <div className="flex flex-col sm:flex-row gap-4">
              {/* Contacts Stat */}
              <Card className="border shadow-sm min-w-[180px]">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center">
                      <User className="h-5 w-5 text-muted-foreground" />
                    </div>
                    <div>
                      <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Contacts</p>
                      <p className="text-2xl font-semibold text-foreground mt-0.5">{contacts.length}</p>
                      <p className="text-xs text-muted-foreground">Total associated</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Created Date Stat */}
              <Card className="border shadow-sm min-w-[180px]">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center">
                      <Calendar className="h-5 w-5 text-muted-foreground" />
                    </div>
                    <div>
                      <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Created</p>
                      <p className="text-base font-semibold text-foreground mt-0.5">{safeAccount.createdBy}</p>
                      <p className="text-xs text-muted-foreground">Account date</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Basic Information Bar */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {/* @ts-ignore */}
        <InfoField 
          label="Industry" 
          value={safeEditedAccount.industry} 
          editable={isEditing}
          onChange={(value) => handleFieldChange('industry', value)}
        />
        {/* @ts-ignore */}
        <InfoField 
          label="Website" 
          value={safeEditedAccount.website} 
          editable={isEditing}
          onChange={(value) => handleFieldChange('website', value)}
          onClick={safeAccount.website && !isEditing ? () => window.open(safeAccount.website, '_blank') : undefined}
        />
        {/* @ts-ignore */}
        <InfoField
          label="Account Owner"
          value={safeEditedAccount.accountOwner}
          editable={isEditing}
          onChange={(value) => handleFieldChange('accountOwner', value)}
          href={safeAccount.accountOwnerId && !isEditing ? `/contacts/${safeAccount.accountOwnerId}` : undefined}
        />
        {/* @ts-ignore */}
        <InfoField 
          label="Phone" 
          value={safeEditedAccount.phone} 
          editable={isEditing}
          onChange={(value) => handleFieldChange('phone', value)}
        />
      </div>

      {/* Tabs */}
      {/* @ts-ignore */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        {/* @ts-ignore */}
        <TabsList>
          {/* @ts-ignore */}
          <TabsTrigger value="related">Related</TabsTrigger>
          {/* @ts-ignore */}
          <TabsTrigger value="details">Details</TabsTrigger>
        </TabsList>
        
        {/* @ts-ignore */}
        <TabsContents className="mt-6">
          {/* @ts-ignore */}
          <TabsContent value="related">
            <RelatedTab />
          </TabsContent>
          {/* @ts-ignore */}
          <TabsContent value="details">
            <DetailsTab />
          </TabsContent>
        </TabsContents>
      </Tabs>


      {/* Edit Account Modal */}
      <AccountEditModal
        open={editModalOpen}
        onOpenChange={setEditModalOpen}
        initialValues={{
          name: safeEditedAccount.name,
          website: safeEditedAccount.website === 'N/A' ? '' : safeEditedAccount.website,
          email: (apiAccount as any)?.email || '',
          phone: safeEditedAccount.phone === 'N/A' ? '' : safeEditedAccount.phone,
        }}
        isSaving={updateAccountMutation.isPending}
        onSave={async (vals) => {
          try {
            // Prepare payload: only send allowed, non-empty fields
            const payload: Partial<ApiAccount> = {}
            if (typeof vals.name === 'string' && vals.name.trim().length > 0) payload.name = vals.name.trim()
            if (typeof vals.website === 'string' && vals.website.trim().length > 0) payload.website = vals.website.trim()
            if (typeof vals.phone === 'string' && vals.phone.trim().length > 0) payload.phone = vals.phone.trim()
            // Do not send email; not supported by account update API

            await updateAccountMutation.mutateAsync({ id: accountId, data: payload })
            toast.success('Account updated successfully!')
            onSave?.()
          } catch (error) {
            if ((error as any)?.response?.status === 403) {
              toast.error('Only System Admin can update accounts.')
            } else {
              toast.error('Failed to update account. Please try again.')
            }
            throw error
          }
        }}
      />
    </div>
  )
})
