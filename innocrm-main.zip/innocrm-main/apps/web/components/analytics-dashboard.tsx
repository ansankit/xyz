"use client"

import React from 'react';
import { AnalyticsOverview } from './analytics-overview';
import { KeyMetrics } from './key-metrics';
import { RecentActivity } from './recent-activity';
import { TopPerformingCampaigns } from './top-campaigns';
import { ChartSkeleton, SectionSkeleton, StatGridSkeleton } from './skeletons';

export function AnalyticsDashboard() {
  return (
    <div className="space-y-6 p-6">
      {/* Page Title */}
      <div>
        <h1 className="text-3xl font-medium tracking-tight">Analytics Overview</h1>
        <p className="text-muted-foreground">
          Monitor your marketing performance and track key metrics
        </p>
      </div>

      {/* Analytics Overview Cards */}
      <AnalyticsOverview />

      {/* Key Metrics */}
      <KeyMetrics />

      {/* Bottom Section - Two Columns */}
      <div className="grid gap-6 md:grid-cols-2">
        {/* Recent Activity */}
        <RecentActivity />
        
        {/* Top Performing Campaigns */}
        <TopPerformingCampaigns />
      </div>
    </div>
  );
}

export function AnalyticsDashboardSkeleton() {
  return (
    <div className="space-y-6 p-6">
      <div className="space-y-2">
        <SectionSkeleton titleWidth="w-64">
          <div className="space-y-2">
            <ChartSkeleton height={24} />
            <ChartSkeleton height={16} />
          </div>
        </SectionSkeleton>
      </div>
      <SectionSkeleton>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {[...Array(3)].map((_, idx) => (
            <ChartSkeleton key={idx} height={180} />
          ))}
        </div>
      </SectionSkeleton>
      <StatGridSkeleton count={6} />
      <div className="grid gap-6 md:grid-cols-2">
        <SectionSkeleton>
          <ChartSkeleton height={220} />
        </SectionSkeleton>
        <SectionSkeleton>
          <ChartSkeleton height={220} />
        </SectionSkeleton>
      </div>
    </div>
  );
}
