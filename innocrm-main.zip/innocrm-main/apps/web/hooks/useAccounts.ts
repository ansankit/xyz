import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { accountService } from '../lib/api/services';
import { Account, PaginatedApiResponse, PaginationMeta } from '../lib/api/types';

// Query keys
export const accountKeys = {
  all: ['accounts'] as const,
  lists: () => [...accountKeys.all, 'list'] as const,
  list: (filters: { page?: number; limit?: number }) => [...accountKeys.lists(), { page: filters?.page, limit: filters?.limit }] as const,
  details: () => [...accountKeys.all, 'detail'] as const,
  detail: (id: number) => [...accountKeys.details(), id] as const,
};

// Hooks for fetching accounts
export function useAccounts(filters?: { page?: number; limit?: number }) {
  return useQuery({
    queryKey: accountKeys.list(filters || {}),
    queryFn: () => accountService.getAllAccounts(filters),
  });
}

// Hook that returns both data and pagination metadata
export function useAccountsWithPagination(filters?: { page?: number; limit?: number }, options?: { enabled?: boolean }) {
  const queryKey = accountKeys.list(filters || {});
  
  const query = useQuery({
    queryKey,
    queryFn: () => {
      console.log('🔄 Fetching accounts - Page:', filters?.page, 'Limit:', filters?.limit);
      return accountService.getAllAccounts(filters);
    },
    enabled: options?.enabled !== undefined ? options.enabled : true,
    staleTime: 5 * 60 * 1000, // 5 minutes
    refetchOnWindowFocus: false,
    refetchOnMount: false,
  });

  console.log('📊 Query result - Page:', filters?.page, 'Data length:', query.data?.data?.length || 0, 'Total pages:', query.data?.pagination?.totalPages);

  return {
    ...query,
    data: query.data?.data || [],
    pagination: query.data?.pagination,
  };
}

export function useAccount(id: number) {
  return useQuery({
    queryKey: accountKeys.detail(id),
    queryFn: () => accountService.getAccountDetails(id),
    enabled: !!id,
  });
}

export function useDeleteAccount() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: accountService.deleteAccount,
    meta: { successMessage: 'Account deleted successfully' },
    onSuccess: (_: void, deletedId: number) => {
      // Remove the account detail cache
      queryClient.removeQueries({ queryKey: accountKeys.detail(deletedId) });
      // Invalidate list queries
      queryClient.invalidateQueries({ queryKey: accountKeys.lists() });
    },
  });
}

export function useUpdateAccount() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ id, data }: { id: number; data: Partial<Account> }) =>
      accountService.updateAccount(id, data),
    meta: { successMessage: 'Account updated successfully' },
    onSuccess: (updated) => {
      queryClient.setQueryData(accountKeys.detail(updated.id), updated);
      queryClient.invalidateQueries({ queryKey: accountKeys.lists() });
    },
  });
}