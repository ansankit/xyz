import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { userService } from '../lib/api/services';
import { User, UserFilters, UserPermissions } from '../lib/api/types';

// Query keys
export const userKeys = {
  all: ['users'] as const,
  lists: () => [...userKeys.all, 'list'] as const,
  list: (filters: UserFilters) => [...userKeys.lists(), filters] as const,
  details: () => [...userKeys.all, 'detail'] as const,
  detail: (id: number) => [...userKeys.details(), id] as const,
};

// Hooks for fetching users
export function useUsers(filters?: UserFilters, options?: { enabled?: boolean }) {
  return useQuery({
    queryKey: userKeys.list(filters || {}),
    queryFn: () => userService.getAllUsers(filters),
    enabled: options?.enabled ?? true,
  });
}

export function useUser(id: number) {
  return useQuery({
    queryKey: userKeys.detail(id),
    queryFn: () => userService.getUserById(id),
    enabled: !!id,
  });
}

// Hooks for user mutations
export function useCreateUser() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: userService.createUser,
    meta: { successMessage: 'User created successfully' },
    onSuccess: () => {
      // Invalidate and refetch users
      queryClient.invalidateQueries({ queryKey: userKeys.all });
    },
  });
}

export function useUpdateUser() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ id, data }: { id: number; data: Partial<User> }) =>
      userService.updateUser(id, data),
    meta: { successMessage: 'User updated successfully' },
    onSuccess: (updatedUser) => {
      // Update the specific user in cache
      queryClient.setQueryData(userKeys.detail(updatedUser.id), updatedUser);
      // Invalidate lists to refetch
      queryClient.invalidateQueries({ queryKey: userKeys.lists() });
    },
  });
}

export function useDeleteUser() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: userService.deleteUser,
    meta: { successMessage: 'User deleted successfully' },
    onSuccess: (_, deletedId) => {
      // Remove the user from cache
      queryClient.removeQueries({ queryKey: userKeys.detail(deletedId) });
      // Invalidate lists to refetch
      queryClient.invalidateQueries({ queryKey: userKeys.lists() });
    },
  });
}

export function useUpdateUserPermissions() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ id, permissions }: { id: number; permissions: Partial<UserPermissions> }) =>
      userService.updateUserPermissions(id, permissions),
    meta: { successMessage: 'Permissions updated successfully' },
    onSuccess: (updatedPermissions, { id }) => {
      // Update the user's permissions in cache
      queryClient.setQueryData(userKeys.detail(id), (oldUser: User | undefined) => {
        if (oldUser) {
          return { ...oldUser, permissions: updatedPermissions };
        }
        return oldUser;
      });
      // Invalidate lists to refetch
      queryClient.invalidateQueries({ queryKey: userKeys.lists() });
    },
  });
}

