"use client"

import React, { useEffect, useMemo, useState } from "react"
import { useRouter } from "next/navigation"
import { Card } from "@repo/ui"
import { Button } from "@repo/ui"
import { Input } from "@repo/ui"
import { Textarea } from "@repo/ui"
import { Label } from "@repo/ui"
import { Select, SelectTrigger, SelectContent, SelectItem, SelectValue } from "@repo/ui/components/ui/select"
import { whatsappService, campaignService } from "@/lib/api/services"

export default function NewWhatsappCampaignPage() {
  const router = useRouter()
  const [name, setName] = useState("")
  const [accountId, setAccountId] = useState<number | undefined>(undefined)
  const [templateName, setTemplateName] = useState("")
  const [toAudience, setToAudience] = useState("all")
  const [messageParams, setMessageParams] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [accounts, setAccounts] = useState<any[]>([])
  const [templates, setTemplates] = useState<any[]>([])
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const load = async () => {
      try {
        const acc = await whatsappService.listAccounts()
        setAccounts(acc)
      } catch (e: any) {
        setError("Failed to load accounts")
      }
    }
    load()
  }, [])

  useEffect(() => {
    if (!accountId) return
    const loadTemplates = async () => {
      try {
        const t = await whatsappService.listTemplates(accountId)
        setTemplates(t)
      } catch (e: any) {
        setError("Failed to load templates")
      }
    }
    loadTemplates()
  }, [accountId])

  const canSubmit = useMemo(() => name && accountId && templateName, [name, accountId, templateName])

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!canSubmit) return
    setIsSubmitting(true)
    setError(null)
    try {
      const payload = {
        name,
        channel: "whatsapp",
        accountId,
        templateName,
        toAudience,
        params: messageParams ? JSON.parse(messageParams) : {},
      }
      const created = await whatsappService.createCampaign(payload)
      router.push(`/campaigns/whatsapp/${created.id}`)
    } catch (err: any) {
      setError(err?.message || "Failed to create campaign")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="container mx-auto p-6">
      <div className="mb-4">
        <h1 className="text-2xl font-semibold">New WhatsApp Campaign</h1>
        <p className="text-sm text-muted-foreground">Configure account, template and audience</p>
      </div>
      <form onSubmit={onSubmit} className="grid gap-4 max-w-2xl">
        <Card className="p-4 grid gap-4">
          {error && <div className="text-red-600 text-sm">{error}</div>}
          <div className="grid gap-2">
            <Label htmlFor="name">Campaign name</Label>
            <Input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Spring Promo" />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="account">WhatsApp Account</Label>
            <Select value={accountId !== undefined ? String(accountId) : ""} onValueChange={(v) => setAccountId(v ? Number(v) : undefined)}>
              <SelectTrigger className="h-9">
                <SelectValue placeholder="Select account…" />
              </SelectTrigger>
              <SelectContent>
                {accounts.map((a) => (
                  <SelectItem key={a.id} value={String(a.id)}>{a.name || `Account #${a.id}`}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="template">Template</Label>
            <Select value={templateName} onValueChange={(v) => setTemplateName(v)}>
              <SelectTrigger className="h-9">
                <SelectValue placeholder="Select template…" />
              </SelectTrigger>
              <SelectContent>
                {templates.map((t) => (
                  <SelectItem key={t.name} value={t.name}>{t.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="audience">Audience</Label>
            <Select value={toAudience} onValueChange={(v) => setToAudience(v)}>
              <SelectTrigger className="h-9">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All contacts</SelectItem>
                <SelectItem value="leads">All leads</SelectItem>
                <SelectItem value="segment">Saved segment…</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="params">Template parameters (JSON)</Label>
            <Textarea id="params" value={messageParams} onChange={(e) => setMessageParams(e.target.value)} placeholder='{"name":"John"}' rows={6} />
          </div>
          <div className="flex gap-2 justify-end">
            <Button type="button" variant="secondary" onClick={() => router.push('/campaigns/whatsapp')}>Cancel</Button>
            <Button type="submit" disabled={!canSubmit || isSubmitting}>{isSubmitting ? 'Creating…' : 'Create campaign'}</Button>
          </div>
        </Card>
      </form>
    </div>
  )
}


