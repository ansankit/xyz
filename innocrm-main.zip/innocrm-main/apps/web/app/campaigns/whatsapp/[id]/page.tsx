"use client"

import React, { useEffect, useRef, useState } from "react"
import { useRouter, useParams } from "next/navigation"
import { CampaignDetailPage } from "@/components/campaign-detail-page"
import { whatsappService } from "@/lib/api/services"

export const runtime = 'edge';

const fakeCampaigns = [
  {
    id: "5",
    name: "Referral Program",
    channel: "WhatsApp",
    status: "Active",
    startDate: "Sep 26, 2025",
    endDate: "Nov 30, 2025",
    createdBy: "Jessica Williams",
    numMessages: 203,
    openRate: 52.3,
    clickRate: 31.2,
  },
]

export default function WhatsappCampaignDetailPage() {
  const router = useRouter()
  const params = useParams()
  const idParam = params?.id as string
  const id = Number(idParam)
  const [deliveries, setDeliveries] = useState<any[]>([])
  const [events, setEvents] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [hasLoaded, setHasLoaded] = useState(false)
  const intervalRef = useRef<any>(null)

  const campaign = fakeCampaigns.find((c) => c.id === idParam) as any

  const handleBack = () => {
    router.push("/campaigns/whatsapp")
  }

  useEffect(() => {
    if (!id) return
    let canceled = false

    const load = async () => {
      try {
        if (!hasLoaded) setLoading(true)
        const [d, e] = await Promise.all([
          whatsappService.listDeliveries(id),
          whatsappService.listEvents(id),
        ])
        if (canceled) return
        setDeliveries(d)
        setEvents(e)
        setError(null)
        setHasLoaded(true)
      } catch (err: any) {
        if (canceled) return
        setError(err?.message || "Failed to load campaign data")
      } finally {
        if (!canceled) setLoading(false)
      }
    }

    const startPolling = () => {
      if (intervalRef.current) return
      intervalRef.current = setInterval(() => {
        if (document.visibilityState === 'visible') {
          load()
        }
      }, 5000)
    }

    const stopPolling = () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current)
        intervalRef.current = null
      }
    }

    const handleVisibility = () => {
      if (document.visibilityState === 'visible') {
        load()
        startPolling()
      } else {
        stopPolling()
      }
    }

    load()
    startPolling()
    document.addEventListener('visibilitychange', handleVisibility)

    return () => {
      canceled = true
      stopPolling()
      document.removeEventListener('visibilitychange', handleVisibility)
    }
  }, [id, hasLoaded])

  if (!campaign) {
    return (
      <div className="container mx-auto p-6">
        <p>Campaign not found</p>
        <button onClick={handleBack}>Back</button>
      </div>
    )
  }

  return <CampaignDetailPage campaign={campaign} onBack={handleBack} deliveries={deliveries} events={events} loading={loading} error={error} onRetry={() => {
    // trigger manual reload
    (async () => {
      try {
        setLoading(true)
        const [d, e] = await Promise.all([
          whatsappService.listDeliveries(id),
          whatsappService.listEvents(id),
        ])
        setDeliveries(d)
        setEvents(e)
        setError(null)
      } catch (err: any) {
        setError(err?.message || "Failed to load campaign data")
      } finally {
        setLoading(false)
      }
    })()
  }} />
}


