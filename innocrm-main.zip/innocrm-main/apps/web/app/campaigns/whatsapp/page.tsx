"use client"

import React, { useMemo, useState } from "react"
import { useRouter } from "next/navigation"
import { CampaignTable, Campaign } from "@/components/campaign-table"
import { CampaignFilterValues } from "@/components/campaign-filter"
import Link from "next/link"
import { Button } from "@repo/ui"

function paginateArray<T>(array: T[], page: number, limit: number): { data: T[]; totalPages: number; totalCount: number } {
  const startIndex = (page - 1) * limit
  const endIndex = startIndex + limit
  const paginatedData = array.slice(startIndex, endIndex)
  const totalPages = Math.ceil(array.length / limit)

  return {
    data: paginatedData,
    totalPages,
    totalCount: array.length,
  }
}

const fakeCampaigns: Campaign[] = [
  {
    id: "5",
    name: "Referral Program",
    channel: "WhatsApp",
    status: "Active",
    startDate: "Sep 26, 2025",
    endDate: "Nov 30, 2025",
    createdBy: "Jessica Williams",
    numMessages: 203,
    openRate: 52.3,
    clickRate: 31.2,
  },
]

export default function WhatsappCampaignsPage() {
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState("")
  const [filters, setFilters] = useState<CampaignFilterValues>({})
  const [currentPage, setCurrentPage] = useState(1)
  const [itemsPerPage, setItemsPerPage] = useState(10)

  const handleCampaignClick = (campaign: Campaign) => {
    router.push(`/campaigns/whatsapp/${campaign.id}`)
  }

  const filteredCampaigns = useMemo(() => {
    let filtered = fakeCampaigns.filter((c) => c.channel === "WhatsApp")

    if (searchQuery) {
      filtered = filtered.filter(
        (campaign) =>
          campaign.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          campaign.createdBy.toLowerCase().includes(searchQuery.toLowerCase())
      )
    }

    // Status filter
    if (filters.status && filters.status.trim() !== "") {
      const filterStatus = filters.status.toLowerCase().trim()
      filtered = filtered.filter((campaign) => {
        const campaignStatus = campaign.status?.toLowerCase().trim() || ""
        return campaignStatus === filterStatus
      })
    }

    if (currentPage > 1 && filtered.length <= (currentPage - 1) * itemsPerPage) {
      setCurrentPage(1)
    }

    return filtered
  }, [searchQuery, filters, currentPage, itemsPerPage])

  const paginatedData = useMemo(() => {
    return paginateArray(filteredCampaigns, currentPage, itemsPerPage)
  }, [filteredCampaigns, currentPage, itemsPerPage])

  const handleItemsPerPageChange = (value: number) => {
    setItemsPerPage(value)
    setCurrentPage(1)
  }

  return (
    <div className="container mx-auto p-6">
      {paginatedData.data.length === 0 ? (
        <div className="rounded-md border p-8 text-center text-muted-foreground">
          No WhatsApp campaigns yet. <Link href="/campaigns/whatsapp/new" className="underline">Create your first campaign</Link>.
        </div>
      ) : null}
      <CampaignTable
        campaigns={paginatedData.data}
        title="WhatsApp Campaigns"
        subtitle="Browse and manage your WhatsApp campaigns"
        searchQuery={searchQuery}
        filters={filters}
        channelFilter={"WhatsApp"}
        currentPage={currentPage}
        totalPages={paginatedData.totalPages}
        totalCount={paginatedData.totalCount}
        itemsPerPage={itemsPerPage}
        onSearchChange={(value) => {
          setSearchQuery(value)
          setCurrentPage(1)
        }}
        onFilterChange={(newFilters) => {
          setFilters(newFilters)
          setCurrentPage(1)
        }}
        onPageChange={setCurrentPage}
        onItemsPerPageChange={handleItemsPerPageChange}
        onCampaignClick={handleCampaignClick}
      />
    </div>
  )
}


