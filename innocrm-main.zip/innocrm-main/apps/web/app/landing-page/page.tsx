export default function LandingPage() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Landing Page</h1>
      <p className="text-sm text-muted-foreground">This is a placeholder for your landing page builder.</p>
    </div>
  );
}


