import type { Metadata } from "next";
import localFont from "next/font/local";
import "@repo/ui/globals.css";
import { AuthProvider } from "@/contexts/AuthContext";
import { QueryProvider } from "@/providers/QueryProvider";
import { AppLayoutWrapper } from "@/components/AppLayoutWrapper";
import { SalesRouteGuard } from "@/components/guards/SalesRouteGuard";
import { Toaster } from "@/components/ui/toaster";

const geistSans = localFont({
  src: "./fonts/GeistVF.woff",
  variable: "--font-geist-sans",
});
const geistMono = localFont({
  src: "./fonts/GeistMonoVF.woff",
  variable: "--font-geist-mono",
});

export const metadata: Metadata = {
  title: "CRM Suite",
  description: "Custom Marketing CRM Suite",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning className="h-full overflow-hidden">
      <body className={`${geistSans.variable} ${geistMono.variable} h-full overflow-hidden`} suppressHydrationWarning>
        <QueryProvider>
          <AuthProvider>
            <SalesRouteGuard>
              <AppLayoutWrapper>
                {children}
              </AppLayoutWrapper>
            </SalesRouteGuard>
          </AuthProvider>
        </QueryProvider>
        <Toaster
          position="top-center"
          richColors={true}
          closeButton={true}
          duration={5000}
          style={{ zIndex: 9999 }}
        />
      </body>
    </html>
  );
}
