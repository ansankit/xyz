"use client"

import React, { useState, useEffect } from "react"
import { Button, Input, Label } from "@repo/ui"
import { useAuth } from "@/contexts/AuthContext"
import { RoleGuard } from "@/components/guards/RoleGuard"
import { HeaderWrapper } from "@/components/header-wrapper"
import { salesService } from "@/lib/api/services"
import { Lead } from "@/lib/api/types"
import { getLeadFullName } from "@/lib/name"
import Image from "next/image"
import logo from '@/app/assets/images/logos/logo_v1.png'

interface LeadWithRemarks extends Lead {
  remarks?: Array<{
    id: number;
    remark: string;
    createdAt: string;
    user: {
      name: string;
      email: string;
    };
  }>;
}

interface Stats {
  totalLeads: number;
  qualifiedLeads: number;
  unqualifiedLeads: number;
  workingLeads: number;
  openLeads: number;
  convertedLeads: number;
  conversionRate: string;
  qualificationRate: string;
}

export default function SalesPage() {
  const { user } = useAuth()
  const [leads, setLeads] = useState<LeadWithRemarks[]>([])
  const [stats, setStats] = useState<Stats | null>(null)
  const [selectedLead, setSelectedLead] = useState<LeadWithRemarks | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [remarkText, setRemarkText] = useState("")
  const [submittingRemark, setSubmittingRemark] = useState(false)
  const [actionLoading, setActionLoading] = useState(false)

  // Fetch leads and stats
  useEffect(() => {
    fetchLeadsAndStats()
  }, [])

  const fetchLeadsAndStats = async () => {
    try {
      setLoading(true)
      const [{ leads, pagination }, { stats }] = await Promise.all([
        salesService.getMyLeads({ page: 1, limit: 100 }),
        salesService.getMyStats(),
      ])
      setLeads(leads as LeadWithRemarks[])
      setStats(stats)
    } catch (err: any) {
      setError(err.message || 'Failed to load data')
    } finally {
      setLoading(false)
    }
  }

  const handleViewLead = async (lead: LeadWithRemarks) => {
    try {
      const fullLead = await salesService.getLeadById(lead.id)
      setSelectedLead(fullLead as LeadWithRemarks)
    } catch (err) {
      setError('Failed to load lead details')
    }
  }

  const handleQualify = async () => {
    if (!selectedLead) return
    try {
      setActionLoading(true)
      await salesService.qualifyLead(selectedLead.id)

      // Update lead in list
      setLeads(prev => prev.map(l =>
        l.id === selectedLead.id ? { ...l, status: 'QUALIFIED' } : l
      ))

      // Update selected lead
      setSelectedLead(prev => prev ? { ...prev, status: 'QUALIFIED' } : null)

      // Refresh stats
      const statsData = await salesService.getMyStats()
      setStats(statsData.stats)
    } catch (err) {
      setError('Failed to qualify lead')
    } finally {
      setActionLoading(false)
    }
  }

  const handleDisqualify = async () => {
    if (!selectedLead) return
    try {
      setActionLoading(true)
      await salesService.disqualifyLead(selectedLead.id)

      // Update lead in list
      setLeads(prev => prev.map(l =>
        l.id === selectedLead.id ? { ...l, status: 'UNQUALIFIED' } : l
      ))

      // Update selected lead
      setSelectedLead(prev => prev ? { ...prev, status: 'UNQUALIFIED' } : null)

      // Refresh stats
      const statsData = await salesService.getMyStats()
      setStats(statsData.stats)
    } catch (err) {
      setError('Failed to disqualify lead')
    } finally {
      setActionLoading(false)
    }
  }

  const handleAddRemark = async () => {
    if (!selectedLead || !remarkText.trim()) return
    try {
      setSubmittingRemark(true)
      const result = await salesService.addRemark(selectedLead.id, remarkText)

      // Update selected lead with new remark
      setSelectedLead(prev => {
        if (!prev) return null
        return {
          ...prev,
          remarks: [result.remark, ...(prev.remarks || [])]
        }
      })

      setRemarkText("")
    } catch (err) {
      setError('Failed to add remark')
    } finally {
      setSubmittingRemark(false)
    }
  }

  if (loading) {
    return (
      <RoleGuard allowedRoles={['SALES']}>
        <div className="flex items-center justify-center min-h-screen">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
        </div>
      </RoleGuard>
    )
  }

  return (
    <RoleGuard allowedRoles={['SALES']}>
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <HeaderWrapper
          icon={
            <Image
              src={logo}
              alt="Company Logo"
              width={120}
              height={40}
              className="object-contain"
            />
          }
          hideNotifications={true}
        />

        {/* Content Area */}
        <div className="max-w-7xl mx-auto px-4 py-6">
          {/* Error Message */}
          {error && (
            <div className="mb-4 bg-red-50 border border-red-200 rounded-lg px-4 py-3 flex justify-between items-center">
              <p className="text-red-800 text-sm">{error}</p>
              <button
                onClick={() => setError(null)}
                className="text-red-600 hover:text-red-800 text-sm font-medium"
              >
                ✕
              </button>
            </div>
          )}
          {/* Stats Section */}
          {/* {stats && !selectedLead && (
            <div className="mb-6">
              <h2 className="text-lg font-semibold mb-3">My Performance</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-white p-4 rounded-lg shadow">
                  <p className="text-sm text-gray-600">Total Leads</p>
                  <p className="text-2xl font-bold">{stats.totalLeads}</p>
                </div>
                <div className="bg-green-50 p-4 rounded-lg shadow">
                  <p className="text-sm text-green-600">Qualified</p>
                  <p className="text-2xl font-bold text-green-700">{stats.qualifiedLeads}</p>
                </div>
                <div className="bg-red-50 p-4 rounded-lg shadow">
                  <p className="text-sm text-red-600">Unqualified</p>
                  <p className="text-2xl font-bold text-red-700">{stats.unqualifiedLeads}</p>
                </div>
                <div className="bg-blue-50 p-4 rounded-lg shadow">
                  <p className="text-sm text-blue-600">Conversion Rate</p>
                  <p className="text-2xl font-bold text-blue-700">{stats.conversionRate}%</p>
                </div>
              </div>
            </div>
          )} */}

          {/* Detail View */}
          {selectedLead ? (
            <div>
              <Button
                variant="outline"
                onClick={() => setSelectedLead(null)}
                className="mb-4"
              >
                ← Back to Leads
              </Button>

              <div className="bg-white rounded-lg shadow-lg p-6 space-y-6">
                {/* Lead Info */}
                <div>
                  <h1 className="text-2xl font-bold mb-4">{getLeadFullName(selectedLead.firstName, selectedLead.lastName)}</h1>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label className="text-sm text-gray-600">Email</Label>
                      {selectedLead.email ? (
                        <a
                          href={`mailto:${selectedLead.email}`}
                          className="font-medium text-blue-600 hover:underline"
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          {selectedLead.email}
                        </a>
                      ) : (
                        <p className="font-medium">-</p>
                      )}
                    </div>
                    <div>
                      <Label className="text-sm text-gray-600">Phone</Label>
                      {selectedLead.phone ? (
                        <a
                          href={`tel:${selectedLead.phone}`}
                          className="font-medium text-blue-600 hover:underline"
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          {selectedLead.phone}
                        </a>
                      ) : (
                        <p className="font-medium">-</p>
                      )}
                    </div>
                    <div>
                      <Label className="text-sm text-gray-600">Company</Label>
                      <p className="font-medium">{selectedLead.companyName || '-'}</p>
                    </div>
                    <div>
                      <Label className="text-sm text-gray-600">Status</Label>
                      <span className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${
                        selectedLead.status === 'QUALIFIED' ? 'bg-green-100 text-green-800' :
                        selectedLead.status === 'UNQUALIFIED' ? 'bg-red-100 text-red-800' :
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {selectedLead.status || 'OPEN'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-3 border-t pt-4">
                  <Button
                    onClick={handleQualify}
                    disabled={actionLoading || selectedLead.status === 'QUALIFIED'}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    {selectedLead.status === 'QUALIFIED' ? '✓ Qualified' : 'Qualify Lead'}
                  </Button>
                  <Button
                    onClick={handleDisqualify}
                    disabled={actionLoading || selectedLead.status === 'UNQUALIFIED'}
                    variant="destructive"
                  >
                    {selectedLead.status === 'UNQUALIFIED' ? '✓ Disqualified' : 'Disqualify Lead'}
                  </Button>
                </div>

                {/* Add Remark */}
                <div className="border-t pt-4">
                  <Label className="text-sm font-semibold mb-2 block">Add Remark</Label>
                  <div className="flex gap-2">
                    <Input
                      value={remarkText}
                      onChange={(e) => setRemarkText(e.target.value)}
                      placeholder="Enter your remark..."
                      className="flex-1"
                      disabled={submittingRemark}
                    />
                    <Button
                      onClick={handleAddRemark}
                      disabled={submittingRemark || !remarkText.trim()}
                    >
                      {submittingRemark ? 'Adding...' : 'Add'}
                    </Button>
                  </div>
                </div>

                {/* Remarks History */}
                {selectedLead.remarks && selectedLead.remarks.length > 0 && (
                  <div className="border-t pt-4">
                    <Label className="text-sm font-semibold mb-3 block">Remarks History</Label>
                    <div className="space-y-3">
                      {selectedLead.remarks.map((remark) => (
                        <div key={remark.id} className="bg-gray-50 p-3 rounded-lg">
                          <p className="text-sm">{remark.remark}</p>
                          <p className="text-xs text-gray-500 mt-1">
                            {remark.user.name} - {new Date(remark.createdAt).toLocaleString()}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ) : (
            /* List View */
            <div>
              <h1 className="text-2xl font-bold mb-6">Assigned Leads</h1>

              {leads.length === 0 ? (
                <div className="bg-white rounded-lg shadow p-8 text-center">
                  <p className="text-gray-600">No leads assigned to you yet</p>
                </div>
              ) : (
                <div className="grid gap-4">
                  {leads.map((lead) => (
                    <div
                      key={lead.id}
                      className="bg-white rounded-lg shadow p-4 hover:shadow-md transition-shadow cursor-pointer"
                      onClick={() => handleViewLead(lead)}
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-semibold text-lg">{getLeadFullName(lead.firstName, lead.lastName)}</h3>
                          <p className="text-sm text-gray-600">{lead.email}</p>
                          {lead.companyName && (
                            <p className="text-sm text-gray-500">{lead.companyName}</p>
                          )}
                        </div>
                        <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                          lead.status === 'QUALIFIED' ? 'bg-green-100 text-green-800' :
                          lead.status === 'UNQUALIFIED' ? 'bg-red-100 text-red-800' :
                          'bg-gray-100 text-gray-800'
                        }`}>
                          {lead.status || 'OPEN'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </RoleGuard>
  )
}
