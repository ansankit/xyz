import { LoginForm } from "@/components/login-form"

export default function LoginPage() {
  return (
    <div className="bg-muted flex min-h-svh flex-col items-center justify-center">
      <div className="w-full h-full max-h-fit">
        <LoginForm />
      </div>
    </div>
  )
}
