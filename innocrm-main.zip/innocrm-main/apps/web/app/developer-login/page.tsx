import { DeveloperLoginForm } from "@/components/DeveloperLoginForm";

export default function DeveloperLoginPage() {
  return <DeveloperLoginForm />;
}

