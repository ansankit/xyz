"use client";

import { useMemo, useState, useEffect } from "react";
import { SearchInput, Button, Label, Separator, Checkbox, Input, ConfirmationDialog, Badge } from "@repo/ui";
import { DataTable, type TableColumn } from "../../../components/data-table";
import { ProtectedRoute } from "../../../components/ProtectedRoute";
import { RoleGuard } from "../../../components/guards/RoleGuard";
import { userService } from "../../../lib/api/services";
import { toast } from '../../../lib/toast';
import { validateEmail, validatePhoneOptional, validateName } from '../../../lib/validation';
import { SkeletonLine, TableSkeleton, ToolbarSkeleton } from "../../../components/skeletons";

type User = {
  id: string;
  name: string;
  email: string;
  phone?: string;
  role: string;
  region?: string;
  createdAt: string;
};

// Helper function to format region for display
const formatRegion = (region?: string): string => {
  if (!region) return '-';
  const regionMap: Record<string, string> = {
    'SOUTH': 'South',
    'NORTH': 'North',
    'EAST': 'East',
    'WEST_1': 'West 1',
    'WEST_2': 'West 2',
    'APTOC': 'APTOC',
  };
  return regionMap[region] || region;
};

// Remove mock data - we'll use real API data

export default function UserManagementPage() {
  const [query, setQuery] = useState("");
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [selectedUsers, setSelectedUsers] = useState<string[]>([]);
  const [newUser, setNewUser] = useState({ name: "", email: "", phone: "", role: "SALES", region: "" });
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [validationErrors, setValidationErrors] = useState<{ name?: string; email?: string; phone?: string; region?: string }>({});

  useEffect(() => {
    async function fetchUsers() {
      try {
        setLoading(true);
        const fetchedUsers = await userService.getAllUsers();
        // Map all users including SYSTEM_ADMIN
        const mappedUsers = (fetchedUsers || []).map((u) => ({
          id: u.id.toString(),
          name: u.name,
          email: u.email,
          phone: u.phone || '',
          role: String(u.role || ''),
          region: u.region || '',
          createdAt: typeof u.createdAt === 'string' ? u.createdAt : new Date(u.createdAt as any).toISOString(),
        }));
        
        // Sort: SYSTEM_ADMIN first, then others
        const sortedUsers = mappedUsers.sort((a, b) => {
          if (a.role === 'SYSTEM_ADMIN' && b.role !== 'SYSTEM_ADMIN') return -1;
          if (a.role !== 'SYSTEM_ADMIN' && b.role === 'SYSTEM_ADMIN') return 1;
          return 0;
        });
        
        setUsers(sortedUsers);
      } catch (err) {
        setError('Failed to load users');
        setUsers([]);
      } finally {
        setLoading(false);
      }
    }
    fetchUsers();
  }, []);

  // Filter users based on search query
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return users;

    const filteredUsers = users.filter((user) => {
      const nameMatch = user.name.toLowerCase().includes(q);
      const emailMatch = user.email.toLowerCase().includes(q);
      const roleMatch = user.role.toLowerCase().includes(q);
      const phoneMatch = user.phone?.toLowerCase().includes(q) || false;
      const regionMatch = formatRegion(user.region).toLowerCase().includes(q);
      const createdAtMatch = new Date(user.createdAt).toLocaleDateString().toLowerCase().includes(q);

      return nameMatch || emailMatch || roleMatch || phoneMatch || regionMatch || createdAtMatch;
    });
    
    // Ensure SYSTEM_ADMIN stays first even after filtering
    return filteredUsers.sort((a, b) => {
      if (a.role === 'SYSTEM_ADMIN' && b.role !== 'SYSTEM_ADMIN') return -1;
      if (a.role !== 'SYSTEM_ADMIN' && b.role === 'SYSTEM_ADMIN') return 1;
      return 0;
    });
  }, [query, users]);

  const handleCreateUser = async () => {
    // Validate before submission
    const nameValidation = validateName(newUser.name);
    const emailValidation = validateEmail(newUser.email);
    const phoneValidation = validatePhoneOptional(newUser.phone);

    const errors: { name?: string; email?: string; phone?: string; region?: string } = {};
    if (!nameValidation.isValid) errors.name = nameValidation.error;
    if (!emailValidation.isValid) errors.email = emailValidation.error;
    if (!phoneValidation.isValid) errors.phone = phoneValidation.error;
    // Region is required for non-SYSTEM_ADMIN users
    if (newUser.role !== 'SYSTEM_ADMIN' && (!newUser.region || newUser.region.trim() === '')) {
      errors.region = 'Region is required';
    }

    setValidationErrors(errors);

    if (Object.keys(errors).length > 0) {
      return; // Don't submit if validation fails
    }

    try {
      setCreating(true);
      const op = userService.createUser(newUser as any);
      toast.promise(op, {
        loading: 'Creating new user...',
        success: 'User created successfully! Login credentials have been sent to their email.',
        error: (error: any) => {
          const title = error?.response?.data?.error || 'Failed to create user';
          const details = error?.response?.data?.details || error?.message;
          return details && details !== title ? `${title}: ${details}` : title;
        },
      });

      const createdUser = await op;

      setUsers((previousUsers) => {
        const newUser = {
          id: createdUser.id.toString(),
          name: createdUser.name,
          email: createdUser.email,
          phone: createdUser.phone || '',
          role: String(createdUser.role || 'SALES'),
          region: createdUser.region || '',
          createdAt: typeof createdUser.createdAt === 'string'
            ? createdUser.createdAt
            : new Date(createdUser.createdAt as unknown as string).toISOString(),
        };
        // Add new user while maintaining SYSTEM_ADMIN first
        const updatedUsers = [...previousUsers, newUser];
        return updatedUsers.sort((a, b) => {
          if (a.role === 'SYSTEM_ADMIN' && b.role !== 'SYSTEM_ADMIN') return -1;
          if (a.role !== 'SYSTEM_ADMIN' && b.role === 'SYSTEM_ADMIN') return 1;
          return 0;
        });
      });

      setNewUser({ name: '', email: '', phone: '', role: 'SALES', region: '' });
      setValidationErrors({});
      setIsCreateModalOpen(false);
    } catch (_err) {
      // Error toast handled by toast.promise above
    } finally {
      setCreating(false);
    }
  };

  const handleBulkDelete = async () => {
    try {
      // Filter out SYSTEM_ADMIN users from deletion
      const usersToDelete = selectedUsers.filter(userId => {
        const user = users.find(u => u.id === userId);
        return user && user.role !== 'SYSTEM_ADMIN';
      });
      
      const count = usersToDelete.length;
      if (count === 0) {
        toast.error('System admin users cannot be deleted');
        setSelectedUsers([]);
        setIsDeleteModalOpen(false);
        return;
      }

      const op = Promise.all(
        usersToDelete.map(userId => userService.deleteUser(parseInt(userId)))
      );

      toast.promise(op, {
        loading: `Deleting ${count} user${count > 1 ? 's' : ''}...`,
        success: `Successfully deleted ${count} user${count > 1 ? 's' : ''}`,
        error: (error: any) => {
          const raw = error?.response?.data;
          const title = raw?.error || 'Failed to delete selected users';
          const details = raw?.details || error?.message || raw?.field;

          // Friendly mapping for common FK cases
          const code = raw?.code;
          const field = String(raw?.field || '').toLowerCase();
          const message = String(details || '').toLowerCase();

          if (code === 'FOREIGN_KEY_CONSTRAINT') {
            // Specific reported case from logs
            if (details && String(details).includes('lead_assignment_rules_assigned_user_id_fkey')) {
              return 'Cannot delete user: they are the assignee for existing leads. Please reassign those leads first.';
            }
            if (field.includes('lead_assignment_rules') || message.includes('lead assignment')) {
              return 'Cannot delete user: they are the assignee for existing leads. Please reassign those leads first.';
            }
            if (field.includes('owner') || message.includes('owner')) {
              return 'Cannot delete user: they are the assignee for existing leads. Please reassign those leads first.';
            }
          }

          return details && details !== title ? `${title}: ${details}` : title;
        },
      });

      await op;

      setUsers(prev => prev.filter(user => !usersToDelete.includes(user.id)));
      setSelectedUsers([]);
      setIsDeleteModalOpen(false);
    } catch (_err) {
      // Error toast handled by toast.promise
    }
  };

  const handleSelectUser = (userId: string, checked: boolean) => {
    // Prevent selecting SYSTEM_ADMIN users
    const user = users.find(u => u.id === userId);
    if (user && user.role === 'SYSTEM_ADMIN') {
      return; // Don't allow selection of SYSTEM_ADMIN
    }
    
    if (checked) {
      setSelectedUsers(prev => [...prev, userId]);
    } else {
      setSelectedUsers(prev => prev.filter(id => id !== userId));
    }
  };

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      // Only select users that are not SYSTEM_ADMIN
      setSelectedUsers(filtered.filter(user => user.role !== 'SYSTEM_ADMIN').map(user => user.id));
    } else {
      setSelectedUsers([]);
    }
  };

  const columns: TableColumn<User>[] = useMemo(
    () => [
      { key: "name", label: "Name", render: (_v, item) => <span className="text-muted-foreground py-4">{item.name}</span> },
      { key: "email", label: "Email", render: (_v, item) => <span className="text-muted-foreground py-4">{item.email}</span> },
      { key: "phone", label: "Phone", render: (_v, item) => <span className="text-muted-foreground py-4">{item.phone || '-'}</span> },
      {
        key: "role",
        label: "Role",
        render: (_v, item) => (
          <Badge 
            variant="secondary" 
            className={
              item.role === 'SYSTEM_ADMIN' 
                ? 'bg-red-100 text-red-800 hover:bg-red-100' 
                : item.role === 'ADMIN' 
                ? 'bg-purple-100 text-purple-800 hover:bg-purple-100' 
                : 'bg-blue-100 text-blue-800 hover:bg-blue-100'
            }
          >
            {item.role}
          </Badge>
        )
      },
      {
        key: "region",
        label: "Region",
        render: (_v, item) => (
          <Badge variant="outline" className="text-muted-foreground">
            {formatRegion(item.region)}
          </Badge>
        )
      },
      { 
        key: "createdAt", 
        label: "Created At", 
        render: (_v, item) => {
          const date = new Date(item.createdAt)
          const time = date.toLocaleTimeString('en-GB', {
            hour: '2-digit',
            minute: '2-digit',
            hour12: true
          })
          const dateStr = date.toLocaleDateString('en-GB', {
            day: '2-digit',
            month: '2-digit',
            year: '2-digit'
          })
          return <span className="text-muted-foreground py-2">{`${time}, ${dateStr}`}</span>
        }
      },
    ],
    []
  );

  const skeletonView = (
    <div className="p-6 space-y-6">
      <div className="space-y-2">
        <SkeletonLine className="h-8 w-72" />
        <SkeletonLine className="h-4 w-48" />
      </div>
      <div className="rounded-xl border bg-card/40 p-4 space-y-4">
        <ToolbarSkeleton />
        <TableSkeleton />
      </div>
    </div>
  );

  // Loader handling in return
  if (loading) {
    return (
      <ProtectedRoute fallback={skeletonView}>
        <RoleGuard allowedRoles={['SYSTEM_ADMIN']}>
          {skeletonView}
        </RoleGuard>
      </ProtectedRoute>
    );
  }

  return (
    <ProtectedRoute fallback={skeletonView}>
      <RoleGuard allowedRoles={['SYSTEM_ADMIN']}>
        <div className="p-6 space-y-4">
          {/* Success Message */}
          {successMessage && (
            <div className="bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded-lg">
              {successMessage}
            </div>
          )}

          {/* Error Message */}
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-lg">
              {error}
            </div>
          )}

          <div className="space-y-2">
            <h1 className="text-2xl font-semibold tracking-tight">User Management</h1>
            <p className="text-muted-foreground">
              Manage users and their roles
              {query && (
                <span className="ml-2 text-sm">
                  ({filtered.length} of {users.length} users)
                </span>
              )}
            </p>
          </div>

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <Label htmlFor="search">Search</Label>
          <div className="relative">
            <SearchInput
              id="search"
              placeholder="Search by name, email, or date..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="w-[280px]"
            />
            {query && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setQuery("")}
                className="absolute right-2 top-1/2 -translate-y-1/2 h-6 w-6 p-0"
              >
                ×
              </Button>
            )}
          </div>
        </div>
        <div className="flex items-center gap-2">
          {selectedUsers.length > 0 && (
            <Button 
              variant="destructive" 
              onClick={() => setIsDeleteModalOpen(true)}
            >
              Delete Selected ({selectedUsers.length})
            </Button>
          )}
          <Button variant="default" onClick={() => setIsCreateModalOpen(true)}>
            Create User
          </Button>
        </div>
      </div>

      <Separator />

          {filtered.length === 0 && query ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">
                No users found matching "{query}"
              </p>
              <Button
                variant="outline"
                onClick={() => setQuery("")}
                className="mt-2"
              >
                Clear Search
              </Button>
            </div>
          ) : (
            <DataTable<User>
              data={filtered}
              columns={columns}
              title="Users"
              count={filtered.length}
              showCheckboxes={true}
              selectedItems={selectedUsers}
              onSelectionChange={(ids) => {
                // Filter out SYSTEM_ADMIN users from selection
                const validIds = ids.filter(id => {
                  const user = filtered.find(u => u.id === id);
                  return user && user.role !== 'SYSTEM_ADMIN';
                });
                setSelectedUsers(validIds);
              }}
              isSearchMode={!!query}
              searchQuery={query}
              showFilter={true}
              customFilter={<></>}
            />
          )}

          {/* Create User Modal */}
          {isCreateModalOpen && (
            <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center">
              <div className="bg-background border rounded-lg p-6 w-full max-w-md">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h2 className="text-lg font-semibold">Create User</h2>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setIsCreateModalOpen(false);
                        setNewUser({ name: '', email: '', phone: '', role: 'SALES', region: '' });
                        setError(null);
                      }}
                    >
                      ×
                    </Button>
                  </div>

                  {error && (
                    <div className="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-lg text-sm">
                      {error}
                    </div>
                  )}

                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Name *</Label>
                      <Input
                        id="name"
                        value={newUser.name}
                        onChange={(e) => {
                          setNewUser(prev => ({ ...prev, name: e.target.value }));
                          if (validationErrors.name) {
                            const validation = validateName(e.target.value);
                            setValidationErrors(prev => ({
                              ...prev,
                              name: validation.isValid ? undefined : validation.error
                            }));
                          }
                        }}
                        placeholder="Enter user name"
                        disabled={creating}
                        aria-invalid={!!validationErrors.name}
                        aria-describedby={validationErrors.name ? "name-error" : undefined}
                      />
                      {validationErrors.name && (
                        <p id="name-error" className="text-xs text-red-600 mt-1">
                          {validationErrors.name}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="email">Email *</Label>
                      <Input
                        id="email"
                        type="email"
                        value={newUser.email}
                        onChange={(e) => {
                          setNewUser(prev => ({ ...prev, email: e.target.value }));
                          if (validationErrors.email) {
                            const validation = validateEmail(e.target.value);
                            setValidationErrors(prev => ({
                              ...prev,
                              email: validation.isValid ? undefined : validation.error
                            }));
                          }
                        }}
                        placeholder="Enter user email"
                        disabled={creating}
                        aria-invalid={!!validationErrors.email}
                        aria-describedby={validationErrors.email ? "email-error" : undefined}
                      />
                      {validationErrors.email && (
                        <p id="email-error" className="text-xs text-red-600 mt-1">
                          {validationErrors.email}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number</Label>
                      <Input
                        id="phone"
                        type="tel"
                        value={newUser.phone}
                        onChange={(e) => {
                          setNewUser(prev => ({ ...prev, phone: e.target.value }));
                          if (validationErrors.phone) {
                            const validation = validatePhoneOptional(e.target.value);
                            setValidationErrors(prev => ({
                              ...prev,
                              phone: validation.isValid ? undefined : validation.error
                            }));
                          }
                        }}
                        placeholder="Enter phone number"
                        disabled={creating}
                        aria-invalid={!!validationErrors.phone}
                        aria-describedby={validationErrors.phone ? "phone-error" : undefined}
                      />
                      {validationErrors.phone && (
                        <p id="phone-error" className="text-xs text-red-600 mt-1">
                          {validationErrors.phone}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="region">
                        Region {newUser.role !== 'SYSTEM_ADMIN' && '*'}
                      </Label>
                      <select
                        id="region"
                        value={newUser.region}
                        onChange={(e) => {
                          setNewUser(prev => ({ ...prev, region: e.target.value }));
                          if (validationErrors.region) {
                            setValidationErrors(prev => ({
                              ...prev,
                              region: undefined
                            }));
                          }
                        }}
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                        disabled={creating}
                        aria-invalid={!!validationErrors.region}
                        aria-describedby={validationErrors.region ? "region-error" : undefined}
                      >
                        <option value="" disabled={newUser.role !== 'SYSTEM_ADMIN'}>{newUser.role === 'SYSTEM_ADMIN' ? 'No Region (Optional)' : 'Select Region'}</option>
                        <option value="SOUTH">South</option>
                        <option value="NORTH">North</option>
                        <option value="EAST">East</option>
                        <option value="WEST_1">West 1</option>
                        <option value="WEST_2">West 2</option>
                        <option value="APTOC">APTOC</option>
                      </select>
                      {validationErrors.region && (
                        <p id="region-error" className="text-xs text-red-600 mt-1">
                          {validationErrors.region}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="role">Role *</Label>
                      <select
                        id="role"
                        value={newUser.role}
                        onChange={(e) => setNewUser(prev => ({ ...prev, role: e.target.value }))}
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                        disabled={creating}
                      >
                        <option value="SALES">Sales</option>
                        <option value="ADMIN">Admin</option>
                      </select>
                      <p className="text-xs text-muted-foreground">
                        Note: System Admin can only be created once and cannot be created here
                      </p>
                    </div>

                    <div className="bg-blue-50 border border-blue-200 text-blue-800 px-4 py-3 rounded-lg text-sm">
                      <p className="font-semibold">Important:</p>
                      <p>A random password will be auto-generated and sent to the user's email address.</p>
                    </div>
                  </div>

                  <div className="flex justify-end gap-2">
                    <Button
                      variant="outline"
                      onClick={() => {
                        setIsCreateModalOpen(false);
                        setError(null);
                        setValidationErrors({});
                      }}
                      disabled={creating}
                    >
                      Cancel
                    </Button>
                    <Button
                      onClick={handleCreateUser}
                      disabled={!newUser.name || !newUser.email || (newUser.role !== 'SYSTEM_ADMIN' && !newUser.region) || creating || Object.keys(validationErrors).length > 0}
                    >
                      {creating ? 'Creating...' : 'Create User'}
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Bulk Delete Confirmation Modal */}
          <ConfirmationDialog
            open={isDeleteModalOpen}
            onOpenChange={setIsDeleteModalOpen}
            onConfirm={handleBulkDelete}
            title="Delete Users"
            description={`Are you sure you want to delete ${selectedUsers.length} selected user(s)? This action cannot be undone.`}
            confirmText="Delete"
            variant="destructive"
          />
        </div>
      </RoleGuard>
    </ProtectedRoute>
  );
}


