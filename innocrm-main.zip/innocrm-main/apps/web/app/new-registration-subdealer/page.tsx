"use client";

import { SubdealerRegistrationForm } from "@/components/subdealer-registration-form";

export default function NewRegistrationSubdealerPage() {
  return (
    <main className="min-h-full w-full bg-muted py-8">
      <SubdealerRegistrationForm />
    </main>
  );
}
