'use client';

import React, { createContext, useContext, useEffect, useState, ReactNode, useCallback } from 'react';
import Cookies from 'js-cookie';
import { useRouter } from 'next/navigation';
import { authService } from '../lib/api/services';
import { User, LoginRequest, SignupRequest, LoginResponse, ApiError } from '../lib/api/types';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (credentials: LoginRequest) => Promise<User>;
  developerLogin: (credentials: LoginRequest) => Promise<User>;
  signup: (userData: SignupRequest) => Promise<void>;
  logout: () => Promise<void>;
  error: string | null;
  clearError: () => void;
  isDeveloper: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

interface AuthProviderProps {
  children: ReactNode;
}

export function AuthProvider({ children }: AuthProviderProps) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isDeveloper, setIsDeveloper] = useState(false);
  const router = useRouter();

  const isAuthenticated = !!user;

  const clearError = useCallback(() => setError(null), []);

  const persistAuthSession = (response: LoginResponse, overrideIsDeveloper?: boolean) => {
    const isDeveloperSession = overrideIsDeveloper ?? response.isDeveloper ?? response.user?.isDeveloper ?? false;

    Cookies.set('auth_token', response.token, { 
      expires: 7, // 7 days
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict'
    });

    const userData: User = {
      ...response.user,
      isDeveloper: isDeveloperSession,
    };

    setUser(userData);
    setIsDeveloper(isDeveloperSession);

    return userData;
  };

  const login = async (credentials: LoginRequest) => {
    try {
      setIsLoading(true);
      clearError();
      
      const response = await authService.login(credentials);
      return persistAuthSession(response);
    } catch (err) {
      const apiError = err as ApiError;
      setError(apiError.message || 'Login failed');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const developerLogin = async (credentials: LoginRequest) => {
    try {
      setIsLoading(true);
      clearError();

      const response = await authService.developerLogin(credentials);
      return persistAuthSession(response, true);
    } catch (err) {
      const apiError = err as ApiError;
      setError(apiError.message || 'Developer login failed');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const signup = async (userData: SignupRequest) => {
    try {
      setIsLoading(true);
      clearError();

      const response = await authService.signup(userData);

      persistAuthSession(response, false);
      router.push('/');
    } catch (err) {
      const apiError = err as ApiError;
      setError(apiError.message || 'Signup failed');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    try {
      await authService.logout();
    } catch (err) {
      const apiError = err as ApiError;
      setError(apiError.message || 'Logout failed');
    } finally {
      Cookies.remove('auth_token');
      setUser(null);
      setIsDeveloper(false);
      window.location.href = '/login';
    }
  };

  // Check if user is authenticated on mount
  useEffect(() => {
    const checkAuth = async () => {
      const token = Cookies.get('auth_token');
      
      if (!token) {
        setIsLoading(false);
        setIsDeveloper(false);
        return;
      }

      try {
        const currentUser = await authService.getCurrentUser();
        const sessionIsDeveloper = !!currentUser.isDeveloper;
        setUser({
          ...currentUser,
          isDeveloper: sessionIsDeveloper,
        });
        setIsDeveloper(sessionIsDeveloper);
      } catch (err) {
        // Token is invalid, clear it
        Cookies.remove('auth_token');
        setUser(null);
        setIsDeveloper(false);
      } finally {
        setIsLoading(false);
      }
    };

    checkAuth();
  }, []);

  const value: AuthContextType = {
    user,
    isAuthenticated,
    isLoading,
    login,
    developerLogin,
    signup,
    logout,
    error,
    clearError,
    isDeveloper,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

