// Central location for lead status badge styles
import { LeadStatus, LeadSource } from '@prisma/client';
import { BadgeProps } from '@repo/ui/components/ui/badge';

export const leadStatusConfig = {
  [LeadStatus.OPEN]: { label: 'OPEN', className: 'bg-blue-100 text-blue-800 hover:bg-blue-100', variant: 'outline' },
  [LeadStatus.WORKING]: { label: 'WORKING', className: 'bg-amber-100 text-amber-800 hover:bg-amber-100', variant: 'outline' },
  [LeadStatus.QUALIFIED]: { label: 'QUALIFIED', className: 'bg-green-100 text-green-800 hover:bg-green-100', variant: 'outline' },
  [LeadStatus.NURTURING]: { label: 'NURTURING', className: 'bg-purple-100 text-purple-800 hover:bg-purple-100', variant: 'outline' },
  [LeadStatus.CONVERTED]: { label: 'CONVERTED', className: 'bg-green-100 text-green-800 hover:bg-green-100', variant: 'outline' },
  [LeadStatus.UNQUALIFIED]: { label: 'UNQUALIFIED', className: 'bg-red-100 text-red-800 hover:bg-red-100', variant: 'outline' },
};

// Lead source display labels
export const leadSourceLabels: Record<LeadSource, string> = {
  [LeadSource.MANUAL]: 'Manual',
  [LeadSource.IMPORT]: 'Import',
  [LeadSource.LANDING_PAGE]: 'Landing Page',
};

export function getLeadStatusConfig(status: LeadStatus) {
  return leadStatusConfig[status as keyof typeof leadStatusConfig] as {
    label: string;
    className: string;
    variant: BadgeProps['variant'];
  } || {
    label: status || 'Unknown Status',
    className: 'bg-gray-100 text-gray-800 hover:bg-gray-100',
    variant: 'outline'
  };
}

export function getLeadSourceLabel(source: LeadSource | string | null | undefined): string {
  if (!source) return 'Unknown source';
  return leadSourceLabels[source as LeadSource] || source;
}
