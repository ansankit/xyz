import apiClient from "./client";
import {
  User,
  Lead,
  Contact,
  Account,
  Campaign,
  AnalyticsEvent,
  FormSubmission,
  UserPermissions,
  LoginRequest,
  LoginResponse,
  SignupRequest,
  SignupResponse,
  LeadFilters,
  ContactFilters,
  CampaignFilters,
  UserFilters,
  WebhookPayload,
  WebhookResponse,
  ApiResponse,
  PaginatedResponse,
  PaginatedApiResponse,
  PaginationMeta,
  SyncLeadsRequest,
  SyncLeadsResponse,
  BrevoCampaign,
  BrevoAnalyticsResponse,
  UpdateCampaignRequest,
  MessagingAccount,
  MessageTemplate,
  CampaignDelivery,
  SalesMyLeadsResponse,
  SalesMyStatsResponse,
  FetchGstResponse,
  GenerateOtpResponse,
  VerifyOtpRequest,
  VerifyOtpResponse,
  Product,
  ProductCategory,
  CreateProductInput,
  UpdateProductInput,
  CreateCategoryInput,
  UpdateCategoryInput,
  Keyword,
  LeadAssignmentStats,
} from "./types";

// Auth Services
export const authService = {
  login: async (credentials: LoginRequest): Promise<LoginResponse> => {
    const response = await apiClient.post("/api/auth/login", credentials);
    return response.data;
  },

  developerLogin: async (credentials: LoginRequest): Promise<LoginResponse> => {
    const response = await apiClient.post("/api/auth/developer-login", credentials);
    return response.data;
  },

  signup: async (userData: SignupRequest): Promise<SignupResponse> => {
    const response = await apiClient.post("/api/auth/signup", userData);
    return response.data;
  },

  logout: async (): Promise<void> => {
    await apiClient.post("/api/auth/logout");
  },

  getCurrentUser: async (): Promise<User> => {
    const response = await apiClient.get("/api/auth/me");
    return response.data;
  },

  // Forgot password (OTP)
  requestPasswordResetOtp: async (
    email: string
  ): Promise<{ success: boolean }> => {
    const response = await apiClient.post("/api/auth/forgot-password", {
      email,
    });
    return response.data;
  },

  verifyPasswordResetOtp: async (
    email: string,
    otp: string
  ): Promise<{ resetToken: string; expiresIn: number }> => {
    const response = await apiClient.post("/api/auth/forgot-password/verify", {
      email,
      otp,
    });
    return response.data;
  },

  resetPasswordWithToken: async (
    resetToken: string,
    newPassword: string
  ): Promise<{ success: boolean }> => {
    const response = await apiClient.post("/api/auth/forgot-password/reset", {
      resetToken,
      newPassword,
    });
    return response.data;
  },

  changePassword: async (
    currentPassword: string,
    newPassword: string
  ): Promise<{ success: boolean }> => {
    const response = await apiClient.post("/api/auth/change-password", {
      currentPassword,
      newPassword,
    });
    return response.data;
  },
};

// Lead Services
export const leadService = {
  getAllLeads: async (
    filters?: LeadFilters & { page?: number; limit?: number }
  ): Promise<PaginatedApiResponse<Lead>> => {
    const params: any = { ...filters };
    // Convert keywordIds array to comma-separated string for API
    if (params.keywordIds && Array.isArray(params.keywordIds) && params.keywordIds.length > 0) {
      params.keywordIds = params.keywordIds.join(',');
    } else if (params.keywordIds) {
      delete params.keywordIds;
    }
    if (typeof params.assigned === "boolean") {
      params.assigned = params.assigned ? "true" : "false";
    }
    if (typeof params.unassigned === "boolean") {
      params.unassigned = params.unassigned ? "true" : "false";
    }
    const response = await apiClient.get("/api/leads", { params });
    return response.data;
  },

  getAllLeadsComplete: async (): Promise<Lead[]> => {
    const response = await apiClient.get("/api/leads/all");
    return response.data;
  },

  getLeadById: async (id: number): Promise<Lead> => {
    const response = await apiClient.get(`/api/leads/${id}`);
    return response.data;
  },

  createLead: async (
    leadData: Partial<Lead>
  ): Promise<{ lead: Lead; scoreBreakdown: any }> => {
    const response = await apiClient.post("/api/leads", leadData);
    return response.data;
  },

  updateLead: async (
    id: number,
    leadData: Partial<Lead>
  ): Promise<{ lead: Lead; scoreBreakdown: any }> => {
    const response = await apiClient.put(`/api/leads/${id}`, leadData);
    return response.data;
  },

  deleteLead: async (id: number): Promise<void> => {
    await apiClient.delete(`/api/leads/${id}`);
  },

  // Filter and search methods
  filterLeads: async (filters: LeadFilters): Promise<Lead[]> => {
    const response = await apiClient.get("/api/leads/filter", {
      params: filters,
    });
    return response.data;
  },

  searchLeads: async (query: string): Promise<Lead[]> => {
    const response = await apiClient.get("/api/leads/search", {
      params: { q: query },
    });
    return response.data;
  },

  getLeadsByStatus: async (status: string): Promise<Lead[]> => {
    const response = await apiClient.get(`/api/leads/by-status/${status}`);
    return response.data;
  },

  getLeadsBySource: async (source: string): Promise<Lead[]> => {
    const response = await apiClient.get(`/api/leads/by-source/${source}`);
    return response.data;
  },

  getLeadsByOwner: async (ownerId: number): Promise<Lead[]> => {
    const response = await apiClient.get(`/api/leads/by-owner/${ownerId}`);
    // The API returns a paginated response with data and pagination properties
    // Extract the data array from the response
    return response.data?.data || response.data || [];
  },

  getAssignmentStats: async (): Promise<LeadAssignmentStats[]> => {
    const response = await apiClient.get("/api/leads/assignment/stats");
    return response.data;
  },

  getLeadsByScore: async (
    minScore?: number,
    maxScore?: number
  ): Promise<Lead[]> => {
    const response = await apiClient.get("/api/leads/by-score", {
      params: { minScore, maxScore },
    });
    return response.data;
  },

  // Assignment methods
  assignLead: async (id: number, userId: number): Promise<Lead> => {
    const response = await apiClient.put(`/api/leads/${id}/assign`, { userId });
    return response.data;
  },

  assignLeadsBulk: async (
    userId: number,
    leadIds: number[]
  ): Promise<Lead[]> => {
    const response = await apiClient.post("/api/leads/assign-bulk", {
      userId,
      leadIds,
    });
    return response.data;
  },

  // Claim methods
  claimLead: async (id: number): Promise<Lead> => {
    const response = await apiClient.put(`/api/leads/${id}/claim`);
    return response.data;
  },

  claimLeadsBulk: async (payload: { leadIds: number[]; userId: number }): Promise<Lead[]> => {
    const response = await apiClient.post("/api/leads/claim-bulk", payload);
    return response.data;
  },

  // Conversion methods
  convertLead: async (
    id: number,
    data: { keywordIds?: number[] }
  ): Promise<any> => {
    const response = await apiClient.post(`/api/leads/${id}/convert`, data);
    return response.data;
  },

  convertLeadsBulk: async (
    leads: Array<{ leadId: number; keywordIds?: number[] }>
  ): Promise<any> => {
    const response = await apiClient.post("/api/leads/convert-bulk", { leads });
    return response.data;
  },

  getConversionHistory: async (id: number): Promise<any[]> => {
    const response = await apiClient.get(`/api/leads/${id}/conversion-history`);
    return response.data;
  },

  getLeadFormSubmissions: async (id: number): Promise<FormSubmission[]> => {
    const response = await apiClient.get(`/api/leads/${id}/form-submissions`);
    return response.data;
  },

  // Scoring methods
  updateLeadScore: async (id: number, score: number): Promise<Lead> => {
    const response = await apiClient.put(`/api/leads/${id}/score`, { score });
    return response.data;
  },

  // Import/Export helpers
  downloadExport: async (
    entity: "leads" | "contacts" | "accounts",
    params: { startPage?: number; endPage?: number; limit?: number; format?: "xlsx" | "csv" }
  ) => {
    const response = await apiClient.get(`/api/export/${entity}` as const, {
      params: {
        ...params,
        format: params.format || "xlsx",
      },
      responseType: "blob",
    });
    return response.data as Blob;
  },

  downloadImportTemplate: async (): Promise<Blob> => {
    const response = await apiClient.get("/api/leads/import/template", {
      responseType: "blob",
    });
    return response.data as Blob;
  },

  downloadImportTemplateCsv: async (): Promise<Blob> => {
    const response = await apiClient.get("/api/leads/import/template-csv", {
      responseType: "blob",
    });
    return response.data as Blob;
  },

  importLeads: async (
    file: File
  ): Promise<{
    insertedCount: number;
    skippedDuplicates: number;
    skippedCount: number;
    errors: Array<{ row: number; reason: string }>;
    report?: { filename: string; mimeType: string; base64: string };
  }> => {
    const form = new FormData();
    form.append("file", file);
    const response = await apiClient.post("/api/leads/import", form, {
      headers: { "Content-Type": "multipart/form-data" },
    });
    return response.data;
  },

  emailSelectedLeads: async (
    to: string,
    leadIds: number[]
  ): Promise<{ success: boolean }> => {
    const response = await apiClient.post("/api/export/leads/email", {
      to,
      leadIds,
    });
    return response.data;
  },
};

// User Services
export const userService = {
  getAllUsers: async (filters?: UserFilters): Promise<User[]> => {
    const response = await apiClient.get("/api/users", { params: filters });
    return response.data;
  },

  getUserById: async (id: number): Promise<User> => {
    const response = await apiClient.get(`/api/users/${id}`);
    return response.data;
  },

  createUser: async (
    userData: Omit<User, "id" | "createdAt" | "updatedAt">
  ): Promise<User> => {
    const response = await apiClient.post("/api/users", userData);
    return response.data;
  },

  updateUser: async (id: number, userData: Partial<User>): Promise<User> => {
    const response = await apiClient.put(`/api/users/${id}`, userData);
    return response.data;
  },

  deleteUser: async (id: number): Promise<void> => {
    await apiClient.delete(`/api/users/${id}`);
  },

  updateUserPermissions: async (
    id: number,
    permissions: Partial<UserPermissions>
  ): Promise<UserPermissions> => {
    const response = await apiClient.put(
      `/api/users/${id}/permissions`,
      permissions
    );
    return response.data;
  },
};

// Account Services
export const accountService = {
  getAllAccounts: async (filters?: {
    page?: number;
    limit?: number;
  }): Promise<PaginatedApiResponse<Account>> => {
    const response = await apiClient.get("/api/accounts/getAllAccounts", {
      params: filters,
    });
    return response.data;
  },

  getAccountDetails: async (id: number): Promise<Account> => {
    const response = await apiClient.get(`/api/accounts/getDetails/${id}`);
    return response.data;
  },

  searchAccountContacts: async (
    accountId: number,
    query: string
  ): Promise<Contact[]> => {
    const response = await apiClient.get(
      `/api/accounts/${accountId}/contacts/search`,
      {
        params: { q: query },
      }
    );
    return response.data;
  },

  searchAccounts: async (query: string): Promise<Account[]> => {
    const response = await apiClient.get("/api/accounts/search", {
      params: { q: query },
    });
    return response.data;
  },

  deleteAccount: async (id: number): Promise<void> => {
    await apiClient.delete(`/api/accounts/${id}`);
  },
  updateAccount: async (
    id: number,
    accountData: Partial<Account>
  ): Promise<Account> => {
    const response = await apiClient.put(`/api/accounts/${id}` , accountData);
    return response.data;
  },
};

// Contact Services
export const contactService = {
  getAllContacts: async (filters?: ContactFilters & { page?: number; limit?: number }): Promise<PaginatedApiResponse<Contact>> => {
    const response = await apiClient.get("/api/contacts", { params: filters });
    return response.data;
  },

  getContactById: async (id: number): Promise<Contact> => {
    const response = await apiClient.get(`/api/contacts/${id}`);
    return response.data;
  },

  createContact: async (
    contactData: Omit<Contact, "id" | "createdAt" | "updatedAt">
  ): Promise<Contact> => {
    const response = await apiClient.post("/api/contacts", contactData);
    return response.data;
  },

  updateContact: async (
    id: number,
    contactData: Partial<Contact>
  ): Promise<Contact> => {
    const response = await apiClient.put(`/api/contacts/${id}`, contactData);
    return response.data;
  },

  deleteContact: async (id: number): Promise<void> => {
    await apiClient.delete(`/api/contacts/${id}`);
  },

  searchContacts: async (query: string): Promise<Contact[]> => {
    const response = await apiClient.get("/api/contacts/search", {
      params: { q: query },
    });
    return response.data;
  },
};

// Campaign Services
export const campaignService = {
  getAllCampaigns: async (filters?: CampaignFilters): Promise<Campaign[]> => {
    const response = await apiClient.get("/api/campaigns", { params: filters });
    return response.data;
  },

  getCampaignById: async (id: number): Promise<Campaign> => {
    const response = await apiClient.get(`/api/campaigns/${id}`);
    return response.data;
  },

  createCampaign: async (
    campaignData: Omit<Campaign, "id" | "createdAt" | "updatedAt">
  ): Promise<Campaign> => {
    const response = await apiClient.post("/api/campaigns", campaignData);
    return response.data;
  },

  updateCampaign: async (
    id: number,
    campaignData: Partial<Campaign>
  ): Promise<Campaign> => {
    const response = await apiClient.put(`/api/campaigns/${id}`, campaignData);
    return response.data;
  },

  deleteCampaign: async (id: number): Promise<void> => {
    await apiClient.delete(`/api/campaigns/${id}`);
  },
};

// Analytics Services
export const analyticsService = {
  getAllEvents: async (params?: {
    campaignId?: number;
    contactId?: number;
    leadId?: number;
    eventType?: string;
  }): Promise<AnalyticsEvent[]> => {
    const response = await apiClient.get("/api/analytics/events", { params });
    return response.data;
  },

  createEvent: async (
    eventData: Omit<AnalyticsEvent, "id" | "occurredAt">
  ): Promise<AnalyticsEvent> => {
    const response = await apiClient.post("/api/analytics/events", eventData);
    return response.data;
  },

  getEventById: async (id: number): Promise<AnalyticsEvent> => {
    const response = await apiClient.get(`/api/analytics/events/${id}`);
    return response.data;
  },

  getEventsByCampaign: async (
    campaignId: number
  ): Promise<AnalyticsEvent[]> => {
    const response = await apiClient.get(
      `/api/analytics/events/campaign/${campaignId}`
    );
    return response.data;
  },

  getEventsByContact: async (contactId: number): Promise<AnalyticsEvent[]> => {
    const response = await apiClient.get(
      `/api/analytics/events/contact/${contactId}`
    );
    return response.data;
  },

  getEventsByLead: async (leadId: number): Promise<AnalyticsEvent[]> => {
    const response = await apiClient.get(
      `/api/analytics/events/lead/${leadId}`
    );
    return response.data;
  },
};

// WhatsApp / Messaging Services
export const whatsappService = {
  // Accounts
  listAccounts: async (): Promise<MessagingAccount[]> => {
    const response = await apiClient.get("/api/whatsapp/accounts");
    return response.data;
  },
  createAccount: async (
    data: Partial<MessagingAccount>
  ): Promise<MessagingAccount> => {
    const response = await apiClient.post("/api/whatsapp/accounts", data);
    return response.data;
  },
  // Templates
  listTemplates: async (accountId: number): Promise<MessageTemplate[]> => {
    const response = await apiClient.get("/api/whatsapp/templates", {
      params: { accountId },
    });
    return response.data;
  },
  syncTemplates: async (accountId: number): Promise<{ count: number }> => {
    const response = await apiClient.post("/api/whatsapp/templates/sync", {
      accountId,
    });
    return response.data;
  },
  // Campaigns
  createCampaign: async (payload: any): Promise<Campaign> => {
    const response = await apiClient.post("/api/whatsapp/campaigns", payload);
    return response.data;
  },
  sendCampaign: async (id: number): Promise<{ queued: number }> => {
    const response = await apiClient.post(`/api/whatsapp/campaigns/${id}/send`);
    return response.data;
  },
  // Data
  listDeliveries: async (campaignId: number): Promise<CampaignDelivery[]> => {
    const response = await apiClient.get("/api/whatsapp/deliveries", {
      params: { campaignId },
    });
    return response.data;
  },
  listEvents: async (campaignId: number): Promise<AnalyticsEvent[]> => {
    const response = await apiClient.get("/api/whatsapp/events", {
      params: { campaignId },
    });
    return response.data;
  },
  // Opt-out
  optOut: async (
    address: string,
    reason?: string,
    source?: string
  ): Promise<any> => {
    const response = await apiClient.post("/api/whatsapp/optout", {
      channel: "whatsapp",
      address,
      reason,
      source,
    });
    return response.data;
  },
  removeOptOut: async (address: string): Promise<{ removed: boolean }> => {
    const response = await apiClient.delete("/api/whatsapp/optout", {
      params: { channel: "whatsapp", address },
    });
    return response.data;
  },
};

// Webhook Services
export const webhookService = {
  handleLandingiWebhook: async (
    payload: WebhookPayload
  ): Promise<WebhookResponse> => {
    const response = await apiClient.post("/api/webhook/landingi", payload);
    return response.data;
  },

  testLandingiWebhook: async (): Promise<WebhookResponse> => {
    const response = await apiClient.get("/api/webhook/landingi/test");
    return response.data;
  },
};

// Dashboard Services
export const dashboardService = {
  getLeadsGeneratedOverTime: async (params?: {
    period?: "week" | "month";
    startDate?: string;
    endDate?: string;
  }): Promise<any> => {
    const response = await apiClient.get("/api/dashboard/leads-generated", {
      params,
    });
    return response.data;
  },

  getConversionRate: async (): Promise<any> => {
    const response = await apiClient.get("/api/dashboard/conversion-rate");
    return response.data;
  },

  getLeadSources: async (): Promise<any> => {
    const response = await apiClient.get("/api/dashboard/lead-sources");
    return response.data;
  },

  getKeyMetrics: async (): Promise<any> => {
    const response = await apiClient.get("/api/dashboard/key-metrics");
    return response.data;
  },
};

// Brevo Services
export const brevoService = {
  syncLeads: async (leadIds: number[]): Promise<SyncLeadsResponse> => {
    const response = await apiClient.post("/api/brevo/sync-leads", { leadIds });
    return response.data;
  },

  getCampaigns: async (params?: {
    limit?: number;
    offset?: number;
    status?: string;
  }): Promise<{ campaigns: BrevoCampaign[]; count: number; total: number }> => {
    const response = await apiClient.get("/api/brevo/campaigns", { params });
    return response.data;
  },

  getActiveCampaigns: async (): Promise<{
    campaigns: BrevoCampaign[];
    count: number;
  }> => {
    const response = await apiClient.get("/api/brevo/campaigns/active");
    return response.data;
  },

  getCampaignDetails: async (id: number, statistics?: string): Promise<BrevoCampaign> => {
    const params = statistics ? { statistics } : {};
    const response = await apiClient.get(`/api/brevo/campaigns/${id}`, { params });
    return response.data;
  },

  deleteCampaign: async (id: number): Promise<void> => {
    await apiClient.delete(`/api/brevo/campaigns/${id}`);
  },

  updateCampaign: async (id: number, data: UpdateCampaignRequest): Promise<BrevoCampaign> => {
    const response = await apiClient.put(`/api/brevo/campaigns/${id}`, data);
    return response.data;
  },

  updateCampaignStatus: async (id: number, status: string): Promise<void> => {
    await apiClient.put(`/api/brevo/campaigns/${id}/status`, { status });
  },

  getAnalytics: async (): Promise<BrevoAnalyticsResponse> => {
    const response = await apiClient.get("/api/brevo/analytics");
    return response.data;
  },

  testConnection: async (): Promise<{ status: string; message: string }> => {
    const response = await apiClient.get("/api/brevo/test-connection");
    return response.data;
  },
};

// Sales Services
export const salesService = {
  // Get all leads assigned to the current sales user
  getMyLeads: async (params?: {
    page?: number;
    limit?: number;
    status?: string;
    source?: string;
  }): Promise<SalesMyLeadsResponse> => {
    const response = await apiClient.get("/api/sales/leads", { params });
    return response.data;
  },

  // Get a specific lead by ID (only if assigned to this sales user)
  getLeadById: async (id: number): Promise<Lead> => {
    const response = await apiClient.get(`/api/sales/leads/${id}`);
    return response.data;
  },

  // Qualify a lead
  qualifyLead: async (id: number): Promise<{ message: string; lead: Lead }> => {
    const response = await apiClient.put(`/api/sales/leads/${id}/qualify`);
    return response.data;
  },

  // Disqualify a lead
  disqualifyLead: async (
    id: number
  ): Promise<{ message: string; lead: Lead }> => {
    const response = await apiClient.put(`/api/sales/leads/${id}/disqualify`);
    return response.data;
  },

  // Add a remark to a lead
  addRemark: async (
    id: number,
    remark: string
  ): Promise<{ message: string; remark: any }> => {
    const response = await apiClient.post(`/api/sales/leads/${id}/remarks`, {
      remark,
    });
    return response.data;
  },

  // Get all remarks for a specific lead
  getLeadRemarks: async (id: number): Promise<{ remarks: any[] }> => {
    const response = await apiClient.get(`/api/sales/leads/${id}/remarks`);
    return response.data;
  },

  // Get statistics for the sales user's leads
  getMyStats: async (): Promise<SalesMyStatsResponse> => {
    const response = await apiClient.get("/api/sales/stats");
    return response.data;
  },
};

// Subdealer Services
export const subdealerService = {
  fetchGstDetails: async (gstNumber: string): Promise<FetchGstResponse> => {
    const response = await apiClient.post("/api/subdealer/fetch-gst", {
      gstNumber,
    });
    return response.data;
  },

  generateOtp: async (phone: string): Promise<GenerateOtpResponse> => {
    const response = await apiClient.post("/api/subdealer/generate-otp", {
      phone,
    });
    return response.data;
  },

  verifyOtpAndRegister: async (
    data: VerifyOtpRequest
  ): Promise<VerifyOtpResponse> => {
    const response = await apiClient.post("/api/subdealer/verify-otp", data);
    return response.data;
  },
};

// Product Services
export const productService = {
  getAllProducts: async (filters?: {
    categoryId?: number;
    active?: boolean;
    search?: string;
  }): Promise<ApiResponse<Product[]>> => {
    const params = new URLSearchParams();
    if (filters?.categoryId) params.append('categoryId', filters.categoryId.toString());
    if (filters?.active !== undefined) params.append('active', filters.active.toString());
    if (filters?.search) params.append('search', filters.search);
    
    const queryString = params.toString();
    const url = queryString ? `/api/products?${queryString}` : '/api/products';
    const response = await apiClient.get(url);
    return response.data;
  },

  searchProducts: async (query: string): Promise<ApiResponse<Product[]>> => {
    const response = await apiClient.get(`/api/products/search?q=${encodeURIComponent(query)}`);
    return response.data;
  },

  getActiveProducts: async (): Promise<ApiResponse<Product[]>> => {
    const response = await apiClient.get("/api/products/active");
    return response.data;
  },

  getProductById: async (id: number): Promise<ApiResponse<Product>> => {
    const response = await apiClient.get(`/api/products/${id}`);
    return response.data;
  },

  createProduct: async (data: CreateProductInput): Promise<ApiResponse<Product>> => {
    const formData = new FormData();
    formData.append("name", data.name);
    formData.append("code", data.code);
    formData.append("price", data.price.toString());
    formData.append("categoryId", data.categoryId.toString());
    if (data.description) formData.append("description", data.description);
    if (data.active !== undefined) formData.append("active", data.active.toString());
    if (data.image) formData.append("image", data.image);

    const response = await apiClient.post("/api/products", formData);
    return response.data;
  },

  updateProduct: async (id: number, data: UpdateProductInput): Promise<ApiResponse<Product>> => {
    const formData = new FormData();
    if (data.name) formData.append("name", data.name);
    if (data.code) formData.append("code", data.code);
    if (data.price !== undefined) formData.append("price", data.price.toString());
    if (data.categoryId !== undefined) formData.append("categoryId", data.categoryId.toString());
    if (data.description !== undefined) formData.append("description", data.description);
    if (data.active !== undefined) formData.append("active", data.active.toString());
    if (data.image) formData.append("image", data.image);

    const response = await apiClient.put(`/api/products/${id}`, formData);
    return response.data;
  },

  deleteProduct: async (id: number): Promise<ApiResponse<void>> => {
    const response = await apiClient.delete(`/api/products/${id}`);
    return response.data;
  },
};

// Product Category Services
export const productCategoryService = {
  getAllCategories: async (): Promise<ApiResponse<ProductCategory[]>> => {
    const response = await apiClient.get("/api/product-categories");
    return response.data;
  },

  getCategoryById: async (id: number): Promise<ApiResponse<ProductCategory>> => {
    const response = await apiClient.get(`/api/product-categories/${id}`);
    return response.data;
  },

  createCategory: async (data: CreateCategoryInput): Promise<ApiResponse<ProductCategory>> => {
    const response = await apiClient.post("/api/product-categories", data);
    return response.data;
  },

  updateCategory: async (id: number, data: UpdateCategoryInput): Promise<ApiResponse<ProductCategory>> => {
    const response = await apiClient.put(`/api/product-categories/${id}`, data);
    return response.data;
  },

  deleteCategory: async (id: number): Promise<ApiResponse<void>> => {
    const response = await apiClient.delete(`/api/product-categories/${id}`);
    return response.data;
  },
};

// Keyword Services
export const keywordService = {
  getAllKeywords: async (search?: string): Promise<ApiResponse<Keyword[]>> => {
    const params = search ? { search } : {};
    const response = await apiClient.get("/api/keywords", { params });
    return response.data;
  },

  getKeywordById: async (id: number): Promise<ApiResponse<Keyword>> => {
    const response = await apiClient.get(`/api/keywords/${id}`);
    return response.data;
  },

  createKeyword: async (name: string): Promise<ApiResponse<Keyword>> => {
    const response = await apiClient.post("/api/keywords", { name });
    return response.data;
  },

  deleteKeyword: async (id: number): Promise<ApiResponse<void>> => {
    const response = await apiClient.delete(`/api/keywords/${id}`);
    return response.data;
  },

  searchKeywords: async (query: string): Promise<ApiResponse<Keyword[]>> => {
    const response = await apiClient.get("/api/keywords", {
      params: { search: query },
    });
    return response.data;
  },
};

// Health Check
export const healthService = {
  checkHealth: async (): Promise<{ status: string; database: string }> => {
    const response = await apiClient.get("/health");
    return response.data;
  },
};
